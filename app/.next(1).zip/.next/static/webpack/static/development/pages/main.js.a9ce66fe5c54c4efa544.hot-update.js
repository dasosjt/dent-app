webpackHotUpdate("static/development/pages/main.js",{

/***/ "./components/createinjurymodal.jsx":
/*!******************************************!*\
  !*** ./components/createinjurymodal.jsx ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CreateInjuryModal; });
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-jsx/style */ "./node_modules/styled-jsx/style.js");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! semantic-ui-react */ "./node_modules/semantic-ui-react/dist/es/index.js");
/* harmony import */ var _css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./css */ "./components/css.jsx");
/* harmony import */ var _utils_functions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../utils/functions */ "./utils/functions.js");
/* harmony import */ var _configuration_options__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../configuration/options */ "./configuration/options.js");
var _jsxFileName = "/home/dsosa/Projects/dent-app/app/components/createinjurymodal.jsx";



function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






var DEFAULT_INIT_STATE = {
  'modalOpen': false,
  'locations': [_objectSpread({}, _configuration_options__WEBPACK_IMPORTED_MODULE_5__["DEFAULT_LOCATION"])],
  'tooths': [],
  'error': null,
  'name': null,
  'lastname': null,
  'register': null,
  'register_num': null,
  'gender': null,
  'age': null,
  '_type': null,
  'op1': null,
  'op2': null,
  'form': null,
  'op3': null,
  'size_0': null,
  'size_1': null,
  'size_2': null,
  'op4': null,
  'op5': null,
  'op5_type': null,
  'op6': null,
  'op7': null,
  'op8': null,
  'dif1': null,
  'dif2': null,
  'dif3': null
};

var CreateInjuryModal =
/*#__PURE__*/
function (_Component) {
  _inherits(CreateInjuryModal, _Component);

  function CreateInjuryModal(props) {
    var _this;

    _classCallCheck(this, CreateInjuryModal);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(CreateInjuryModal).call(this, props));

    _defineProperty(_assertThisInitialized(_this), "teethOptions", []);

    _defineProperty(_assertThisInitialized(_this), "handleChange", function (e, _ref) {
      var name = _ref.name,
          value = _ref.value,
          checked = _ref.checked;
      console.log('handleChange');
      console.log("".concat(name, " ").concat(value, " ").concat(checked));

      if (value === undefined && checked !== undefined) {
        value = checked;
      }

      if (name === 'op4' && value === 'Asociada') {
        _this.checkTooth(value);
      } else if (name === 'op4' && value === 'No Asociado') {
        _this.removeToothByType('Asociada');
      } else if (name === 'op6' && value === 'Con Desplazamiento Piezas Dentarias') {
        _this.checkTooth(value);
      } else if (name === 'op6' && value === 'Sin Desplazamiento Piezas Dentarias') {
        _this.removeToothByType('Con Desplazamiento Piezas Dentarias');
      } else if (name === 'op8' && value === 'Pieza Incluida') {
        _this.checkTooth(value);
      } else if (name === 'op8' && value === 'Pieza No Incluida') {
        _this.removeToothByType('Pieza Incluida');
      }

      _this.setState(_defineProperty({}, name, value));
    });

    _defineProperty(_assertThisInitialized(_this), "handleLocationChange", function (e, _ref2) {
      var name = _ref2.name,
          value = _ref2.value;

      if (name <= _this.state.locations.length - 1) {
        var locations = _this.state.locations;
        locations[name]['location'] = value['name'];
        locations[name]['_type'] = value['type'];
        locations[name]['body_mandibula'] = false;
        locations[name]['sinus_maxilar'] = false;

        _this.setState({
          'locations': _toConsumableArray(locations)
        });
      }
    });

    _defineProperty(_assertThisInitialized(_this), "handleToothsChange", function (e, _ref3) {
      var name = _ref3.name,
          value = _ref3.value;

      if (name <= _this.state.tooths.length - 1) {
        var tooths = _toConsumableArray(_this.state.tooths);

        tooths[name]['location'] = value;

        _this.setState({
          'tooths': _toConsumableArray(tooths)
        });
      }
    });

    _defineProperty(_assertThisInitialized(_this), "handlePositionChange", function (e, _ref4) {
      var name = _ref4.name,
          value = _ref4.value;

      if (name <= _this.state.locations.length - 1) {
        var locations = _this.state.locations;
        locations[name]['position'] = value;

        _this.setState({
          'locations': _toConsumableArray(locations)
        });
      }
    });

    _defineProperty(_assertThisInitialized(_this), "handleBranchChange", function (e, _ref5) {
      var name = _ref5.name,
          value = _ref5.value;

      if (name <= _this.state.locations.length - 1) {
        var locations = _this.state.locations;
        locations[name]['branch_mandibula'] = value;

        _this.setState({
          'locations': _toConsumableArray(locations)
        });
      }
    });

    _defineProperty(_assertThisInitialized(_this), "handleWallChange", function (e, _ref6) {
      var name = _ref6.name,
          value = _ref6.value;

      if (name <= _this.state.locations.length - 1) {
        var locations = _this.state.locations;
        locations[name]['sinus_maxilar_wall'] = value;

        _this.setState({
          'locations': _toConsumableArray(locations)
        });
      }
    });

    _defineProperty(_assertThisInitialized(_this), "handleBodyChange", function (index, _ref7) {
      var name = _ref7.name,
          checked = _ref7.checked;

      if (name <= _this.state.locations.length - 1) {
        var locations = _this.state.locations;
        locations[name]['body_mandibula'] = checked;

        _this.setState({
          'locations': _toConsumableArray(locations)
        });
      }
    });

    _defineProperty(_assertThisInitialized(_this), "handleSinusChange", function (index, _ref8) {
      var name = _ref8.name,
          checked = _ref8.checked;

      if (name <= _this.state.locations.length - 1) {
        var locations = _this.state.locations;
        locations[name]['sinus_maxilar'] = checked;

        _this.setState({
          'locations': _toConsumableArray(locations)
        });
      }
    });

    _defineProperty(_assertThisInitialized(_this), "addLocation", function (e) {
      e.preventDefault();

      _this.setState(function (state) {
        return _objectSpread({}, state, {
          'locations': [].concat(_toConsumableArray(state.locations), [_objectSpread({}, _configuration_options__WEBPACK_IMPORTED_MODULE_5__["DEFAULT_LOCATION"])])
        });
      });
    });

    _defineProperty(_assertThisInitialized(_this), "removeLocation", function (e) {
      e.preventDefault();

      _this.setState(function (state) {
        var locations = _toConsumableArray(state.locations);

        locations.pop();

        if (locations.length > 0) {
          return _objectSpread({}, state, {
            locations: locations
          });
        } else {
          return _objectSpread({}, state);
        }
      });
    });

    _defineProperty(_assertThisInitialized(_this), "addTooth", function (currentType) {
      return function (e) {
        e.preventDefault();

        _this.setState(function (state) {
          var new_tooth = Object.assign({}, _configuration_options__WEBPACK_IMPORTED_MODULE_5__["DEFAULT_TOOTH"]);
          new_tooth['_type'] = currentType;
          new_tooth['index'] = state.tooths.length;
          return _objectSpread({}, state, {
            'tooths': [].concat(_toConsumableArray(state.tooths), [_objectSpread({}, new_tooth)])
          });
        });
      };
    });

    _defineProperty(_assertThisInitialized(_this), "removeTooth", function (index) {
      return function (e) {
        e.preventDefault();

        _this.removeToothByIndex(index);
      };
    });

    _this.state = Object.assign({}, DEFAULT_INIT_STATE);
    _this.teethOptions = _this.initTeethOptions();
    _this.handleOpen = _this.handleOpen.bind(_assertThisInitialized(_this));
    _this.handleClose = _this.handleClose.bind(_assertThisInitialized(_this));
    _this.handleSubmit = _this.handleSubmit.bind(_assertThisInitialized(_this));
    _this.handleChange = _this.handleChange.bind(_assertThisInitialized(_this));
    _this.handleBranchChange = _this.handleBranchChange.bind(_assertThisInitialized(_this));
    _this.handleBodyChange = _this.handleBodyChange.bind(_assertThisInitialized(_this));
    _this.handleSinusChange = _this.handleSinusChange.bind(_assertThisInitialized(_this));
    _this.handleWallChange = _this.handleWallChange.bind(_assertThisInitialized(_this));
    return _this;
  }

  _createClass(CreateInjuryModal, [{
    key: "initTeethOptions",
    value: function initTeethOptions() {
      var teethRange = Object(_utils_functions__WEBPACK_IMPORTED_MODULE_4__["range"])(1, 32).map(function (number) {
        var numberString = number.toString();
        return {
          'key': numberString,
          'value': numberString,
          'text': numberString
        };
      });
      return [].concat(_toConsumableArray(teethRange), [{
        'key': 'sp',
        'value': 'Super Numeraria',
        'text': 'Super Numeraria'
      }]);
    }
  }, {
    key: "handleOpen",
    value: function handleOpen() {
      this.setState(_objectSpread({}, DEFAULT_INIT_STATE));
      this.setState({
        'locations': [_objectSpread({}, _configuration_options__WEBPACK_IMPORTED_MODULE_5__["DEFAULT_LOCATION"])]
      });
      this.setState({
        'modalOpen': true
      });
    }
  }, {
    key: "handleClose",
    value: function handleClose() {
      this.setState({
        'modalOpen': false
      });
    }
  }, {
    key: "handleSubmit",
    value: function handleSubmit(e) {
      var _this2 = this;

      console.log("******************");
      console.log(e);
      console.log("******************");
      e.target.reset();
      var tmp_locations = this.state.locations;

      if (tmp_locations && tmp_locations.length < 2 && tmp_locations[0] === _configuration_options__WEBPACK_IMPORTED_MODULE_5__["DEFAULT_LOCATION"]) {
        this.setState('locations', []);
      }

      console.log(this.state);
      fetch('http://127.0.0.1:5000/injury', {
        method: 'POST',
        headers: new Headers({
          "Content-Type": "application/json",
          "Accept": "application/json"
        }),
        body: JSON.stringify(this.state)
      }).then(function (response) {
        _this2.setState(_objectSpread({}, DEFAULT_INIT_STATE));

        _this2.handleClose();
      }).catch(function (error) {
        _this2.setState({
          error: error
        });
      });
    }
  }, {
    key: "checkTooth",
    value: function checkTooth(currentType) {
      var tooths = this.state.tooths.filter(function (tooth) {
        return tooth._type === currentType;
      });

      if (tooths.length === 0) {
        this.setState(function (state) {
          var new_tooth = Object.assign({}, _configuration_options__WEBPACK_IMPORTED_MODULE_5__["DEFAULT_TOOTH"]);
          new_tooth['_type'] = currentType;
          new_tooth['index'] = state.tooths.length;
          return _objectSpread({}, state, {
            'tooths': [].concat(_toConsumableArray(state.tooths), [_objectSpread({}, new_tooth)])
          });
        });
      }
    }
  }, {
    key: "removeToothByType",
    value: function removeToothByType(currentType) {
      var _this3 = this;

      this.setState(function (state) {
        var tooths = _this3.state.tooths.filter(function (tooth) {
          return tooth._type !== currentType;
        });

        return _objectSpread({}, state, {
          'tooths': _this3.updateToothsIndex(tooths)
        });
      });
    }
  }, {
    key: "removeToothByTypeAndEmpty",
    value: function removeToothByTypeAndEmpty(currentType, cb) {
      var _this4 = this;

      this.setState(function (state) {
        var tooths = _this4.state.tooths.filter(function (tooth) {
          console.log(tooth.location);
          return tooth._type !== currentType && tooth.location === "";
        });

        return _objectSpread({}, state, {
          'tooths': _this4.updateToothsIndex(tooths)
        });
      }, cb());
    }
  }, {
    key: "removeToothByIndex",
    value: function removeToothByIndex(index) {
      var _this5 = this;

      this.setState(function (state) {
        var tooths = _this5.state.tooths.filter(function (tooth) {
          return tooth.index !== index;
        });

        return _objectSpread({}, state, {
          'tooths': _this5.updateToothsIndex(tooths)
        });
      });
    }
  }, {
    key: "updateToothsIndex",
    value: function updateToothsIndex(tooths) {
      var newTooths = _toConsumableArray(tooths.map(function (tooth, index) {
        tooth.index = index;
        return tooth;
      }));

      console.log(newTooths);
      return newTooths;
    }
  }, {
    key: "render",
    value: function render() {
      var _this6 = this;

      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Modal"], {
        open: this.state.modalOpen,
        onClose: this.handleClose,
        trigger: react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Button"], {
          inverted: true,
          color: "purple",
          onClick: this.handleOpen,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 357
          },
          __self: this
        }, "Ingresar nueva lesi\xF3n"),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 353
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Segment"], {
        inverted: true,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 364
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Modal"].Header, {
        as: "h1",
        style: {
          margin: 2
        },
        __source: {
          fileName: _jsxFileName,
          lineNumber: 365
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("b", {
        className: "jsx-2839058981",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 368
        },
        __self: this
      }, "Nueva Lesi\xF3n")), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Modal"].Content, {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 370
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Modal"].Description, {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 371
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"], {
        onSubmit: this.handleSubmit,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 372
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
        widths: "equal",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 374
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
        required: true,
        control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Input"],
        label: "Nombre",
        name: "name",
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 375
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
        required: true,
        control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Input"],
        label: "Apellido",
        name: "lastname",
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 381
        },
        __self: this
      })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
        widths: "equal",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 388
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
        required: true,
        control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Select"],
        label: "Registro",
        name: "register",
        options: _configuration_options__WEBPACK_IMPORTED_MODULE_5__["REGISTER"],
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 389
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
        required: true,
        control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Input"],
        label: "Registro",
        name: "register_num",
        type: "number",
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 396
        },
        __self: this
      })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
        widths: "equal",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 404
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
        required: true,
        control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Select"],
        label: "G\xE9nero",
        name: "gender",
        options: _configuration_options__WEBPACK_IMPORTED_MODULE_5__["GENDER"],
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 405
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
        required: true,
        control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Input"],
        label: "Edad",
        name: "age",
        type: "number",
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 412
        },
        __self: this
      })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
        required: true,
        control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Select"],
        label: "Aspecto General",
        name: "_type",
        options: _configuration_options__WEBPACK_IMPORTED_MODULE_5__["_TYPE"],
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 420
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
        inline: true,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 427
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Radio, {
        label: "\xDAnica",
        name: "op1",
        value: "\xDAnica",
        checked: this.state.op1 === 'Única',
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 428
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Radio, {
        label: "M\xFAltiple",
        name: "op1",
        value: "M\xFAltiple",
        checked: this.state.op1 === 'Múltiple',
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 434
        },
        __self: this
      })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
        inline: true,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 441
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Radio, {
        label: "Unilocular",
        name: "op2",
        value: "Unilocular",
        checked: this.state.op2 === 'Unilocular',
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 442
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Radio, {
        label: "Multilocular",
        name: "op2",
        value: "Multilocular",
        checked: this.state.op2 === 'Multilocular',
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 448
        },
        __self: this
      })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
        inline: true,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 455
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
        control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Select"],
        label: "Forma",
        name: "form",
        options: _configuration_options__WEBPACK_IMPORTED_MODULE_5__["FORM"],
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 456
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
        control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Select"],
        label: "Bordes",
        name: "op3",
        options: _configuration_options__WEBPACK_IMPORTED_MODULE_5__["OP3"],
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 462
        },
        __self: this
      })), this.state.locations.map(function (obj, index) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
          key: 'location' + index,
          inline: true,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 471
          },
          __self: this
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
          control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Select"],
          name: index,
          label: "Localizaci\xF3n",
          options: Object(_configuration_options__WEBPACK_IMPORTED_MODULE_5__["LOCATION"])(index),
          onChange: _this6.handleLocationChange,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 474
          },
          __self: this
        }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
          control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Select"],
          name: index,
          label: "Posici\xF3n",
          options: Object(_configuration_options__WEBPACK_IMPORTED_MODULE_5__["POSITION"])(index),
          onChange: _this6.handlePositionChange,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 480
          },
          __self: this
        }), obj.location === 'Mandíbula' ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
          control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Select"],
          label: "Rama",
          name: index,
          options: Object(_configuration_options__WEBPACK_IMPORTED_MODULE_5__["MANDIBULA_BRANCH"])(index),
          onChange: _this6.handleBranchChange,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 489
          },
          __self: this
        }) : null, obj.location === 'Mandíbula' ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
          control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Checkbox"],
          label: "Cuerpo",
          name: index,
          onChange: _this6.handleBodyChange,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 499
          },
          __self: this
        }) : null, obj.location === 'Maxilar' ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
          control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Checkbox"],
          label: "Seno Maxilar",
          name: index,
          onChange: _this6.handleSinusChange,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 508
          },
          __self: this
        }) : null, obj.sinus_maxilar ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
          control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Select"],
          label: "Pared",
          name: index,
          options: Object(_configuration_options__WEBPACK_IMPORTED_MODULE_5__["SINUS_MAXILAR_WALL"])(index),
          onChange: _this6.handleWallChange,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 517
          },
          __self: this
        }) : null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", {
          key: 'br' + index,
          className: "jsx-2839058981",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 525
          },
          __self: this
        }), controlOnlyToLast(index, _this6.state.locations, _this6.addLocation, _this6.removeLocation));
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 535
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
        control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Input"],
        label: "Eje Mayor",
        name: "size_0",
        type: "number",
        step: "0.1",
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 536
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
        control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Input"],
        label: "Eje Menor",
        name: "size_1",
        type: "number",
        step: "0.1",
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 543
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
        control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Input"],
        label: "Diametro",
        name: "size_2",
        type: "number",
        step: "0.1",
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 550
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("label", {
        className: "jsx-2839058981",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 557
        },
        __self: this
      }, "mm")), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
        inline: true,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 559
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Radio, {
        label: "Asociada",
        name: "op4",
        value: "Asociada",
        checked: this.state.op4 === 'Asociada',
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 560
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Radio, {
        label: "No Asociado",
        name: "op4",
        value: "No Asociado",
        checked: this.state.op4 === 'No Asociado',
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 566
        },
        __self: this
      })), this.state.op4 === 'Asociada' ? this.state.tooths.filter(function (t) {
        return t._type === 'Asociada';
      }).map(function (obj, index) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
          key: 'tooth' + index,
          inline: true,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 578
          },
          __self: this
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
          required: true,
          control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Select"],
          name: obj.index,
          label: "Pieza Dental",
          options: _this6.teethOptions,
          onChange: _this6.handleToothsChange,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 581
          },
          __self: this
        }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", {
          key: 'br' + index,
          className: "jsx-2839058981",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 588
          },
          __self: this
        }), controlOnlyToLast(obj.index, _this6.state.tooths, _this6.addTooth('Asociada'), _this6.removeTooth(obj.index)));
      }) : null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
        inline: true,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 600
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Radio, {
        label: "Con Reabsorci\xF3n",
        name: "op5",
        value: "Con Reabsorci\xF3n",
        checked: this.state.op5 === 'Con Reabsorción',
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 601
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Radio, {
        label: "Sin Reabsorci\xF3n",
        name: "op5",
        value: "Sin Reabsorci\xF3n",
        checked: this.state.op5 === 'Sin Reabsorción',
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 607
        },
        __self: this
      }), this.state.op5 === 'Con Reabsorción' ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
        required: true,
        control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Select"],
        label: "Tipo",
        name: "op5_type",
        options: _configuration_options__WEBPACK_IMPORTED_MODULE_5__["OP5_TYPE"],
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 615
        },
        __self: this
      }) : null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
        inline: true,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 625
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Radio, {
        label: "Con Desplazamiento Piezas Dentarias",
        name: "op6",
        value: "Con Desplazamiento Piezas Dentarias",
        checked: this.state.op6 === 'Con Desplazamiento Piezas Dentarias',
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 626
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Radio, {
        label: "Sin Desplazamiento Piezas Dentarias",
        name: "op6",
        value: "Sin Desplazamiento Piezas Dentarias",
        checked: this.state.op6 === 'Sin Desplazamiento Piezas Dentarias',
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 632
        },
        __self: this
      })), this.state.op6 === 'Con Desplazamiento Piezas Dentarias' ? this.state.tooths.filter(function (t) {
        return t._type === 'Con Desplazamiento Piezas Dentarias';
      }).map(function (obj, index) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
          key: 'tooth' + index,
          inline: true,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 645
          },
          __self: this
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
          required: true,
          control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Select"],
          name: obj.index,
          label: "Pieza Dental",
          options: _this6.teethOptions,
          onChange: _this6.handleToothsChange,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 648
          },
          __self: this
        }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", {
          key: 'br' + index,
          className: "jsx-2839058981",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 655
          },
          __self: this
        }), controlOnlyToLast(obj.index, _this6.state.tooths, _this6.addTooth('Con Desplazamiento Piezas Dentarias'), _this6.removeTooth(obj.index)));
      }) : null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
        inline: true,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 667
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Radio, {
        label: "Con Expansi\xF3n de Corticales",
        name: "op7",
        value: "Con Expansi\xF3n de Corticales",
        checked: this.state.op7 === 'Con Expansión de Corticales',
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 668
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Radio, {
        label: "Sin Expansi\xF3n de Corticales",
        name: "op7",
        value: "Sin Expansi\xF3n de Corticales",
        checked: this.state.op7 === 'Sin Expansión de Corticales',
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 674
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Radio, {
        label: "No aplica",
        name: "op7",
        value: "No aplica",
        checked: this.state.op7 === 'No aplica',
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 680
        },
        __self: this
      })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
        inline: true,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 687
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Radio, {
        label: "Pieza Incluida",
        name: "op8",
        value: "Pieza Incluida",
        checked: this.state.op8 === 'Pieza Incluida',
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 688
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Radio, {
        label: "Pieza No Incluida",
        name: "op8",
        value: "Pieza No Incluida",
        checked: this.state.op8 === 'Pieza No Incluida',
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 694
        },
        __self: this
      })), this.state.op8 === 'Pieza Incluida' ? this.state.tooths.filter(function (t) {
        return t._type === 'Pieza Incluida';
      }).map(function (obj, index) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
          key: 'tooth' + index,
          inline: true,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 706
          },
          __self: this
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
          required: true,
          control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Select"],
          name: obj.index,
          label: "Pieza Dental",
          options: _this6.teethOptions,
          onChange: _this6.handleToothsChange,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 709
          },
          __self: this
        }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", {
          key: 'br' + index,
          className: "jsx-2839058981",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 716
          },
          __self: this
        }), controlOnlyToLast(obj.index, _this6.state.tooths, _this6.addTooth('Pieza Incluida'), _this6.removeTooth(obj.index)));
      }) : null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
        inline: true,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 728
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("label", {
        className: "jsx-2839058981",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 729
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("b", {
        className: "jsx-2839058981",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 729
        },
        __self: this
      }, "Diagn\xF3stico Diferencial")), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
        required: true,
        control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Input"],
        name: "dif1",
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 730
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
        control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Input"],
        name: "dif2",
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 735
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
        control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Input"],
        name: "dif3",
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 739
        },
        __self: this
      })), this.state.error ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Message"], {
        negative: true,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 746
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Message"].Header, {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 747
        },
        __self: this
      }, "Error"), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("p", {
        className: "jsx-2839058981",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 748
        },
        __self: this
      }, "La lesi\xF3n no pudo ser ingresada")) : null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Button"], {
        inverted: true,
        color: "purple",
        content: "Enviar",
        type: "submit",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 751
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Button"], {
        inverted: true,
        color: "grey",
        content: "Cancelar",
        onClick: this.handleClose,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 752
        },
        __self: this
      }))))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a, {
        styleId: "2839058981",
        css: "b.jsx-2839058981,label.jsx-2839058981{color:white;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9ob21lL2Rzb3NhL1Byb2plY3RzL2RlbnQtYXBwL2FwcC9jb21wb25lbnRzL2NyZWF0ZWluanVyeW1vZGFsLmpzeCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFvdkI0QixBQUdxQyxZQUNoQiIsImZpbGUiOiIvaG9tZS9kc29zYS9Qcm9qZWN0cy9kZW50LWFwcC9hcHAvY29tcG9uZW50cy9jcmVhdGVpbmp1cnltb2RhbC5qc3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7XG4gICAgRm9ybSxcbiAgICBCdXR0b24sXG4gICAgTW9kYWwsXG4gICAgSW5wdXQsXG4gICAgU2VsZWN0LFxuICAgIFNlZ21lbnQsXG4gICAgSWNvbixcbiAgICBDaGVja2JveCxcbiAgICBNZXNzYWdlXG59IGZyb20gJ3NlbWFudGljLXVpLXJlYWN0J1xuaW1wb3J0IENTUyBmcm9tICcuL2NzcydcbmltcG9ydCB7IHJhbmdlIH0gZnJvbSAnLi4vdXRpbHMvZnVuY3Rpb25zJ1xuaW1wb3J0IHtcbiAgICBERUZBVUxUX0xPQ0FUSU9OLCBERUZBVUxUX1RPT1RILFxuICAgIFJFR0lTVEVSLCBHRU5ERVIsIF9UWVBFLFxuICAgIEZPUk0sIE9QMywgTE9DQVRJT04sIFBPU0lUSU9OLFxuICAgIE1BTkRJQlVMQV9CUkFOQ0gsIE9QNV9UWVBFLCBTSU5VU19NQVhJTEFSX1dBTExcbn0gZnJvbSAnLi4vY29uZmlndXJhdGlvbi9vcHRpb25zJ1xuXG5jb25zdCBERUZBVUxUX0lOSVRfU1RBVEUgPSB7XG4gICAgJ21vZGFsT3Blbic6IGZhbHNlLFxuICAgICdsb2NhdGlvbnMnOiBbeyAuLi5ERUZBVUxUX0xPQ0FUSU9OIH1dLFxuICAgICd0b290aHMnOiBbXSxcbiAgICAnZXJyb3InOiBudWxsLFxuICAgICduYW1lJzogbnVsbCxcbiAgICAnbGFzdG5hbWUnOiBudWxsLFxuICAgICdyZWdpc3Rlcic6IG51bGwsXG4gICAgJ3JlZ2lzdGVyX251bSc6IG51bGwsXG4gICAgJ2dlbmRlcic6IG51bGwsXG4gICAgJ2FnZSc6IG51bGwsXG4gICAgJ190eXBlJzogbnVsbCxcbiAgICAnb3AxJzogbnVsbCxcbiAgICAnb3AyJzogbnVsbCxcbiAgICAnZm9ybSc6IG51bGwsXG4gICAgJ29wMyc6IG51bGwsXG4gICAgJ3NpemVfMCc6IG51bGwsXG4gICAgJ3NpemVfMSc6IG51bGwsXG4gICAgJ3NpemVfMic6IG51bGwsXG4gICAgJ29wNCc6IG51bGwsXG4gICAgJ29wNSc6IG51bGwsXG4gICAgJ29wNV90eXBlJzogbnVsbCxcbiAgICAnb3A2JzogbnVsbCxcbiAgICAnb3A3JzogbnVsbCxcbiAgICAnb3A4JzogbnVsbCxcbiAgICAnZGlmMSc6IG51bGwsXG4gICAgJ2RpZjInOiBudWxsLFxuICAgICdkaWYzJzogbnVsbCxcbn1cblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgQ3JlYXRlSW5qdXJ5TW9kYWwgZXh0ZW5kcyBDb21wb25lbnQge1xuICAgIHRlZXRoT3B0aW9ucyA9IFtdXG5cbiAgICBjb25zdHJ1Y3Rvcihwcm9wcyl7XG4gICAgICAgIHN1cGVyKHByb3BzKVxuXG4gICAgICAgIHRoaXMuc3RhdGUgPSBPYmplY3QuYXNzaWduKHt9LCBERUZBVUxUX0lOSVRfU1RBVEUpXG5cbiAgICAgICAgdGhpcy50ZWV0aE9wdGlvbnMgPSB0aGlzLmluaXRUZWV0aE9wdGlvbnMoKVxuXG4gICAgICAgIHRoaXMuaGFuZGxlT3BlbiA9IHRoaXMuaGFuZGxlT3Blbi5iaW5kKHRoaXMpXG4gICAgICAgIHRoaXMuaGFuZGxlQ2xvc2UgPSB0aGlzLmhhbmRsZUNsb3NlLmJpbmQodGhpcylcbiAgICAgICAgdGhpcy5oYW5kbGVTdWJtaXQgPSB0aGlzLmhhbmRsZVN1Ym1pdC5iaW5kKHRoaXMpXG4gICAgICAgIHRoaXMuaGFuZGxlQ2hhbmdlID0gdGhpcy5oYW5kbGVDaGFuZ2UuYmluZCh0aGlzKVxuICAgICAgICB0aGlzLmhhbmRsZUJyYW5jaENoYW5nZSA9IHRoaXMuaGFuZGxlQnJhbmNoQ2hhbmdlLmJpbmQodGhpcylcbiAgICAgICAgdGhpcy5oYW5kbGVCb2R5Q2hhbmdlID0gdGhpcy5oYW5kbGVCb2R5Q2hhbmdlLmJpbmQodGhpcylcbiAgICAgICAgdGhpcy5oYW5kbGVTaW51c0NoYW5nZSA9IHRoaXMuaGFuZGxlU2ludXNDaGFuZ2UuYmluZCh0aGlzKVxuICAgICAgICB0aGlzLmhhbmRsZVdhbGxDaGFuZ2UgPSB0aGlzLmhhbmRsZVdhbGxDaGFuZ2UuYmluZCh0aGlzKVxuICAgIH1cblxuICAgIGluaXRUZWV0aE9wdGlvbnMoKXtcbiAgICAgICAgY29uc3QgdGVldGhSYW5nZSA9IHJhbmdlKDEsIDMyKS5tYXAoXG4gICAgICAgICAgICBudW1iZXIgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IG51bWJlclN0cmluZyA9IG51bWJlci50b1N0cmluZygpXG4gICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgJ2tleSc6IG51bWJlclN0cmluZyxcbiAgICAgICAgICAgICAgICAgICAgJ3ZhbHVlJzogbnVtYmVyU3RyaW5nLFxuICAgICAgICAgICAgICAgICAgICAndGV4dCc6IG51bWJlclN0cmluZ1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgKVxuXG4gICAgICAgIHJldHVybiBbXG4gICAgICAgICAgICAuLi50ZWV0aFJhbmdlLFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICdrZXknOiAnc3AnLFxuICAgICAgICAgICAgICAgICd2YWx1ZSc6ICdTdXBlciBOdW1lcmFyaWEnLFxuICAgICAgICAgICAgICAgICd0ZXh0JzogJ1N1cGVyIE51bWVyYXJpYSdcbiAgICAgICAgICAgIH1cbiAgICAgICAgXVxuICAgIH1cblxuICAgIGhhbmRsZU9wZW4oKXtcbiAgICAgICAgdGhpcy5zZXRTdGF0ZSh7Li4uREVGQVVMVF9JTklUX1NUQVRFfSlcbiAgICAgICAgdGhpcy5zZXRTdGF0ZSh7ICdsb2NhdGlvbnMnOiBbeyAuLi5ERUZBVUxUX0xPQ0FUSU9OIH1dIH0pXG4gICAgICAgIHRoaXMuc2V0U3RhdGUoeyAnbW9kYWxPcGVuJzogdHJ1ZSB9KVxuICAgIH1cblxuICAgIGhhbmRsZUNsb3NlKCl7XG4gICAgICAgIHRoaXMuc2V0U3RhdGUoeyAnbW9kYWxPcGVuJzogZmFsc2UgfSlcbiAgICB9XG5cbiAgICBoYW5kbGVDaGFuZ2UgPSAoZSwgeyBuYW1lLCB2YWx1ZSwgY2hlY2tlZCB9KSA9PiB7XG4gICAgICAgIGNvbnNvbGUubG9nKCdoYW5kbGVDaGFuZ2UnKVxuICAgICAgICBjb25zb2xlLmxvZyhgJHtuYW1lfSAke3ZhbHVlfSAke2NoZWNrZWR9YClcbiAgICAgICAgaWYgKHZhbHVlID09PSB1bmRlZmluZWQgJiYgY2hlY2tlZCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICB2YWx1ZSA9IGNoZWNrZWRcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChuYW1lID09PSAnb3A0JyAmJiB2YWx1ZSA9PT0gJ0Fzb2NpYWRhJykge1xuICAgICAgICAgICAgdGhpcy5jaGVja1Rvb3RoKHZhbHVlKVxuICAgICAgICB9IGVsc2UgaWYgKG5hbWUgPT09ICdvcDQnICYmIHZhbHVlID09PSAnTm8gQXNvY2lhZG8nKSB7XG4gICAgICAgICAgICB0aGlzLnJlbW92ZVRvb3RoQnlUeXBlKCdBc29jaWFkYScpXG4gICAgICAgIH0gZWxzZSBpZiAobmFtZSA9PT0gJ29wNicgJiYgdmFsdWUgPT09ICdDb24gRGVzcGxhemFtaWVudG8gUGllemFzIERlbnRhcmlhcycpIHtcbiAgICAgICAgICAgIHRoaXMuY2hlY2tUb290aCh2YWx1ZSlcbiAgICAgICAgfSBlbHNlIGlmIChuYW1lID09PSAnb3A2JyAmJiB2YWx1ZSA9PT0gJ1NpbiBEZXNwbGF6YW1pZW50byBQaWV6YXMgRGVudGFyaWFzJykge1xuICAgICAgICAgICAgdGhpcy5yZW1vdmVUb290aEJ5VHlwZSgnQ29uIERlc3BsYXphbWllbnRvIFBpZXphcyBEZW50YXJpYXMnKVxuICAgICAgICB9IGVsc2UgaWYgKG5hbWUgPT09ICdvcDgnICYmIHZhbHVlID09PSAnUGllemEgSW5jbHVpZGEnKSB7XG4gICAgICAgICAgICB0aGlzLmNoZWNrVG9vdGgodmFsdWUpXG4gICAgICAgIH0gZWxzZSBpZiAobmFtZSA9PT0gJ29wOCcgJiYgdmFsdWUgPT09ICdQaWV6YSBObyBJbmNsdWlkYScpIHtcbiAgICAgICAgICAgIHRoaXMucmVtb3ZlVG9vdGhCeVR5cGUoJ1BpZXphIEluY2x1aWRhJylcbiAgICAgICAgfVxuXG4gICAgICAgIHRoaXMuc2V0U3RhdGUoeyBbbmFtZV06IHZhbHVlIH0pXG4gICAgfVxuXG4gICAgaGFuZGxlTG9jYXRpb25DaGFuZ2UgPSAoZSwgeyBuYW1lLCB2YWx1ZSB9KSA9PiB7XG4gICAgICAgIGlmKG5hbWUgPD0gdGhpcy5zdGF0ZS5sb2NhdGlvbnMubGVuZ3RoIC0gMSl7XG4gICAgICAgICAgICBsZXQgbG9jYXRpb25zID0gdGhpcy5zdGF0ZS5sb2NhdGlvbnNcblxuICAgICAgICAgICAgbG9jYXRpb25zW25hbWVdWydsb2NhdGlvbiddID0gdmFsdWVbJ25hbWUnXVxuICAgICAgICAgICAgbG9jYXRpb25zW25hbWVdWydfdHlwZSddID0gdmFsdWVbJ3R5cGUnXVxuICAgICAgICAgICAgbG9jYXRpb25zW25hbWVdWydib2R5X21hbmRpYnVsYSddID0gZmFsc2VcbiAgICAgICAgICAgIGxvY2F0aW9uc1tuYW1lXVsnc2ludXNfbWF4aWxhciddID0gZmFsc2VcblxuICAgICAgICAgICAgdGhpcy5zZXRTdGF0ZSh7ICdsb2NhdGlvbnMnOiAgWy4uLmxvY2F0aW9uc10gfSlcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGhhbmRsZVRvb3Roc0NoYW5nZSA9IChlLCB7IG5hbWUsIHZhbHVlIH0pID0+IHtcbiAgICAgICAgaWYobmFtZSA8PSB0aGlzLnN0YXRlLnRvb3Rocy5sZW5ndGggLSAxKXtcbiAgICAgICAgICAgIGxldCB0b290aHMgPSBbLi4udGhpcy5zdGF0ZS50b290aHNdXG5cbiAgICAgICAgICAgIHRvb3Roc1tuYW1lXVsnbG9jYXRpb24nXSA9IHZhbHVlXG5cbiAgICAgICAgICAgIHRoaXMuc2V0U3RhdGUoeyAndG9vdGhzJzogIFsuLi50b290aHNdIH0pXG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBoYW5kbGVQb3NpdGlvbkNoYW5nZSA9IChlLCB7IG5hbWUsIHZhbHVlIH0pID0+IHtcbiAgICAgICAgaWYobmFtZSA8PSB0aGlzLnN0YXRlLmxvY2F0aW9ucy5sZW5ndGggLSAxKXtcbiAgICAgICAgICAgIGxldCBsb2NhdGlvbnMgPSB0aGlzLnN0YXRlLmxvY2F0aW9uc1xuICAgICAgICAgICAgbG9jYXRpb25zW25hbWVdWydwb3NpdGlvbiddID0gdmFsdWVcblxuICAgICAgICAgICAgdGhpcy5zZXRTdGF0ZSh7ICdsb2NhdGlvbnMnOiAgWy4uLmxvY2F0aW9uc10gfSlcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGhhbmRsZUJyYW5jaENoYW5nZSA9IChlLCB7IG5hbWUsICB2YWx1ZSB9KSA9PiB7XG4gICAgICAgIGlmKG5hbWUgPD0gdGhpcy5zdGF0ZS5sb2NhdGlvbnMubGVuZ3RoIC0gMSl7XG4gICAgICAgICAgICBsZXQgbG9jYXRpb25zID0gdGhpcy5zdGF0ZS5sb2NhdGlvbnNcbiAgICAgICAgICAgIGxvY2F0aW9uc1tuYW1lXVsnYnJhbmNoX21hbmRpYnVsYSddID0gdmFsdWVcblxuICAgICAgICAgICAgdGhpcy5zZXRTdGF0ZSh7ICdsb2NhdGlvbnMnOiAgWy4uLmxvY2F0aW9uc10gfSlcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGhhbmRsZVdhbGxDaGFuZ2UgPSAoZSwgeyBuYW1lLCAgdmFsdWUgfSkgPT4ge1xuICAgICAgICBpZihuYW1lIDw9IHRoaXMuc3RhdGUubG9jYXRpb25zLmxlbmd0aCAtIDEpe1xuICAgICAgICAgICAgbGV0IGxvY2F0aW9ucyA9IHRoaXMuc3RhdGUubG9jYXRpb25zXG4gICAgICAgICAgICBsb2NhdGlvbnNbbmFtZV1bJ3NpbnVzX21heGlsYXJfd2FsbCddID0gdmFsdWVcblxuICAgICAgICAgICAgdGhpcy5zZXRTdGF0ZSh7ICdsb2NhdGlvbnMnOiAgWy4uLmxvY2F0aW9uc10gfSlcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGhhbmRsZUJvZHlDaGFuZ2UgPSAoaW5kZXgsIHsgbmFtZSwgY2hlY2tlZCB9KSA9PiB7XG4gICAgICAgIGlmKG5hbWUgPD0gdGhpcy5zdGF0ZS5sb2NhdGlvbnMubGVuZ3RoIC0gMSl7XG4gICAgICAgICAgICBsZXQgbG9jYXRpb25zID0gdGhpcy5zdGF0ZS5sb2NhdGlvbnNcbiAgICAgICAgICAgIGxvY2F0aW9uc1tuYW1lXVsnYm9keV9tYW5kaWJ1bGEnXSA9IGNoZWNrZWRcblxuICAgICAgICAgICAgdGhpcy5zZXRTdGF0ZSh7ICdsb2NhdGlvbnMnOiAgWy4uLmxvY2F0aW9uc10gfSlcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGhhbmRsZVNpbnVzQ2hhbmdlID0gKGluZGV4LCB7IG5hbWUsIGNoZWNrZWQgfSkgPT4ge1xuICAgICAgICBpZihuYW1lIDw9IHRoaXMuc3RhdGUubG9jYXRpb25zLmxlbmd0aCAtIDEpe1xuICAgICAgICAgICAgbGV0IGxvY2F0aW9ucyA9IHRoaXMuc3RhdGUubG9jYXRpb25zXG4gICAgICAgICAgICBsb2NhdGlvbnNbbmFtZV1bJ3NpbnVzX21heGlsYXInXSA9IGNoZWNrZWRcblxuICAgICAgICAgICAgdGhpcy5zZXRTdGF0ZSh7ICdsb2NhdGlvbnMnOiAgWy4uLmxvY2F0aW9uc10gfSlcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGFkZExvY2F0aW9uID0gZSA9PiB7XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgICAgICB0aGlzLnNldFN0YXRlKHN0YXRlID0+ICh7XG4gICAgICAgICAgICAuLi5zdGF0ZSxcbiAgICAgICAgICAgICdsb2NhdGlvbnMnOiBbXG4gICAgICAgICAgICAgICAgLi4uc3RhdGUubG9jYXRpb25zLFxuICAgICAgICAgICAgICAgIHsgLi4uREVGQVVMVF9MT0NBVElPTiB9XG4gICAgICAgICAgICBdXG4gICAgICAgIH0pKVxuICAgIH1cblxuICAgIHJlbW92ZUxvY2F0aW9uID0gZSA9PiB7XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgICAgICB0aGlzLnNldFN0YXRlKHN0YXRlID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGxvY2F0aW9ucyA9IFsgLi4uc3RhdGUubG9jYXRpb25zIF1cbiAgICAgICAgICAgIGxvY2F0aW9ucy5wb3AoKVxuXG4gICAgICAgICAgICBpZihsb2NhdGlvbnMubGVuZ3RoID4gMCl7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgLi4uc3RhdGUsXG4gICAgICAgICAgICAgICAgICAgIGxvY2F0aW9ucyxcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHJldHVybiB7Li4uc3RhdGV9XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pXG4gICAgfVxuXG4gICAgYWRkVG9vdGggPSBjdXJyZW50VHlwZSA9PiBlID0+IHtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgICAgIHRoaXMuc2V0U3RhdGUoc3RhdGUgPT4ge1xuICAgICAgICAgICAgbGV0IG5ld190b290aCA9IE9iamVjdC5hc3NpZ24oe30sIERFRkFVTFRfVE9PVEgpXG4gICAgICAgICAgICBuZXdfdG9vdGhbJ190eXBlJ10gPSBjdXJyZW50VHlwZVxuICAgICAgICAgICAgbmV3X3Rvb3RoWydpbmRleCddID0gc3RhdGUudG9vdGhzLmxlbmd0aFxuXG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIC4uLnN0YXRlLFxuICAgICAgICAgICAgICAgICd0b290aHMnOiBbXG4gICAgICAgICAgICAgICAgICAgIC4uLnN0YXRlLnRvb3RocyxcbiAgICAgICAgICAgICAgICAgICAgeyAuLi5uZXdfdG9vdGggfVxuICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfSlcbiAgICB9XG5cbiAgICByZW1vdmVUb290aCA9IGluZGV4ID0+IGUgPT4ge1xuICAgICAgICBlLnByZXZlbnREZWZhdWx0KClcbiAgICAgICAgdGhpcy5yZW1vdmVUb290aEJ5SW5kZXgoaW5kZXgpXG4gICAgfVxuXG4gICAgaGFuZGxlU3VibWl0KGUpe1xuICAgICAgICBjb25zb2xlLmxvZyhcIioqKioqKioqKioqKioqKioqKlwiKVxuICAgICAgICBjb25zb2xlLmxvZyhlKVxuICAgICAgICBjb25zb2xlLmxvZyhcIioqKioqKioqKioqKioqKioqKlwiKVxuICAgICAgICBlLnRhcmdldC5yZXNldCgpXG4gICAgICAgIGNvbnN0IHRtcF9sb2NhdGlvbnMgPSB0aGlzLnN0YXRlLmxvY2F0aW9uc1xuXG4gICAgICAgIGlmICh0bXBfbG9jYXRpb25zICYmIHRtcF9sb2NhdGlvbnMubGVuZ3RoIDwgMiAmJiB0bXBfbG9jYXRpb25zWzBdID09PSBERUZBVUxUX0xPQ0FUSU9OKXtcbiAgICAgICAgICAgIHRoaXMuc2V0U3RhdGUoJ2xvY2F0aW9ucycsIFtdKVxuICAgICAgICB9XG5cbiAgICAgICAgY29uc29sZS5sb2codGhpcy5zdGF0ZSlcblxuICAgICAgICBmZXRjaCgnaHR0cDovLzEyNy4wLjAuMTo1MDAwL2luanVyeScsIHtcbiAgICAgICAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgICAgICAgICBoZWFkZXJzOiBuZXcgSGVhZGVycyh7XG4gICAgICAgICAgICAgICAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiLFxuICAgICAgICAgICAgICAgICAgICBcIkFjY2VwdFwiOlwiYXBwbGljYXRpb24vanNvblwiXG4gICAgICAgICAgICAgICAgfSksXG4gICAgICAgICAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkodGhpcy5zdGF0ZSlcbiAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5zZXRTdGF0ZSh7Li4uREVGQVVMVF9JTklUX1NUQVRFfSlcbiAgICAgICAgICAgICAgICB0aGlzLmhhbmRsZUNsb3NlKClcbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAuY2F0Y2goKGVycm9yKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5zZXRTdGF0ZSh7IGVycm9yIH0pXG4gICAgICAgICAgICB9KVxuICAgIH1cblxuICAgIGNoZWNrVG9vdGgoY3VycmVudFR5cGUpe1xuICAgICAgICBjb25zdCB0b290aHMgPSB0aGlzLnN0YXRlLnRvb3Rocy5maWx0ZXIoXG4gICAgICAgICAgICB0b290aCA9PiB0b290aC5fdHlwZSA9PT0gY3VycmVudFR5cGVcbiAgICAgICAgKVxuXG4gICAgICAgIGlmICh0b290aHMubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICB0aGlzLnNldFN0YXRlKHN0YXRlID0+IHtcbiAgICAgICAgICAgICAgICBsZXQgbmV3X3Rvb3RoID0gT2JqZWN0LmFzc2lnbih7fSwgREVGQVVMVF9UT09USClcbiAgICAgICAgICAgICAgICBuZXdfdG9vdGhbJ190eXBlJ10gPSBjdXJyZW50VHlwZVxuICAgICAgICAgICAgICAgIG5ld190b290aFsnaW5kZXgnXSA9IHN0YXRlLnRvb3Rocy5sZW5ndGhcbiAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgICAuLi5zdGF0ZSxcbiAgICAgICAgICAgICAgICAgICAgJ3Rvb3Rocyc6IFtcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLnN0YXRlLnRvb3RocyxcbiAgICAgICAgICAgICAgICAgICAgICAgIHsgLi4ubmV3X3Rvb3RoIH1cbiAgICAgICAgICAgICAgICAgICAgXVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pXG4gICAgICAgIH1cbiAgICB9XG5cbiAgICByZW1vdmVUb290aEJ5VHlwZShjdXJyZW50VHlwZSl7XG4gICAgICAgIHRoaXMuc2V0U3RhdGUoc3RhdGUgPT4ge1xuICAgICAgICAgICAgY29uc3QgdG9vdGhzID0gdGhpcy5zdGF0ZS50b290aHMuZmlsdGVyKFxuICAgICAgICAgICAgICAgIHRvb3RoID0+IHRvb3RoLl90eXBlICE9PSBjdXJyZW50VHlwZVxuICAgICAgICAgICAgKVxuXG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIC4uLnN0YXRlLFxuICAgICAgICAgICAgICAgICd0b290aHMnOiB0aGlzLnVwZGF0ZVRvb3Roc0luZGV4KHRvb3RocylcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSlcbiAgICB9XG5cbiAgICByZW1vdmVUb290aEJ5VHlwZUFuZEVtcHR5KGN1cnJlbnRUeXBlLCBjYil7XG4gICAgICAgIHRoaXMuc2V0U3RhdGUoc3RhdGUgPT4ge1xuICAgICAgICAgICAgbGV0IHRvb3RocyA9IHRoaXMuc3RhdGUudG9vdGhzLmZpbHRlcihcbiAgICAgICAgICAgICAgICB0b290aCA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKHRvb3RoLmxvY2F0aW9uKVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdG9vdGguX3R5cGUgIT09IGN1cnJlbnRUeXBlICYmIHRvb3RoLmxvY2F0aW9uID09PSBcIlwiXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgKVxuXG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIC4uLnN0YXRlLFxuICAgICAgICAgICAgICAgICd0b290aHMnOiB0aGlzLnVwZGF0ZVRvb3Roc0luZGV4KHRvb3RocylcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSwgY2IoKSlcbiAgICB9XG5cbiAgICByZW1vdmVUb290aEJ5SW5kZXgoaW5kZXgpIHtcbiAgICAgICAgdGhpcy5zZXRTdGF0ZShzdGF0ZSA9PiB7XG4gICAgICAgICAgICBjb25zdCB0b290aHMgPSB0aGlzLnN0YXRlLnRvb3Rocy5maWx0ZXIoXG4gICAgICAgICAgICAgICAgdG9vdGggPT4gdG9vdGguaW5kZXggIT09IGluZGV4XG4gICAgICAgICAgICApXG5cbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgLi4uc3RhdGUsXG4gICAgICAgICAgICAgICAgJ3Rvb3Rocyc6IHRoaXMudXBkYXRlVG9vdGhzSW5kZXgodG9vdGhzKVxuICAgICAgICAgICAgfVxuICAgICAgICB9KVxuICAgIH1cblxuICAgIHVwZGF0ZVRvb3Roc0luZGV4KHRvb3Rocykge1xuICAgICAgICBjb25zdCBuZXdUb290aHMgPSBbLi4udG9vdGhzLm1hcChcbiAgICAgICAgICAgICh0b290aCwgaW5kZXgpID0+IHsgXG4gICAgICAgICAgICAgICAgdG9vdGguaW5kZXggPSBpbmRleFxuICAgICAgICAgICAgICAgIHJldHVybiB0b290aFxuICAgICAgICAgICAgfVxuICAgICAgICApXVxuXG4gICAgICAgIGNvbnNvbGUubG9nKG5ld1Rvb3RocylcbiAgICAgICAgcmV0dXJuIG5ld1Rvb3Roc1xuICAgIH1cblxuICAgIHJlbmRlcigpe1xuICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgPE1vZGFsXG4gICAgICAgICAgICAgICAgb3Blbj17dGhpcy5zdGF0ZS5tb2RhbE9wZW59XG4gICAgICAgICAgICAgICAgb25DbG9zZT17dGhpcy5oYW5kbGVDbG9zZX1cbiAgICAgICAgICAgICAgICB0cmlnZ2VyPXtcbiAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgaW52ZXJ0ZWRcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPSdwdXJwbGUnXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXt0aGlzLmhhbmRsZU9wZW59PlxuICAgICAgICAgICAgICAgICAgICAgICAgSW5ncmVzYXIgbnVldmEgbGVzacOzblxuICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICB9PlxuICAgICAgICAgICAgICAgIDxTZWdtZW50IGludmVydGVkPlxuICAgICAgICAgICAgICAgIDxNb2RhbC5IZWFkZXJcbiAgICAgICAgICAgICAgICAgICAgYXM9J2gxJ1xuICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBtYXJnaW46IDIgfX0+XG4gICAgICAgICAgICAgICAgICAgIDxiPk51ZXZhIExlc2nDs248L2I+XG4gICAgICAgICAgICAgICAgPC9Nb2RhbC5IZWFkZXI+XG4gICAgICAgICAgICAgICAgPE1vZGFsLkNvbnRlbnQ+XG4gICAgICAgICAgICAgICAgICAgIDxNb2RhbC5EZXNjcmlwdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgPEZvcm0gXG4gICAgICAgICAgICAgICAgICAgICAgICBvblN1Ym1pdD17dGhpcy5oYW5kbGVTdWJtaXR9PlxuICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uR3JvdXAgd2lkdGhzPSdlcXVhbCc+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uRmllbGQgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2w9e0lucHV0fSBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9J05vbWJyZScgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9J25hbWUnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXt0aGlzLmhhbmRsZUNoYW5nZX0vPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkZpZWxkIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZCBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbD17SW5wdXR9IFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD0nQXBlbGxpZG8nIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPSdsYXN0bmFtZSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlQ2hhbmdlfS8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uR3JvdXA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5Hcm91cCB3aWR0aHM9J2VxdWFsJz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5GaWVsZCBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWQgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2w9e1NlbGVjdH0gXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPSdSZWdpc3RybycgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9J3JlZ2lzdGVyJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb25zPXtSRUdJU1RFUn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlQ2hhbmdlfS8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uRmllbGQgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sPXtJbnB1dH0gXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPSdSZWdpc3RybycgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9J3JlZ2lzdGVyX251bScgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9J251bWJlcidcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlQ2hhbmdlfS8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uR3JvdXA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5Hcm91cCB3aWR0aHM9J2VxdWFsJz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5GaWVsZCBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWQgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2w9e1NlbGVjdH0gXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPSdHw6luZXJvJyBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT0nZ2VuZGVyJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb25zPXtHRU5ERVJ9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXt0aGlzLmhhbmRsZUNoYW5nZX0vPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkZpZWxkIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZCBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbD17SW5wdXR9IFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD0nRWRhZCcgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9J2FnZScgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9J251bWJlcidcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlQ2hhbmdlfS8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uR3JvdXA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5GaWVsZCBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZCBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sPXtTZWxlY3R9IFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPSdBc3BlY3RvIEdlbmVyYWwnIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9J190eXBlJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbnM9e19UWVBFfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXt0aGlzLmhhbmRsZUNoYW5nZX0vPlxuICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uR3JvdXAgaW5saW5lPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLlJhZGlvXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPSfDmm5pY2EnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9J29wMSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9J8OabmljYSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17dGhpcy5zdGF0ZS5vcDEgPT09ICfDmm5pY2EnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17dGhpcy5oYW5kbGVDaGFuZ2V9Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5SYWRpb1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD0nTcO6bHRpcGxlJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPSdvcDEnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPSdNw7psdGlwbGUnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3RoaXMuc3RhdGUub3AxID09PSAnTcO6bHRpcGxlJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlQ2hhbmdlfS8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uR3JvdXA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5Hcm91cCBpbmxpbmU+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uUmFkaW9cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9J1VuaWxvY3VsYXInXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9J29wMidcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9J1VuaWxvY3VsYXInXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3RoaXMuc3RhdGUub3AyID09PSAnVW5pbG9jdWxhcid9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXt0aGlzLmhhbmRsZUNoYW5nZX0vPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLlJhZGlvXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPSdNdWx0aWxvY3VsYXInXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9J29wMidcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9J011bHRpbG9jdWxhcidcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17dGhpcy5zdGF0ZS5vcDIgPT09ICdNdWx0aWxvY3VsYXInfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17dGhpcy5oYW5kbGVDaGFuZ2V9Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybS5Hcm91cD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkdyb3VwIGlubGluZT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5GaWVsZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sPXtTZWxlY3R9IFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD0nRm9ybWEnIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPSdmb3JtJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb25zPXtGT1JNfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17dGhpcy5oYW5kbGVDaGFuZ2V9Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5GaWVsZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sPXtTZWxlY3R9IFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD0nQm9yZGVzJyBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT0nb3AzJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb25zPXtPUDN9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXt0aGlzLmhhbmRsZUNoYW5nZX0vPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtLkdyb3VwPlxuICAgICAgICAgICAgICAgICAgICAgICAgeyBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnN0YXRlLmxvY2F0aW9ucy5tYXAoKG9iaiwgaW5kZXgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uR3JvdXBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17J2xvY2F0aW9uJyArIGluZGV4fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaW5saW5lPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uRmllbGRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sPXtTZWxlY3R9ICBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPXtpbmRleH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD0nTG9jYWxpemFjacOzbidcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb25zPXtMT0NBVElPTihpbmRleCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlTG9jYXRpb25DaGFuZ2V9Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkZpZWxkIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2w9e1NlbGVjdH0gIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9e2luZGV4fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPSdQb3NpY2nDs24nXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9ucz17UE9TSVRJT04oaW5kZXgpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXt0aGlzLmhhbmRsZVBvc2l0aW9uQ2hhbmdlfS8+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb2JqLmxvY2F0aW9uID09PSAnTWFuZMOtYnVsYScgP1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5GaWVsZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbD17U2VsZWN0fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9J1JhbWEnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPXtpbmRleH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbnM9e01BTkRJQlVMQV9CUkFOQ0goaW5kZXgpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlQnJhbmNoQ2hhbmdlfS8+IDogbnVsbFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9iai5sb2NhdGlvbiA9PT0gJ01hbmTDrWJ1bGEnID9cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uRmllbGRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2w9e0NoZWNrYm94fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9J0N1ZXJwbydcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9e2luZGV4fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlQm9keUNoYW5nZX0vPiA6IG51bGxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvYmoubG9jYXRpb24gPT09ICdNYXhpbGFyJyA/XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkZpZWxkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sPXtDaGVja2JveH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPSdTZW5vIE1heGlsYXInXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPXtpbmRleH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXt0aGlzLmhhbmRsZVNpbnVzQ2hhbmdlfS8+IDogbnVsbFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9iai5zaW51c19tYXhpbGFyID9cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uRmllbGRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2w9e1NlbGVjdH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPSdQYXJlZCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9e2luZGV4fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9ucz17U0lOVVNfTUFYSUxBUl9XQUxMKGluZGV4KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXt0aGlzLmhhbmRsZVdhbGxDaGFuZ2V9Lz4gOiBudWxsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxiciBrZXk9eydicicgKyBpbmRleH0vPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2xPbmx5VG9MYXN0KFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbmRleCwgdGhpcy5zdGF0ZS5sb2NhdGlvbnMsIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmFkZExvY2F0aW9uLCB0aGlzLnJlbW92ZUxvY2F0aW9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uR3JvdXA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSlcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkdyb3VwPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkZpZWxkIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sPXtJbnB1dH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9J0VqZSBNYXlvcicgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9J3NpemVfMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT0nbnVtYmVyJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdGVwPScwLjEnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXt0aGlzLmhhbmRsZUNoYW5nZX0vPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkZpZWxkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2w9e0lucHV0fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD0nRWplIE1lbm9yJyAgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9J3NpemVfMSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT0nbnVtYmVyJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdGVwPScwLjEnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXt0aGlzLmhhbmRsZUNoYW5nZX0vPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkZpZWxkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2w9e0lucHV0fSBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9J0RpYW1ldHJvJyBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT0nc2l6ZV8yJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPSdudW1iZXInXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0ZXA9JzAuMSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlQ2hhbmdlfS8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsPm1tPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybS5Hcm91cD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkdyb3VwIGlubGluZT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5SYWRpb1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD0nQXNvY2lhZGEnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9J29wNCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9J0Fzb2NpYWRhJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXt0aGlzLnN0YXRlLm9wNCA9PT0gJ0Fzb2NpYWRhJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlQ2hhbmdlfS8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uUmFkaW9cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9J05vIEFzb2NpYWRvJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPSdvcDQnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPSdObyBBc29jaWFkbydcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17dGhpcy5zdGF0ZS5vcDQgPT09ICdObyBBc29jaWFkbyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXt0aGlzLmhhbmRsZUNoYW5nZX0vPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtLkdyb3VwPlxuICAgICAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuc3RhdGUub3A0ID09PSAnQXNvY2lhZGEnID8gXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5zdGF0ZS50b290aHMuZmlsdGVyKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ID0+IHQuX3R5cGUgPT09ICdBc29jaWFkYSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApLm1hcCgob2JqLCBpbmRleCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5Hcm91cFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXsndG9vdGgnICsgaW5kZXh9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbmxpbmU+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5GaWVsZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2w9e1NlbGVjdH0gIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9e29iai5pbmRleH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD0nUGllemEgRGVudGFsJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbnM9e3RoaXMudGVldGhPcHRpb25zfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXt0aGlzLmhhbmRsZVRvb3Roc0NoYW5nZX0vPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJyIGtleT17J2JyJyArIGluZGV4fS8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbE9ubHlUb0xhc3QoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9iai5pbmRleCwgdGhpcy5zdGF0ZS50b290aHMsIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmFkZFRvb3RoKCdBc29jaWFkYScpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnJlbW92ZVRvb3RoKG9iai5pbmRleClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybS5Hcm91cD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiBudWxsXG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5Hcm91cCBpbmxpbmU+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uUmFkaW9cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9J0NvbiBSZWFic29yY2nDs24nXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9J29wNSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9J0NvbiBSZWFic29yY2nDs24nXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3RoaXMuc3RhdGUub3A1ID09PSAnQ29uIFJlYWJzb3JjacOzbid9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXt0aGlzLmhhbmRsZUNoYW5nZX0vPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLlJhZGlvXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPSdTaW4gUmVhYnNvcmNpw7NuJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPSdvcDUnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPSdTaW4gUmVhYnNvcmNpw7NuJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXt0aGlzLnN0YXRlLm9wNSA9PT0gJ1NpbiBSZWFic29yY2nDs24nfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17dGhpcy5oYW5kbGVDaGFuZ2V9Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuc3RhdGUub3A1ID09PSAnQ29uIFJlYWJzb3JjacOzbicgPyBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uRmllbGRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbD17U2VsZWN0fSBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPSdUaXBvJyBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9J29wNV90eXBlJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9ucz17T1A1X1RZUEV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17dGhpcy5oYW5kbGVDaGFuZ2V9Lz4gOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBudWxsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtLkdyb3VwPlxuICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uR3JvdXAgaW5saW5lPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLlJhZGlvXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPSdDb24gRGVzcGxhemFtaWVudG8gUGllemFzIERlbnRhcmlhcydcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT0nb3A2J1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT0nQ29uIERlc3BsYXphbWllbnRvIFBpZXphcyBEZW50YXJpYXMnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3RoaXMuc3RhdGUub3A2ID09PSAnQ29uIERlc3BsYXphbWllbnRvIFBpZXphcyBEZW50YXJpYXMnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17dGhpcy5oYW5kbGVDaGFuZ2V9Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5SYWRpb1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD0nU2luIERlc3BsYXphbWllbnRvIFBpZXphcyBEZW50YXJpYXMnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9J29wNidcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9J1NpbiBEZXNwbGF6YW1pZW50byBQaWV6YXMgRGVudGFyaWFzJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXt0aGlzLnN0YXRlLm9wNiA9PT0gJ1NpbiBEZXNwbGF6YW1pZW50byBQaWV6YXMgRGVudGFyaWFzJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlQ2hhbmdlfS8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uR3JvdXA+XG4gICAgICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5zdGF0ZS5vcDYgPT09ICdDb24gRGVzcGxhemFtaWVudG8gUGllemFzIERlbnRhcmlhcycgPyBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnN0YXRlLnRvb3Rocy5maWx0ZXIoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHQgPT4gdC5fdHlwZSA9PT0gJ0NvbiBEZXNwbGF6YW1pZW50byBQaWV6YXMgRGVudGFyaWFzJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkubWFwKChvYmosIGluZGV4KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkdyb3VwXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9eyd0b290aCcgKyBpbmRleH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlubGluZT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkZpZWxkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWQgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbD17U2VsZWN0fSAgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT17b2JqLmluZGV4fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPSdQaWV6YSBEZW50YWwnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9ucz17dGhpcy50ZWV0aE9wdGlvbnN9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlVG9vdGhzQ2hhbmdlfS8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnIga2V5PXsnYnInICsgaW5kZXh9Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sT25seVRvTGFzdChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb2JqLmluZGV4LCB0aGlzLnN0YXRlLnRvb3RocywgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuYWRkVG9vdGgoJ0NvbiBEZXNwbGF6YW1pZW50byBQaWV6YXMgRGVudGFyaWFzJyksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMucmVtb3ZlVG9vdGgob2JqLmluZGV4KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtLkdyb3VwPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IG51bGxcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkdyb3VwIGlubGluZT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5SYWRpb1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD0nQ29uIEV4cGFuc2nDs24gZGUgQ29ydGljYWxlcydcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT0nb3A3J1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT0nQ29uIEV4cGFuc2nDs24gZGUgQ29ydGljYWxlcydcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17dGhpcy5zdGF0ZS5vcDcgPT09ICdDb24gRXhwYW5zacOzbiBkZSBDb3J0aWNhbGVzJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlQ2hhbmdlfS8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uUmFkaW9cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9J1NpbiBFeHBhbnNpw7NuIGRlIENvcnRpY2FsZXMnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9J29wNydcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9J1NpbiBFeHBhbnNpw7NuIGRlIENvcnRpY2FsZXMnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3RoaXMuc3RhdGUub3A3ID09PSAnU2luIEV4cGFuc2nDs24gZGUgQ29ydGljYWxlcyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXt0aGlzLmhhbmRsZUNoYW5nZX0vPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLlJhZGlvXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPSdObyBhcGxpY2EnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9J29wNydcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9J05vIGFwbGljYSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17dGhpcy5zdGF0ZS5vcDcgPT09ICdObyBhcGxpY2EnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17dGhpcy5oYW5kbGVDaGFuZ2V9Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybS5Hcm91cD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkdyb3VwIGlubGluZT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5SYWRpb1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD0nUGllemEgSW5jbHVpZGEnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9J29wOCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9J1BpZXphIEluY2x1aWRhJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXt0aGlzLnN0YXRlLm9wOCA9PT0gJ1BpZXphIEluY2x1aWRhJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlQ2hhbmdlfS8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uUmFkaW9cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9J1BpZXphIE5vIEluY2x1aWRhJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPSdvcDgnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPSdQaWV6YSBObyBJbmNsdWlkYSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17dGhpcy5zdGF0ZS5vcDggPT09ICdQaWV6YSBObyBJbmNsdWlkYSd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXt0aGlzLmhhbmRsZUNoYW5nZX0vPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtLkdyb3VwPlxuICAgICAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuc3RhdGUub3A4ID09PSAnUGllemEgSW5jbHVpZGEnID8gXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5zdGF0ZS50b290aHMuZmlsdGVyKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ID0+IHQuX3R5cGUgPT09ICdQaWV6YSBJbmNsdWlkYSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApLm1hcCgob2JqLCBpbmRleCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5Hcm91cFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXsndG9vdGgnICsgaW5kZXh9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbmxpbmU+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5GaWVsZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2w9e1NlbGVjdH0gIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9e29iai5pbmRleH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD0nUGllemEgRGVudGFsJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbnM9e3RoaXMudGVldGhPcHRpb25zfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXt0aGlzLmhhbmRsZVRvb3Roc0NoYW5nZX0vPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJyIGtleT17J2JyJyArIGluZGV4fS8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbE9ubHlUb0xhc3QoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9iai5pbmRleCwgdGhpcy5zdGF0ZS50b290aHMsIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmFkZFRvb3RoKCdQaWV6YSBJbmNsdWlkYScpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnJlbW92ZVRvb3RoKG9iai5pbmRleClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybS5Hcm91cD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiBudWxsXG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5Hcm91cCBpbmxpbmU+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsPjxiPkRpYWduw7NzdGljbyBEaWZlcmVuY2lhbDwvYj48L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkZpZWxkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sPXtJbnB1dH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT0nZGlmMSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlQ2hhbmdlfS8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uRmllbGRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbD17SW5wdXR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9J2RpZjInXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXt0aGlzLmhhbmRsZUNoYW5nZX0vPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkZpZWxkIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sPXtJbnB1dH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT0nZGlmMydcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlQ2hhbmdlfS8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uR3JvdXA+XG4gICAgICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5zdGF0ZS5lcnJvciA/XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPE1lc3NhZ2UgbmVnYXRpdmU+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxNZXNzYWdlLkhlYWRlcj5FcnJvcjwvTWVzc2FnZS5IZWFkZXI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwPkxhIGxlc2nDs24gbm8gcHVkbyBzZXIgaW5ncmVzYWRhPC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvTWVzc2FnZT4gOiBudWxsXG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uIGludmVydGVkIGNvbG9yPSdwdXJwbGUnIGNvbnRlbnQ9J0VudmlhcicgdHlwZT0nc3VibWl0Jy8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uIGludmVydGVkIGNvbG9yPSdncmV5JyBjb250ZW50PSdDYW5jZWxhcicgb25DbGljaz17dGhpcy5oYW5kbGVDbG9zZX0vPlxuICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtPlxuICAgICAgICAgICAgICAgICAgPC9Nb2RhbC5EZXNjcmlwdGlvbj5cbiAgICAgICAgICAgICAgICA8L01vZGFsLkNvbnRlbnQ+XG4gICAgICAgICAgICAgICAgPC9TZWdtZW50PlxuICAgICAgICAgICAgICAgIDxzdHlsZSBqc3g+e2BcbiAgICAgICAgICAgICAgICAgICAgYiwgbGFiZWwge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6IHdoaXRlO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYH08L3N0eWxlPlxuICAgICAgICAgICAgPC9Nb2RhbD5cbiAgICAgICAgKVxuICAgIH1cbn1cblxuY29uc3QgY29udHJvbE9ubHlUb0xhc3QgPSAoaW5kZXgsIGxpc3QsIGFkZCwgcmVtb3ZlKSA9PiAoXG4gICAgaW5kZXggPT09IGxpc3QubGVuZ3RoIC0gMSA/XG4gICAgPGRpdj5cbiAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgaWNvblxuICAgICAgICAgICAgY29tcGFjdFxuICAgICAgICAgICAgY29sb3I9J2JsdWUnXG4gICAgICAgICAgICBvbkNsaWNrPXthZGR9PlxuICAgICAgICAgICAgPEljb24gbmFtZT0ncGx1cycvPlxuICAgICAgICA8L0J1dHRvbj4gXG4gICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgIGljb25cbiAgICAgICAgICAgIGNvbXBhY3RcbiAgICAgICAgICAgIGNvbG9yPSdyZWQnXG4gICAgICAgICAgICBvbkNsaWNrPXtyZW1vdmV9PlxuICAgICAgICAgICAgPEljb24gbmFtZT0neCcvPlxuICAgICAgICA8L0J1dHRvbj5cbiAgICA8L2Rpdj4gOiBudWxsXG4pIl19 */\n/*@ sourceURL=/home/dsosa/Projects/dent-app/app/components/createinjurymodal.jsx */",
        __self: this
      }));
    }
  }]);

  return CreateInjuryModal;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);



var controlOnlyToLast = function controlOnlyToLast(index, list, add, remove) {
  return index === list.length - 1 ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 769
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Button"], {
    icon: true,
    compact: true,
    color: "blue",
    onClick: add,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 770
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Icon"], {
    name: "plus",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 775
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Button"], {
    icon: true,
    compact: true,
    color: "red",
    onClick: remove,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 777
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Icon"], {
    name: "x",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 782
    },
    __self: this
  }))) : null;
};

/***/ })

})
//# sourceMappingURL=main.js.a9ce66fe5c54c4efa544.hot-update.js.map