webpackHotUpdate("static/development/pages/main.js",{

/***/ "./components/createinjurymodal.jsx":
/*!******************************************!*\
  !*** ./components/createinjurymodal.jsx ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CreateInjuryModal; });
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-jsx/style */ "./node_modules/styled-jsx/style.js");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! semantic-ui-react */ "./node_modules/semantic-ui-react/dist/es/index.js");
/* harmony import */ var _css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./css */ "./components/css.jsx");
/* harmony import */ var _utils_functions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../utils/functions */ "./utils/functions.js");
/* harmony import */ var _configuration_options__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../configuration/options */ "./configuration/options.js");
var _jsxFileName = "/home/dsosa/Projects/dent-app/app/components/createinjurymodal.jsx";



function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






var DEFAULT_INIT_STATE = {
  'modalOpen': false,
  'locations': [_objectSpread({}, _configuration_options__WEBPACK_IMPORTED_MODULE_5__["DEFAULT_LOCATION"])],
  'tooths': [],
  'error': null,
  'name': null,
  'lastname': null,
  'register': null,
  'register_num': null,
  'gender': null,
  'age': null,
  '_type': null,
  'op1': null,
  'op2': null,
  'form': null,
  'op3': null,
  'size_0': null,
  'size_1': null,
  'size_2': null,
  'op4': null,
  'op5': null,
  'op5_type': null,
  'op6': null,
  'op7': null,
  'op8': null,
  'dif1': null,
  'dif2': null,
  'dif3': null
};

var CreateInjuryModal =
/*#__PURE__*/
function (_Component) {
  _inherits(CreateInjuryModal, _Component);

  function CreateInjuryModal(props) {
    var _this;

    _classCallCheck(this, CreateInjuryModal);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(CreateInjuryModal).call(this, props));

    _defineProperty(_assertThisInitialized(_this), "teethOptions", []);

    _defineProperty(_assertThisInitialized(_this), "handleChange", function (e, _ref) {
      var name = _ref.name,
          value = _ref.value,
          checked = _ref.checked;
      console.log('handleChange');
      console.log("".concat(name, " ").concat(value, " ").concat(checked));

      if (value === undefined && checked !== undefined) {
        value = checked;
      }

      if (name === 'op4' && value === 'Asociada') {
        _this.checkTooth(value);
      } else if (name === 'op4' && value === 'No Asociado') {
        _this.removeToothByType('Asociada');
      } else if (name === 'op6' && value === 'Con Desplazamiento Piezas Dentarias') {
        _this.checkTooth(value);
      } else if (name === 'op6' && value === 'Sin Desplazamiento Piezas Dentarias') {
        _this.removeToothByType('Con Desplazamiento Piezas Dentarias');
      } else if (name === 'op8' && value === 'Pieza Incluida') {
        _this.checkTooth(value);
      } else if (name === 'op8' && value === 'Pieza No Incluida') {
        _this.removeToothByType('Pieza Incluida');
      }

      _this.setState(_defineProperty({}, name, value));
    });

    _defineProperty(_assertThisInitialized(_this), "handleLocationChange", function (e, _ref2) {
      var name = _ref2.name,
          value = _ref2.value;

      if (name <= _this.state.locations.length - 1) {
        var locations = _this.state.locations;
        locations[name]['location'] = value['name'];
        locations[name]['_type'] = value['type'];
        locations[name]['body_mandibula'] = false;
        locations[name]['sinus_maxilar'] = false;

        _this.setState({
          'locations': _toConsumableArray(locations)
        });
      }
    });

    _defineProperty(_assertThisInitialized(_this), "handleToothsChange", function (e, _ref3) {
      var name = _ref3.name,
          value = _ref3.value;

      if (name <= _this.state.tooths.length - 1) {
        var tooths = _toConsumableArray(_this.state.tooths);

        tooths[name]['location'] = value;

        _this.setState({
          'tooths': _toConsumableArray(tooths)
        });
      }
    });

    _defineProperty(_assertThisInitialized(_this), "handlePositionChange", function (e, _ref4) {
      var name = _ref4.name,
          value = _ref4.value;

      if (name <= _this.state.locations.length - 1) {
        var locations = _this.state.locations;
        locations[name]['position'] = value;

        _this.setState({
          'locations': _toConsumableArray(locations)
        });
      }
    });

    _defineProperty(_assertThisInitialized(_this), "handleBranchChange", function (e, _ref5) {
      var name = _ref5.name,
          value = _ref5.value;

      if (name <= _this.state.locations.length - 1) {
        var locations = _this.state.locations;
        locations[name]['branch_mandibula'] = value;

        _this.setState({
          'locations': _toConsumableArray(locations)
        });
      }
    });

    _defineProperty(_assertThisInitialized(_this), "handleWallChange", function (e, _ref6) {
      var name = _ref6.name,
          value = _ref6.value;

      if (name <= _this.state.locations.length - 1) {
        var locations = _this.state.locations;
        locations[name]['sinus_maxilar_wall'] = value;

        _this.setState({
          'locations': _toConsumableArray(locations)
        });
      }
    });

    _defineProperty(_assertThisInitialized(_this), "handleBodyChange", function (index, _ref7) {
      var name = _ref7.name,
          checked = _ref7.checked;

      if (name <= _this.state.locations.length - 1) {
        var locations = _this.state.locations;
        locations[name]['body_mandibula'] = checked;

        _this.setState({
          'locations': _toConsumableArray(locations)
        });
      }
    });

    _defineProperty(_assertThisInitialized(_this), "handleSinusChange", function (index, _ref8) {
      var name = _ref8.name,
          checked = _ref8.checked;

      if (name <= _this.state.locations.length - 1) {
        var locations = _this.state.locations;
        locations[name]['sinus_maxilar'] = checked;

        _this.setState({
          'locations': _toConsumableArray(locations)
        });
      }
    });

    _defineProperty(_assertThisInitialized(_this), "addLocation", function (e) {
      e.preventDefault();

      _this.setState(function (state) {
        return _objectSpread({}, state, {
          'locations': [].concat(_toConsumableArray(state.locations), [_objectSpread({}, _configuration_options__WEBPACK_IMPORTED_MODULE_5__["DEFAULT_LOCATION"])])
        });
      });
    });

    _defineProperty(_assertThisInitialized(_this), "removeLocation", function (e) {
      e.preventDefault();

      _this.setState(function (state) {
        var locations = _toConsumableArray(state.locations);

        locations.pop();

        if (locations.length > 0) {
          return _objectSpread({}, state, {
            locations: locations
          });
        } else {
          return _objectSpread({}, state);
        }
      });
    });

    _defineProperty(_assertThisInitialized(_this), "addTooth", function (currentType) {
      return function (e) {
        e.preventDefault();

        _this.setState(function (state) {
          var new_tooth = Object.assign({}, _configuration_options__WEBPACK_IMPORTED_MODULE_5__["DEFAULT_TOOTH"]);
          new_tooth['_type'] = currentType;
          new_tooth['index'] = state.tooths.length;
          return _objectSpread({}, state, {
            'tooths': [].concat(_toConsumableArray(state.tooths), [_objectSpread({}, new_tooth)])
          });
        });
      };
    });

    _defineProperty(_assertThisInitialized(_this), "removeTooth", function (index) {
      return function (e) {
        e.preventDefault();

        _this.removeToothByIndex(index);
      };
    });

    _this.state = Object.assign({}, DEFAULT_INIT_STATE);
    _this.teethOptions = _this.initTeethOptions();
    _this.handleOpen = _this.handleOpen.bind(_assertThisInitialized(_this));
    _this.handleClose = _this.handleClose.bind(_assertThisInitialized(_this));
    _this.handleSubmit = _this.handleSubmit.bind(_assertThisInitialized(_this));
    _this.handleChange = _this.handleChange.bind(_assertThisInitialized(_this));
    _this.handleBranchChange = _this.handleBranchChange.bind(_assertThisInitialized(_this));
    _this.handleBodyChange = _this.handleBodyChange.bind(_assertThisInitialized(_this));
    _this.handleSinusChange = _this.handleSinusChange.bind(_assertThisInitialized(_this));
    _this.handleWallChange = _this.handleWallChange.bind(_assertThisInitialized(_this));
    return _this;
  }

  _createClass(CreateInjuryModal, [{
    key: "initTeethOptions",
    value: function initTeethOptions() {
      var teethRange = Object(_utils_functions__WEBPACK_IMPORTED_MODULE_4__["range"])(1, 32).map(function (number) {
        var numberString = number.toString();
        return {
          'key': numberString,
          'value': numberString,
          'text': numberString
        };
      });
      return [].concat(_toConsumableArray(teethRange), [{
        'key': 'sp',
        'value': 'Super Numeraria',
        'text': 'Super Numeraria'
      }]);
    }
  }, {
    key: "handleOpen",
    value: function handleOpen() {
      this.setState(_objectSpread({}, DEFAULT_INIT_STATE));
      this.setState({
        'modalOpen': true
      });
    }
  }, {
    key: "handleClose",
    value: function handleClose() {
      this.setState({
        'modalOpen': false
      });
    }
  }, {
    key: "handleSubmit",
    value: function handleSubmit(e) {
      var _this2 = this;

      console.log("******************");
      console.log(e);
      console.log("******************");
      e.target.reset();
      var tmp_locations = this.state.locations;

      if (tmp_locations && tmp_locations.length < 2 && tmp_locations[0] === _configuration_options__WEBPACK_IMPORTED_MODULE_5__["DEFAULT_LOCATION"]) {
        this.setState('locations', []);
      }

      console.log(this.state);
      fetch('http://127.0.0.1:5000/injury', {
        method: 'POST',
        headers: new Headers({
          "Content-Type": "application/json",
          "Accept": "application/json"
        }),
        body: JSON.stringify(this.state)
      }).then(function (response) {
        _this2.setState(_objectSpread({}, DEFAULT_INIT_STATE));

        _this2.handleClose();
      }).catch(function (error) {
        _this2.setState({
          error: error
        });
      });
    }
  }, {
    key: "checkTooth",
    value: function checkTooth(currentType) {
      var tooths = this.state.tooths.filter(function (tooth) {
        return tooth._type === currentType;
      });

      if (tooths.length === 0) {
        this.setState(function (state) {
          var new_tooth = Object.assign({}, _configuration_options__WEBPACK_IMPORTED_MODULE_5__["DEFAULT_TOOTH"]);
          new_tooth['_type'] = currentType;
          new_tooth['index'] = state.tooths.length;
          return _objectSpread({}, state, {
            'tooths': [].concat(_toConsumableArray(state.tooths), [_objectSpread({}, new_tooth)])
          });
        });
      }
    }
  }, {
    key: "removeToothByType",
    value: function removeToothByType(currentType) {
      var _this3 = this;

      this.setState(function (state) {
        var tooths = _this3.state.tooths.filter(function (tooth) {
          return tooth._type !== currentType;
        });

        return _objectSpread({}, state, {
          'tooths': _this3.updateToothsIndex(tooths)
        });
      });
    }
  }, {
    key: "removeToothByTypeAndEmpty",
    value: function removeToothByTypeAndEmpty(currentType, cb) {
      var _this4 = this;

      this.setState(function (state) {
        var tooths = _this4.state.tooths.filter(function (tooth) {
          console.log(tooth.location);
          return tooth._type !== currentType && tooth.location === "";
        });

        return _objectSpread({}, state, {
          'tooths': _this4.updateToothsIndex(tooths)
        });
      }, cb());
    }
  }, {
    key: "removeToothByIndex",
    value: function removeToothByIndex(index) {
      var _this5 = this;

      this.setState(function (state) {
        var tooths = _this5.state.tooths.filter(function (tooth) {
          return tooth.index !== index;
        });

        return _objectSpread({}, state, {
          'tooths': _this5.updateToothsIndex(tooths)
        });
      });
    }
  }, {
    key: "updateToothsIndex",
    value: function updateToothsIndex(tooths) {
      var newTooths = _toConsumableArray(tooths.map(function (tooth, index) {
        tooth.index = index;
        return tooth;
      }));

      console.log(newTooths);
      return newTooths;
    }
  }, {
    key: "render",
    value: function render() {
      var _this6 = this;

      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Modal"], {
        open: this.state.modalOpen,
        onClose: this.handleClose,
        trigger: react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Button"], {
          inverted: true,
          color: "purple",
          onClick: this.handleOpen,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 356
          },
          __self: this
        }, "Ingresar nueva lesi\xF3n"),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 352
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Segment"], {
        inverted: true,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 363
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Modal"].Header, {
        as: "h1",
        style: {
          margin: 2
        },
        __source: {
          fileName: _jsxFileName,
          lineNumber: 364
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("b", {
        className: "jsx-2839058981",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 367
        },
        __self: this
      }, "Nueva Lesi\xF3n")), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Modal"].Content, {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 369
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Modal"].Description, {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 370
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"], {
        onSubmit: this.handleSubmit,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 371
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
        widths: "equal",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 373
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
        required: true,
        control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Input"],
        label: "Nombre",
        name: "name",
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 374
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
        required: true,
        control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Input"],
        label: "Apellido",
        name: "lastname",
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 380
        },
        __self: this
      })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
        widths: "equal",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 387
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
        required: true,
        control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Select"],
        label: "Registro",
        name: "register",
        options: _configuration_options__WEBPACK_IMPORTED_MODULE_5__["REGISTER"],
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 388
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
        required: true,
        control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Input"],
        label: "Registro",
        name: "register_num",
        type: "number",
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 395
        },
        __self: this
      })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
        widths: "equal",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 403
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
        required: true,
        control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Select"],
        label: "G\xE9nero",
        name: "gender",
        options: _configuration_options__WEBPACK_IMPORTED_MODULE_5__["GENDER"],
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 404
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
        required: true,
        control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Input"],
        label: "Edad",
        name: "age",
        type: "number",
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 411
        },
        __self: this
      })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
        required: true,
        control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Select"],
        label: "Aspecto General",
        name: "_type",
        options: _configuration_options__WEBPACK_IMPORTED_MODULE_5__["_TYPE"],
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 419
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
        inline: true,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 426
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Radio, {
        label: "\xDAnica",
        name: "op1",
        value: "\xDAnica",
        checked: this.state.op1 === 'Única',
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 427
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Radio, {
        label: "M\xFAltiple",
        name: "op1",
        value: "M\xFAltiple",
        checked: this.state.op1 === 'Múltiple',
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 433
        },
        __self: this
      })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
        inline: true,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 440
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Radio, {
        label: "Unilocular",
        name: "op2",
        value: "Unilocular",
        checked: this.state.op2 === 'Unilocular',
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 441
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Radio, {
        label: "Multilocular",
        name: "op2",
        value: "Multilocular",
        checked: this.state.op2 === 'Multilocular',
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 447
        },
        __self: this
      })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
        inline: true,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 454
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
        control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Select"],
        label: "Forma",
        name: "form",
        options: _configuration_options__WEBPACK_IMPORTED_MODULE_5__["FORM"],
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 455
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
        control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Select"],
        label: "Bordes",
        name: "op3",
        options: _configuration_options__WEBPACK_IMPORTED_MODULE_5__["OP3"],
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 461
        },
        __self: this
      })), this.state.locations.map(function (obj, index) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
          key: 'location' + index,
          inline: true,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 470
          },
          __self: this
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
          control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Select"],
          name: index,
          label: "Localizaci\xF3n",
          options: Object(_configuration_options__WEBPACK_IMPORTED_MODULE_5__["LOCATION"])(index),
          onChange: _this6.handleLocationChange,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 473
          },
          __self: this
        }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
          control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Select"],
          name: index,
          label: "Posici\xF3n",
          options: Object(_configuration_options__WEBPACK_IMPORTED_MODULE_5__["POSITION"])(index),
          onChange: _this6.handlePositionChange,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 479
          },
          __self: this
        }), obj.location === 'Mandíbula' ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
          control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Select"],
          label: "Rama",
          name: index,
          options: Object(_configuration_options__WEBPACK_IMPORTED_MODULE_5__["MANDIBULA_BRANCH"])(index),
          onChange: _this6.handleBranchChange,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 488
          },
          __self: this
        }) : null, obj.location === 'Mandíbula' ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
          control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Checkbox"],
          label: "Cuerpo",
          name: index,
          onChange: _this6.handleBodyChange,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 498
          },
          __self: this
        }) : null, obj.location === 'Maxilar' ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
          control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Checkbox"],
          label: "Seno Maxilar",
          name: index,
          onChange: _this6.handleSinusChange,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 507
          },
          __self: this
        }) : null, obj.sinus_maxilar ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
          control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Select"],
          label: "Pared",
          name: index,
          options: Object(_configuration_options__WEBPACK_IMPORTED_MODULE_5__["SINUS_MAXILAR_WALL"])(index),
          onChange: _this6.handleWallChange,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 516
          },
          __self: this
        }) : null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", {
          key: 'br' + index,
          className: "jsx-2839058981",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 524
          },
          __self: this
        }), controlOnlyToLast(index, _this6.state.locations, _this6.addLocation, _this6.removeLocation));
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 534
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
        control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Input"],
        label: "Eje Mayor",
        name: "size_0",
        type: "number",
        step: "0.1",
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 535
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
        control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Input"],
        label: "Eje Menor",
        name: "size_1",
        type: "number",
        step: "0.1",
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 542
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
        control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Input"],
        label: "Diametro",
        name: "size_2",
        type: "number",
        step: "0.1",
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 549
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("label", {
        className: "jsx-2839058981",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 556
        },
        __self: this
      }, "mm")), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
        inline: true,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 558
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Radio, {
        label: "Asociada",
        name: "op4",
        value: "Asociada",
        checked: this.state.op4 === 'Asociada',
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 559
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Radio, {
        label: "No Asociado",
        name: "op4",
        value: "No Asociado",
        checked: this.state.op4 === 'No Asociado',
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 565
        },
        __self: this
      })), this.state.op4 === 'Asociada' ? this.state.tooths.filter(function (t) {
        return t._type === 'Asociada';
      }).map(function (obj, index) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
          key: 'tooth' + index,
          inline: true,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 577
          },
          __self: this
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
          required: true,
          control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Select"],
          name: obj.index,
          label: "Pieza Dental",
          options: _this6.teethOptions,
          onChange: _this6.handleToothsChange,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 580
          },
          __self: this
        }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", {
          key: 'br' + index,
          className: "jsx-2839058981",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 587
          },
          __self: this
        }), controlOnlyToLast(obj.index, _this6.state.tooths, _this6.addTooth('Asociada'), _this6.removeTooth(obj.index)));
      }) : null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
        inline: true,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 599
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Radio, {
        label: "Con Reabsorci\xF3n",
        name: "op5",
        value: "Con Reabsorci\xF3n",
        checked: this.state.op5 === 'Con Reabsorción',
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 600
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Radio, {
        label: "Sin Reabsorci\xF3n",
        name: "op5",
        value: "Sin Reabsorci\xF3n",
        checked: this.state.op5 === 'Sin Reabsorción',
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 606
        },
        __self: this
      }), this.state.op5 === 'Con Reabsorción' ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
        required: true,
        control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Select"],
        label: "Tipo",
        name: "op5_type",
        options: _configuration_options__WEBPACK_IMPORTED_MODULE_5__["OP5_TYPE"],
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 614
        },
        __self: this
      }) : null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
        inline: true,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 624
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Radio, {
        label: "Con Desplazamiento Piezas Dentarias",
        name: "op6",
        value: "Con Desplazamiento Piezas Dentarias",
        checked: this.state.op6 === 'Con Desplazamiento Piezas Dentarias',
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 625
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Radio, {
        label: "Sin Desplazamiento Piezas Dentarias",
        name: "op6",
        value: "Sin Desplazamiento Piezas Dentarias",
        checked: this.state.op6 === 'Sin Desplazamiento Piezas Dentarias',
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 631
        },
        __self: this
      })), this.state.op6 === 'Con Desplazamiento Piezas Dentarias' ? this.state.tooths.filter(function (t) {
        return t._type === 'Con Desplazamiento Piezas Dentarias';
      }).map(function (obj, index) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
          key: 'tooth' + index,
          inline: true,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 644
          },
          __self: this
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
          required: true,
          control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Select"],
          name: obj.index,
          label: "Pieza Dental",
          options: _this6.teethOptions,
          onChange: _this6.handleToothsChange,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 647
          },
          __self: this
        }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", {
          key: 'br' + index,
          className: "jsx-2839058981",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 654
          },
          __self: this
        }), controlOnlyToLast(obj.index, _this6.state.tooths, _this6.addTooth('Con Desplazamiento Piezas Dentarias'), _this6.removeTooth(obj.index)));
      }) : null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
        inline: true,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 666
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Radio, {
        label: "Con Expansi\xF3n de Corticales",
        name: "op7",
        value: "Con Expansi\xF3n de Corticales",
        checked: this.state.op7 === 'Con Expansión de Corticales',
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 667
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Radio, {
        label: "Sin Expansi\xF3n de Corticales",
        name: "op7",
        value: "Sin Expansi\xF3n de Corticales",
        checked: this.state.op7 === 'Sin Expansión de Corticales',
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 673
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Radio, {
        label: "No aplica",
        name: "op7",
        value: "No aplica",
        checked: this.state.op7 === 'No aplica',
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 679
        },
        __self: this
      })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
        inline: true,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 686
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Radio, {
        label: "Pieza Incluida",
        name: "op8",
        value: "Pieza Incluida",
        checked: this.state.op8 === 'Pieza Incluida',
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 687
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Radio, {
        label: "Pieza No Incluida",
        name: "op8",
        value: "Pieza No Incluida",
        checked: this.state.op8 === 'Pieza No Incluida',
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 693
        },
        __self: this
      })), this.state.op8 === 'Pieza Incluida' ? this.state.tooths.filter(function (t) {
        return t._type === 'Pieza Incluida';
      }).map(function (obj, index) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
          key: 'tooth' + index,
          inline: true,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 705
          },
          __self: this
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
          required: true,
          control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Select"],
          name: obj.index,
          label: "Pieza Dental",
          options: _this6.teethOptions,
          onChange: _this6.handleToothsChange,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 708
          },
          __self: this
        }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", {
          key: 'br' + index,
          className: "jsx-2839058981",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 715
          },
          __self: this
        }), controlOnlyToLast(obj.index, _this6.state.tooths, _this6.addTooth('Pieza Incluida'), _this6.removeTooth(obj.index)));
      }) : null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
        inline: true,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 727
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("label", {
        className: "jsx-2839058981",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 728
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("b", {
        className: "jsx-2839058981",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 728
        },
        __self: this
      }, "Diagn\xF3stico Diferencial")), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
        required: true,
        control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Input"],
        name: "dif1",
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 729
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
        control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Input"],
        name: "dif2",
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 734
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
        control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Input"],
        name: "dif3",
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 738
        },
        __self: this
      })), this.state.error ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Message"], {
        negative: true,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 745
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Message"].Header, {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 746
        },
        __self: this
      }, "Error"), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("p", {
        className: "jsx-2839058981",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 747
        },
        __self: this
      }, "La lesi\xF3n no pudo ser ingresada")) : null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Button"], {
        inverted: true,
        color: "purple",
        content: "Enviar",
        type: "submit",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 750
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Button"], {
        inverted: true,
        color: "grey",
        content: "Cancelar",
        onClick: this.handleClose,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 751
        },
        __self: this
      }))))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a, {
        styleId: "2839058981",
        css: "b.jsx-2839058981,label.jsx-2839058981{color:white;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9ob21lL2Rzb3NhL1Byb2plY3RzL2RlbnQtYXBwL2FwcC9jb21wb25lbnRzL2NyZWF0ZWluanVyeW1vZGFsLmpzeCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFtdkI0QixBQUdxQyxZQUNoQiIsImZpbGUiOiIvaG9tZS9kc29zYS9Qcm9qZWN0cy9kZW50LWFwcC9hcHAvY29tcG9uZW50cy9jcmVhdGVpbmp1cnltb2RhbC5qc3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7XG4gICAgRm9ybSxcbiAgICBCdXR0b24sXG4gICAgTW9kYWwsXG4gICAgSW5wdXQsXG4gICAgU2VsZWN0LFxuICAgIFNlZ21lbnQsXG4gICAgSWNvbixcbiAgICBDaGVja2JveCxcbiAgICBNZXNzYWdlXG59IGZyb20gJ3NlbWFudGljLXVpLXJlYWN0J1xuaW1wb3J0IENTUyBmcm9tICcuL2NzcydcbmltcG9ydCB7IHJhbmdlIH0gZnJvbSAnLi4vdXRpbHMvZnVuY3Rpb25zJ1xuaW1wb3J0IHtcbiAgICBERUZBVUxUX0xPQ0FUSU9OLCBERUZBVUxUX1RPT1RILFxuICAgIFJFR0lTVEVSLCBHRU5ERVIsIF9UWVBFLFxuICAgIEZPUk0sIE9QMywgTE9DQVRJT04sIFBPU0lUSU9OLFxuICAgIE1BTkRJQlVMQV9CUkFOQ0gsIE9QNV9UWVBFLCBTSU5VU19NQVhJTEFSX1dBTExcbn0gZnJvbSAnLi4vY29uZmlndXJhdGlvbi9vcHRpb25zJ1xuXG5jb25zdCBERUZBVUxUX0lOSVRfU1RBVEUgPSB7XG4gICAgJ21vZGFsT3Blbic6IGZhbHNlLFxuICAgICdsb2NhdGlvbnMnOiBbeyAuLi5ERUZBVUxUX0xPQ0FUSU9OIH1dLFxuICAgICd0b290aHMnOiBbXSxcbiAgICAnZXJyb3InOiBudWxsLFxuICAgICduYW1lJzogbnVsbCxcbiAgICAnbGFzdG5hbWUnOiBudWxsLFxuICAgICdyZWdpc3Rlcic6IG51bGwsXG4gICAgJ3JlZ2lzdGVyX251bSc6IG51bGwsXG4gICAgJ2dlbmRlcic6IG51bGwsXG4gICAgJ2FnZSc6IG51bGwsXG4gICAgJ190eXBlJzogbnVsbCxcbiAgICAnb3AxJzogbnVsbCxcbiAgICAnb3AyJzogbnVsbCxcbiAgICAnZm9ybSc6IG51bGwsXG4gICAgJ29wMyc6IG51bGwsXG4gICAgJ3NpemVfMCc6IG51bGwsXG4gICAgJ3NpemVfMSc6IG51bGwsXG4gICAgJ3NpemVfMic6IG51bGwsXG4gICAgJ29wNCc6IG51bGwsXG4gICAgJ29wNSc6IG51bGwsXG4gICAgJ29wNV90eXBlJzogbnVsbCxcbiAgICAnb3A2JzogbnVsbCxcbiAgICAnb3A3JzogbnVsbCxcbiAgICAnb3A4JzogbnVsbCxcbiAgICAnZGlmMSc6IG51bGwsXG4gICAgJ2RpZjInOiBudWxsLFxuICAgICdkaWYzJzogbnVsbCxcbn1cblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgQ3JlYXRlSW5qdXJ5TW9kYWwgZXh0ZW5kcyBDb21wb25lbnQge1xuICAgIHRlZXRoT3B0aW9ucyA9IFtdXG5cbiAgICBjb25zdHJ1Y3Rvcihwcm9wcyl7XG4gICAgICAgIHN1cGVyKHByb3BzKVxuXG4gICAgICAgIHRoaXMuc3RhdGUgPSBPYmplY3QuYXNzaWduKHt9LCBERUZBVUxUX0lOSVRfU1RBVEUpXG5cbiAgICAgICAgdGhpcy50ZWV0aE9wdGlvbnMgPSB0aGlzLmluaXRUZWV0aE9wdGlvbnMoKVxuXG4gICAgICAgIHRoaXMuaGFuZGxlT3BlbiA9IHRoaXMuaGFuZGxlT3Blbi5iaW5kKHRoaXMpXG4gICAgICAgIHRoaXMuaGFuZGxlQ2xvc2UgPSB0aGlzLmhhbmRsZUNsb3NlLmJpbmQodGhpcylcbiAgICAgICAgdGhpcy5oYW5kbGVTdWJtaXQgPSB0aGlzLmhhbmRsZVN1Ym1pdC5iaW5kKHRoaXMpXG4gICAgICAgIHRoaXMuaGFuZGxlQ2hhbmdlID0gdGhpcy5oYW5kbGVDaGFuZ2UuYmluZCh0aGlzKVxuICAgICAgICB0aGlzLmhhbmRsZUJyYW5jaENoYW5nZSA9IHRoaXMuaGFuZGxlQnJhbmNoQ2hhbmdlLmJpbmQodGhpcylcbiAgICAgICAgdGhpcy5oYW5kbGVCb2R5Q2hhbmdlID0gdGhpcy5oYW5kbGVCb2R5Q2hhbmdlLmJpbmQodGhpcylcbiAgICAgICAgdGhpcy5oYW5kbGVTaW51c0NoYW5nZSA9IHRoaXMuaGFuZGxlU2ludXNDaGFuZ2UuYmluZCh0aGlzKVxuICAgICAgICB0aGlzLmhhbmRsZVdhbGxDaGFuZ2UgPSB0aGlzLmhhbmRsZVdhbGxDaGFuZ2UuYmluZCh0aGlzKVxuICAgIH1cblxuICAgIGluaXRUZWV0aE9wdGlvbnMoKXtcbiAgICAgICAgY29uc3QgdGVldGhSYW5nZSA9IHJhbmdlKDEsIDMyKS5tYXAoXG4gICAgICAgICAgICBudW1iZXIgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IG51bWJlclN0cmluZyA9IG51bWJlci50b1N0cmluZygpXG4gICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgJ2tleSc6IG51bWJlclN0cmluZyxcbiAgICAgICAgICAgICAgICAgICAgJ3ZhbHVlJzogbnVtYmVyU3RyaW5nLFxuICAgICAgICAgICAgICAgICAgICAndGV4dCc6IG51bWJlclN0cmluZ1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgKVxuXG4gICAgICAgIHJldHVybiBbXG4gICAgICAgICAgICAuLi50ZWV0aFJhbmdlLFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICdrZXknOiAnc3AnLFxuICAgICAgICAgICAgICAgICd2YWx1ZSc6ICdTdXBlciBOdW1lcmFyaWEnLFxuICAgICAgICAgICAgICAgICd0ZXh0JzogJ1N1cGVyIE51bWVyYXJpYSdcbiAgICAgICAgICAgIH1cbiAgICAgICAgXVxuICAgIH1cblxuICAgIGhhbmRsZU9wZW4oKXtcbiAgICAgICAgdGhpcy5zZXRTdGF0ZSh7Li4uREVGQVVMVF9JTklUX1NUQVRFfSlcbiAgICAgICAgdGhpcy5zZXRTdGF0ZSh7ICdtb2RhbE9wZW4nOiB0cnVlIH0pXG4gICAgfVxuXG4gICAgaGFuZGxlQ2xvc2UoKXtcbiAgICAgICAgdGhpcy5zZXRTdGF0ZSh7ICdtb2RhbE9wZW4nOiBmYWxzZSB9KVxuICAgIH1cblxuICAgIGhhbmRsZUNoYW5nZSA9IChlLCB7IG5hbWUsIHZhbHVlLCBjaGVja2VkIH0pID0+IHtcbiAgICAgICAgY29uc29sZS5sb2coJ2hhbmRsZUNoYW5nZScpXG4gICAgICAgIGNvbnNvbGUubG9nKGAke25hbWV9ICR7dmFsdWV9ICR7Y2hlY2tlZH1gKVxuICAgICAgICBpZiAodmFsdWUgPT09IHVuZGVmaW5lZCAmJiBjaGVja2VkICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIHZhbHVlID0gY2hlY2tlZFxuICAgICAgICB9XG5cbiAgICAgICAgaWYgKG5hbWUgPT09ICdvcDQnICYmIHZhbHVlID09PSAnQXNvY2lhZGEnKSB7XG4gICAgICAgICAgICB0aGlzLmNoZWNrVG9vdGgodmFsdWUpXG4gICAgICAgIH0gZWxzZSBpZiAobmFtZSA9PT0gJ29wNCcgJiYgdmFsdWUgPT09ICdObyBBc29jaWFkbycpIHtcbiAgICAgICAgICAgIHRoaXMucmVtb3ZlVG9vdGhCeVR5cGUoJ0Fzb2NpYWRhJylcbiAgICAgICAgfSBlbHNlIGlmIChuYW1lID09PSAnb3A2JyAmJiB2YWx1ZSA9PT0gJ0NvbiBEZXNwbGF6YW1pZW50byBQaWV6YXMgRGVudGFyaWFzJykge1xuICAgICAgICAgICAgdGhpcy5jaGVja1Rvb3RoKHZhbHVlKVxuICAgICAgICB9IGVsc2UgaWYgKG5hbWUgPT09ICdvcDYnICYmIHZhbHVlID09PSAnU2luIERlc3BsYXphbWllbnRvIFBpZXphcyBEZW50YXJpYXMnKSB7XG4gICAgICAgICAgICB0aGlzLnJlbW92ZVRvb3RoQnlUeXBlKCdDb24gRGVzcGxhemFtaWVudG8gUGllemFzIERlbnRhcmlhcycpXG4gICAgICAgIH0gZWxzZSBpZiAobmFtZSA9PT0gJ29wOCcgJiYgdmFsdWUgPT09ICdQaWV6YSBJbmNsdWlkYScpIHtcbiAgICAgICAgICAgIHRoaXMuY2hlY2tUb290aCh2YWx1ZSlcbiAgICAgICAgfSBlbHNlIGlmIChuYW1lID09PSAnb3A4JyAmJiB2YWx1ZSA9PT0gJ1BpZXphIE5vIEluY2x1aWRhJykge1xuICAgICAgICAgICAgdGhpcy5yZW1vdmVUb290aEJ5VHlwZSgnUGllemEgSW5jbHVpZGEnKVxuICAgICAgICB9XG5cbiAgICAgICAgdGhpcy5zZXRTdGF0ZSh7IFtuYW1lXTogdmFsdWUgfSlcbiAgICB9XG5cbiAgICBoYW5kbGVMb2NhdGlvbkNoYW5nZSA9IChlLCB7IG5hbWUsIHZhbHVlIH0pID0+IHtcbiAgICAgICAgaWYobmFtZSA8PSB0aGlzLnN0YXRlLmxvY2F0aW9ucy5sZW5ndGggLSAxKXtcbiAgICAgICAgICAgIGxldCBsb2NhdGlvbnMgPSB0aGlzLnN0YXRlLmxvY2F0aW9uc1xuXG4gICAgICAgICAgICBsb2NhdGlvbnNbbmFtZV1bJ2xvY2F0aW9uJ10gPSB2YWx1ZVsnbmFtZSddXG4gICAgICAgICAgICBsb2NhdGlvbnNbbmFtZV1bJ190eXBlJ10gPSB2YWx1ZVsndHlwZSddXG4gICAgICAgICAgICBsb2NhdGlvbnNbbmFtZV1bJ2JvZHlfbWFuZGlidWxhJ10gPSBmYWxzZVxuICAgICAgICAgICAgbG9jYXRpb25zW25hbWVdWydzaW51c19tYXhpbGFyJ10gPSBmYWxzZVxuXG4gICAgICAgICAgICB0aGlzLnNldFN0YXRlKHsgJ2xvY2F0aW9ucyc6ICBbLi4ubG9jYXRpb25zXSB9KVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgaGFuZGxlVG9vdGhzQ2hhbmdlID0gKGUsIHsgbmFtZSwgdmFsdWUgfSkgPT4ge1xuICAgICAgICBpZihuYW1lIDw9IHRoaXMuc3RhdGUudG9vdGhzLmxlbmd0aCAtIDEpe1xuICAgICAgICAgICAgbGV0IHRvb3RocyA9IFsuLi50aGlzLnN0YXRlLnRvb3Roc11cblxuICAgICAgICAgICAgdG9vdGhzW25hbWVdWydsb2NhdGlvbiddID0gdmFsdWVcblxuICAgICAgICAgICAgdGhpcy5zZXRTdGF0ZSh7ICd0b290aHMnOiAgWy4uLnRvb3Roc10gfSlcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGhhbmRsZVBvc2l0aW9uQ2hhbmdlID0gKGUsIHsgbmFtZSwgdmFsdWUgfSkgPT4ge1xuICAgICAgICBpZihuYW1lIDw9IHRoaXMuc3RhdGUubG9jYXRpb25zLmxlbmd0aCAtIDEpe1xuICAgICAgICAgICAgbGV0IGxvY2F0aW9ucyA9IHRoaXMuc3RhdGUubG9jYXRpb25zXG4gICAgICAgICAgICBsb2NhdGlvbnNbbmFtZV1bJ3Bvc2l0aW9uJ10gPSB2YWx1ZVxuXG4gICAgICAgICAgICB0aGlzLnNldFN0YXRlKHsgJ2xvY2F0aW9ucyc6ICBbLi4ubG9jYXRpb25zXSB9KVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgaGFuZGxlQnJhbmNoQ2hhbmdlID0gKGUsIHsgbmFtZSwgIHZhbHVlIH0pID0+IHtcbiAgICAgICAgaWYobmFtZSA8PSB0aGlzLnN0YXRlLmxvY2F0aW9ucy5sZW5ndGggLSAxKXtcbiAgICAgICAgICAgIGxldCBsb2NhdGlvbnMgPSB0aGlzLnN0YXRlLmxvY2F0aW9uc1xuICAgICAgICAgICAgbG9jYXRpb25zW25hbWVdWydicmFuY2hfbWFuZGlidWxhJ10gPSB2YWx1ZVxuXG4gICAgICAgICAgICB0aGlzLnNldFN0YXRlKHsgJ2xvY2F0aW9ucyc6ICBbLi4ubG9jYXRpb25zXSB9KVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgaGFuZGxlV2FsbENoYW5nZSA9IChlLCB7IG5hbWUsICB2YWx1ZSB9KSA9PiB7XG4gICAgICAgIGlmKG5hbWUgPD0gdGhpcy5zdGF0ZS5sb2NhdGlvbnMubGVuZ3RoIC0gMSl7XG4gICAgICAgICAgICBsZXQgbG9jYXRpb25zID0gdGhpcy5zdGF0ZS5sb2NhdGlvbnNcbiAgICAgICAgICAgIGxvY2F0aW9uc1tuYW1lXVsnc2ludXNfbWF4aWxhcl93YWxsJ10gPSB2YWx1ZVxuXG4gICAgICAgICAgICB0aGlzLnNldFN0YXRlKHsgJ2xvY2F0aW9ucyc6ICBbLi4ubG9jYXRpb25zXSB9KVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgaGFuZGxlQm9keUNoYW5nZSA9IChpbmRleCwgeyBuYW1lLCBjaGVja2VkIH0pID0+IHtcbiAgICAgICAgaWYobmFtZSA8PSB0aGlzLnN0YXRlLmxvY2F0aW9ucy5sZW5ndGggLSAxKXtcbiAgICAgICAgICAgIGxldCBsb2NhdGlvbnMgPSB0aGlzLnN0YXRlLmxvY2F0aW9uc1xuICAgICAgICAgICAgbG9jYXRpb25zW25hbWVdWydib2R5X21hbmRpYnVsYSddID0gY2hlY2tlZFxuXG4gICAgICAgICAgICB0aGlzLnNldFN0YXRlKHsgJ2xvY2F0aW9ucyc6ICBbLi4ubG9jYXRpb25zXSB9KVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgaGFuZGxlU2ludXNDaGFuZ2UgPSAoaW5kZXgsIHsgbmFtZSwgY2hlY2tlZCB9KSA9PiB7XG4gICAgICAgIGlmKG5hbWUgPD0gdGhpcy5zdGF0ZS5sb2NhdGlvbnMubGVuZ3RoIC0gMSl7XG4gICAgICAgICAgICBsZXQgbG9jYXRpb25zID0gdGhpcy5zdGF0ZS5sb2NhdGlvbnNcbiAgICAgICAgICAgIGxvY2F0aW9uc1tuYW1lXVsnc2ludXNfbWF4aWxhciddID0gY2hlY2tlZFxuXG4gICAgICAgICAgICB0aGlzLnNldFN0YXRlKHsgJ2xvY2F0aW9ucyc6ICBbLi4ubG9jYXRpb25zXSB9KVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgYWRkTG9jYXRpb24gPSBlID0+IHtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgICAgIHRoaXMuc2V0U3RhdGUoc3RhdGUgPT4gKHtcbiAgICAgICAgICAgIC4uLnN0YXRlLFxuICAgICAgICAgICAgJ2xvY2F0aW9ucyc6IFtcbiAgICAgICAgICAgICAgICAuLi5zdGF0ZS5sb2NhdGlvbnMsXG4gICAgICAgICAgICAgICAgeyAuLi5ERUZBVUxUX0xPQ0FUSU9OIH1cbiAgICAgICAgICAgIF1cbiAgICAgICAgfSkpXG4gICAgfVxuXG4gICAgcmVtb3ZlTG9jYXRpb24gPSBlID0+IHtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgICAgIHRoaXMuc2V0U3RhdGUoc3RhdGUgPT4ge1xuICAgICAgICAgICAgY29uc3QgbG9jYXRpb25zID0gWyAuLi5zdGF0ZS5sb2NhdGlvbnMgXVxuICAgICAgICAgICAgbG9jYXRpb25zLnBvcCgpXG5cbiAgICAgICAgICAgIGlmKGxvY2F0aW9ucy5sZW5ndGggPiAwKXtcbiAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgICAuLi5zdGF0ZSxcbiAgICAgICAgICAgICAgICAgICAgbG9jYXRpb25zLFxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHsuLi5zdGF0ZX1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfSlcbiAgICB9XG5cbiAgICBhZGRUb290aCA9IGN1cnJlbnRUeXBlID0+IGUgPT4ge1xuICAgICAgICBlLnByZXZlbnREZWZhdWx0KClcbiAgICAgICAgdGhpcy5zZXRTdGF0ZShzdGF0ZSA9PiB7XG4gICAgICAgICAgICBsZXQgbmV3X3Rvb3RoID0gT2JqZWN0LmFzc2lnbih7fSwgREVGQVVMVF9UT09USClcbiAgICAgICAgICAgIG5ld190b290aFsnX3R5cGUnXSA9IGN1cnJlbnRUeXBlXG4gICAgICAgICAgICBuZXdfdG9vdGhbJ2luZGV4J10gPSBzdGF0ZS50b290aHMubGVuZ3RoXG5cbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgLi4uc3RhdGUsXG4gICAgICAgICAgICAgICAgJ3Rvb3Rocyc6IFtcbiAgICAgICAgICAgICAgICAgICAgLi4uc3RhdGUudG9vdGhzLFxuICAgICAgICAgICAgICAgICAgICB7IC4uLm5ld190b290aCB9XG4gICAgICAgICAgICAgICAgXVxuICAgICAgICAgICAgfVxuICAgICAgICB9KVxuICAgIH1cblxuICAgIHJlbW92ZVRvb3RoID0gaW5kZXggPT4gZSA9PiB7XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgICAgICB0aGlzLnJlbW92ZVRvb3RoQnlJbmRleChpbmRleClcbiAgICB9XG5cbiAgICBoYW5kbGVTdWJtaXQoZSl7XG4gICAgICAgIGNvbnNvbGUubG9nKFwiKioqKioqKioqKioqKioqKioqXCIpXG4gICAgICAgIGNvbnNvbGUubG9nKGUpXG4gICAgICAgIGNvbnNvbGUubG9nKFwiKioqKioqKioqKioqKioqKioqXCIpXG4gICAgICAgIGUudGFyZ2V0LnJlc2V0KClcbiAgICAgICAgY29uc3QgdG1wX2xvY2F0aW9ucyA9IHRoaXMuc3RhdGUubG9jYXRpb25zXG5cbiAgICAgICAgaWYgKHRtcF9sb2NhdGlvbnMgJiYgdG1wX2xvY2F0aW9ucy5sZW5ndGggPCAyICYmIHRtcF9sb2NhdGlvbnNbMF0gPT09IERFRkFVTFRfTE9DQVRJT04pe1xuICAgICAgICAgICAgdGhpcy5zZXRTdGF0ZSgnbG9jYXRpb25zJywgW10pXG4gICAgICAgIH1cblxuICAgICAgICBjb25zb2xlLmxvZyh0aGlzLnN0YXRlKVxuXG4gICAgICAgIGZldGNoKCdodHRwOi8vMTI3LjAuMC4xOjUwMDAvaW5qdXJ5Jywge1xuICAgICAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICAgICAgICAgIGhlYWRlcnM6IG5ldyBIZWFkZXJzKHtcbiAgICAgICAgICAgICAgICAgICAgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIsXG4gICAgICAgICAgICAgICAgICAgIFwiQWNjZXB0XCI6XCJhcHBsaWNhdGlvbi9qc29uXCJcbiAgICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh0aGlzLnN0YXRlKVxuICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLnNldFN0YXRlKHsuLi5ERUZBVUxUX0lOSVRfU1RBVEV9KVxuICAgICAgICAgICAgICAgIHRoaXMuaGFuZGxlQ2xvc2UoKVxuICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIC5jYXRjaCgoZXJyb3IpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLnNldFN0YXRlKHsgZXJyb3IgfSlcbiAgICAgICAgICAgIH0pXG4gICAgfVxuXG4gICAgY2hlY2tUb290aChjdXJyZW50VHlwZSl7XG4gICAgICAgIGNvbnN0IHRvb3RocyA9IHRoaXMuc3RhdGUudG9vdGhzLmZpbHRlcihcbiAgICAgICAgICAgIHRvb3RoID0+IHRvb3RoLl90eXBlID09PSBjdXJyZW50VHlwZVxuICAgICAgICApXG5cbiAgICAgICAgaWYgKHRvb3Rocy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgIHRoaXMuc2V0U3RhdGUoc3RhdGUgPT4ge1xuICAgICAgICAgICAgICAgIGxldCBuZXdfdG9vdGggPSBPYmplY3QuYXNzaWduKHt9LCBERUZBVUxUX1RPT1RIKVxuICAgICAgICAgICAgICAgIG5ld190b290aFsnX3R5cGUnXSA9IGN1cnJlbnRUeXBlXG4gICAgICAgICAgICAgICAgbmV3X3Rvb3RoWydpbmRleCddID0gc3RhdGUudG9vdGhzLmxlbmd0aFxuICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgIC4uLnN0YXRlLFxuICAgICAgICAgICAgICAgICAgICAndG9vdGhzJzogW1xuICAgICAgICAgICAgICAgICAgICAgICAgLi4uc3RhdGUudG9vdGhzLFxuICAgICAgICAgICAgICAgICAgICAgICAgeyAuLi5uZXdfdG9vdGggfVxuICAgICAgICAgICAgICAgICAgICBdXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSlcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHJlbW92ZVRvb3RoQnlUeXBlKGN1cnJlbnRUeXBlKXtcbiAgICAgICAgdGhpcy5zZXRTdGF0ZShzdGF0ZSA9PiB7XG4gICAgICAgICAgICBjb25zdCB0b290aHMgPSB0aGlzLnN0YXRlLnRvb3Rocy5maWx0ZXIoXG4gICAgICAgICAgICAgICAgdG9vdGggPT4gdG9vdGguX3R5cGUgIT09IGN1cnJlbnRUeXBlXG4gICAgICAgICAgICApXG5cbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgLi4uc3RhdGUsXG4gICAgICAgICAgICAgICAgJ3Rvb3Rocyc6IHRoaXMudXBkYXRlVG9vdGhzSW5kZXgodG9vdGhzKVxuICAgICAgICAgICAgfVxuICAgICAgICB9KVxuICAgIH1cblxuICAgIHJlbW92ZVRvb3RoQnlUeXBlQW5kRW1wdHkoY3VycmVudFR5cGUsIGNiKXtcbiAgICAgICAgdGhpcy5zZXRTdGF0ZShzdGF0ZSA9PiB7XG4gICAgICAgICAgICBsZXQgdG9vdGhzID0gdGhpcy5zdGF0ZS50b290aHMuZmlsdGVyKFxuICAgICAgICAgICAgICAgIHRvb3RoID0+IHtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2codG9vdGgubG9jYXRpb24pXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0b290aC5fdHlwZSAhPT0gY3VycmVudFR5cGUgJiYgdG9vdGgubG9jYXRpb24gPT09IFwiXCJcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICApXG5cbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgLi4uc3RhdGUsXG4gICAgICAgICAgICAgICAgJ3Rvb3Rocyc6IHRoaXMudXBkYXRlVG9vdGhzSW5kZXgodG9vdGhzKVxuICAgICAgICAgICAgfVxuICAgICAgICB9LCBjYigpKVxuICAgIH1cblxuICAgIHJlbW92ZVRvb3RoQnlJbmRleChpbmRleCkge1xuICAgICAgICB0aGlzLnNldFN0YXRlKHN0YXRlID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHRvb3RocyA9IHRoaXMuc3RhdGUudG9vdGhzLmZpbHRlcihcbiAgICAgICAgICAgICAgICB0b290aCA9PiB0b290aC5pbmRleCAhPT0gaW5kZXhcbiAgICAgICAgICAgIClcblxuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAuLi5zdGF0ZSxcbiAgICAgICAgICAgICAgICAndG9vdGhzJzogdGhpcy51cGRhdGVUb290aHNJbmRleCh0b290aHMpXG4gICAgICAgICAgICB9XG4gICAgICAgIH0pXG4gICAgfVxuXG4gICAgdXBkYXRlVG9vdGhzSW5kZXgodG9vdGhzKSB7XG4gICAgICAgIGNvbnN0IG5ld1Rvb3RocyA9IFsuLi50b290aHMubWFwKFxuICAgICAgICAgICAgKHRvb3RoLCBpbmRleCkgPT4geyBcbiAgICAgICAgICAgICAgICB0b290aC5pbmRleCA9IGluZGV4XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRvb3RoXG4gICAgICAgICAgICB9XG4gICAgICAgICldXG5cbiAgICAgICAgY29uc29sZS5sb2cobmV3VG9vdGhzKVxuICAgICAgICByZXR1cm4gbmV3VG9vdGhzXG4gICAgfVxuXG4gICAgcmVuZGVyKCl7XG4gICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICA8TW9kYWxcbiAgICAgICAgICAgICAgICBvcGVuPXt0aGlzLnN0YXRlLm1vZGFsT3Blbn1cbiAgICAgICAgICAgICAgICBvbkNsb3NlPXt0aGlzLmhhbmRsZUNsb3NlfVxuICAgICAgICAgICAgICAgIHRyaWdnZXI9e1xuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICBpbnZlcnRlZFxuICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9J3B1cnBsZSdcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e3RoaXMuaGFuZGxlT3Blbn0+XG4gICAgICAgICAgICAgICAgICAgICAgICBJbmdyZXNhciBudWV2YSBsZXNpw7NuXG4gICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICAgIH0+XG4gICAgICAgICAgICAgICAgPFNlZ21lbnQgaW52ZXJ0ZWQ+XG4gICAgICAgICAgICAgICAgPE1vZGFsLkhlYWRlclxuICAgICAgICAgICAgICAgICAgICBhcz0naDEnXG4gICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IG1hcmdpbjogMiB9fT5cbiAgICAgICAgICAgICAgICAgICAgPGI+TnVldmEgTGVzacOzbjwvYj5cbiAgICAgICAgICAgICAgICA8L01vZGFsLkhlYWRlcj5cbiAgICAgICAgICAgICAgICA8TW9kYWwuQ29udGVudD5cbiAgICAgICAgICAgICAgICAgICAgPE1vZGFsLkRlc2NyaXB0aW9uPlxuICAgICAgICAgICAgICAgICAgICA8Rm9ybSBcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uU3VibWl0PXt0aGlzLmhhbmRsZVN1Ym1pdH0+XG4gICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5Hcm91cCB3aWR0aHM9J2VxdWFsJz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5GaWVsZCBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbD17SW5wdXR9IFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD0nTm9tYnJlJyBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT0nbmFtZSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlQ2hhbmdlfS8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uRmllbGQgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sPXtJbnB1dH0gXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPSdBcGVsbGlkbycgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9J2xhc3RuYW1lJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17dGhpcy5oYW5kbGVDaGFuZ2V9Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybS5Hcm91cD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkdyb3VwIHdpZHRocz0nZXF1YWwnPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkZpZWxkIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZCBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbD17U2VsZWN0fSBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9J1JlZ2lzdHJvJyBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT0ncmVnaXN0ZXInXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbnM9e1JFR0lTVEVSfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17dGhpcy5oYW5kbGVDaGFuZ2V9Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5GaWVsZCBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWQgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2w9e0lucHV0fSBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9J1JlZ2lzdHJvJyBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT0ncmVnaXN0ZXJfbnVtJyBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT0nbnVtYmVyJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17dGhpcy5oYW5kbGVDaGFuZ2V9Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybS5Hcm91cD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkdyb3VwIHdpZHRocz0nZXF1YWwnPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkZpZWxkIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZCBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbD17U2VsZWN0fSBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9J0fDqW5lcm8nIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPSdnZW5kZXInXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbnM9e0dFTkRFUn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlQ2hhbmdlfS8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uRmllbGQgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sPXtJbnB1dH0gXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPSdFZGFkJyBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT0nYWdlJyBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT0nbnVtYmVyJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17dGhpcy5oYW5kbGVDaGFuZ2V9Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybS5Hcm91cD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkZpZWxkIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2w9e1NlbGVjdH0gXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9J0FzcGVjdG8gR2VuZXJhbCcgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT0nX3R5cGUnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9ucz17X1RZUEV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlQ2hhbmdlfS8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5Hcm91cCBpbmxpbmU+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uUmFkaW9cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9J8OabmljYSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT0nb3AxJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT0nw5puaWNhJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXt0aGlzLnN0YXRlLm9wMSA9PT0gJ8OabmljYSd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXt0aGlzLmhhbmRsZUNoYW5nZX0vPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLlJhZGlvXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPSdNw7psdGlwbGUnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9J29wMSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9J03Dumx0aXBsZSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17dGhpcy5zdGF0ZS5vcDEgPT09ICdNw7psdGlwbGUnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17dGhpcy5oYW5kbGVDaGFuZ2V9Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybS5Hcm91cD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkdyb3VwIGlubGluZT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5SYWRpb1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD0nVW5pbG9jdWxhcidcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT0nb3AyJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT0nVW5pbG9jdWxhcidcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17dGhpcy5zdGF0ZS5vcDIgPT09ICdVbmlsb2N1bGFyJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlQ2hhbmdlfS8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uUmFkaW9cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9J011bHRpbG9jdWxhcidcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT0nb3AyJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT0nTXVsdGlsb2N1bGFyJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXt0aGlzLnN0YXRlLm9wMiA9PT0gJ011bHRpbG9jdWxhcid9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXt0aGlzLmhhbmRsZUNoYW5nZX0vPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtLkdyb3VwPlxuICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uR3JvdXAgaW5saW5lPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkZpZWxkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2w9e1NlbGVjdH0gXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPSdGb3JtYScgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9J2Zvcm0nXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbnM9e0ZPUk19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXt0aGlzLmhhbmRsZUNoYW5nZX0vPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkZpZWxkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2w9e1NlbGVjdH0gXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPSdCb3JkZXMnIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPSdvcDMnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbnM9e09QM31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlQ2hhbmdlfS8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uR3JvdXA+XG4gICAgICAgICAgICAgICAgICAgICAgICB7IFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuc3RhdGUubG9jYXRpb25zLm1hcCgob2JqLCBpbmRleCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5Hcm91cFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXsnbG9jYXRpb24nICsgaW5kZXh9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbmxpbmU+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5GaWVsZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2w9e1NlbGVjdH0gIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9e2luZGV4fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPSdMb2NhbGl6YWNpw7NuJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbnM9e0xPQ0FUSU9OKGluZGV4KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17dGhpcy5oYW5kbGVMb2NhdGlvbkNoYW5nZX0vPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uRmllbGQgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbD17U2VsZWN0fSAgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT17aW5kZXh9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9J1Bvc2ljacOzbidcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb25zPXtQT1NJVElPTihpbmRleCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlUG9zaXRpb25DaGFuZ2V9Lz5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvYmoubG9jYXRpb24gPT09ICdNYW5kw61idWxhJyA/XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkZpZWxkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sPXtTZWxlY3R9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD0nUmFtYSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9e2luZGV4fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9ucz17TUFORElCVUxBX0JSQU5DSChpbmRleCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17dGhpcy5oYW5kbGVCcmFuY2hDaGFuZ2V9Lz4gOiBudWxsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb2JqLmxvY2F0aW9uID09PSAnTWFuZMOtYnVsYScgP1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5GaWVsZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbD17Q2hlY2tib3h9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD0nQ3VlcnBvJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT17aW5kZXh9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17dGhpcy5oYW5kbGVCb2R5Q2hhbmdlfS8+IDogbnVsbFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9iai5sb2NhdGlvbiA9PT0gJ01heGlsYXInID9cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uRmllbGRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2w9e0NoZWNrYm94fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9J1Nlbm8gTWF4aWxhcidcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9e2luZGV4fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlU2ludXNDaGFuZ2V9Lz4gOiBudWxsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb2JqLnNpbnVzX21heGlsYXIgP1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5GaWVsZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbD17U2VsZWN0fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9J1BhcmVkJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT17aW5kZXh9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb25zPXtTSU5VU19NQVhJTEFSX1dBTEwoaW5kZXgpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlV2FsbENoYW5nZX0vPiA6IG51bGxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJyIGtleT17J2JyJyArIGluZGV4fS8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbE9ubHlUb0xhc3QoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGluZGV4LCB0aGlzLnN0YXRlLmxvY2F0aW9ucywgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuYWRkTG9jYXRpb24sIHRoaXMucmVtb3ZlTG9jYXRpb25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybS5Hcm91cD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApKVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uR3JvdXA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uRmllbGQgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2w9e0lucHV0fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD0nRWplIE1heW9yJyBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT0nc2l6ZV8wJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPSdudW1iZXInXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0ZXA9JzAuMSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlQ2hhbmdlfS8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uRmllbGRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbD17SW5wdXR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPSdFamUgTWVub3InICBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT0nc2l6ZV8xJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlPSdudW1iZXInXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0ZXA9JzAuMSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlQ2hhbmdlfS8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uRmllbGRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbD17SW5wdXR9IFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD0nRGlhbWV0cm8nIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPSdzaXplXzInXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9J251bWJlcidcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RlcD0nMC4xJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17dGhpcy5oYW5kbGVDaGFuZ2V9Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWw+bW08L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtLkdyb3VwPlxuICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uR3JvdXAgaW5saW5lPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLlJhZGlvXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPSdBc29jaWFkYSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT0nb3A0J1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT0nQXNvY2lhZGEnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3RoaXMuc3RhdGUub3A0ID09PSAnQXNvY2lhZGEnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17dGhpcy5oYW5kbGVDaGFuZ2V9Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5SYWRpb1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD0nTm8gQXNvY2lhZG8nXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9J29wNCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9J05vIEFzb2NpYWRvJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXt0aGlzLnN0YXRlLm9wNCA9PT0gJ05vIEFzb2NpYWRvJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlQ2hhbmdlfS8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uR3JvdXA+XG4gICAgICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5zdGF0ZS5vcDQgPT09ICdBc29jaWFkYScgPyBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnN0YXRlLnRvb3Rocy5maWx0ZXIoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHQgPT4gdC5fdHlwZSA9PT0gJ0Fzb2NpYWRhJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkubWFwKChvYmosIGluZGV4KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkdyb3VwXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9eyd0b290aCcgKyBpbmRleH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlubGluZT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkZpZWxkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWQgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbD17U2VsZWN0fSAgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT17b2JqLmluZGV4fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPSdQaWV6YSBEZW50YWwnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9ucz17dGhpcy50ZWV0aE9wdGlvbnN9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlVG9vdGhzQ2hhbmdlfS8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnIga2V5PXsnYnInICsgaW5kZXh9Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sT25seVRvTGFzdChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb2JqLmluZGV4LCB0aGlzLnN0YXRlLnRvb3RocywgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuYWRkVG9vdGgoJ0Fzb2NpYWRhJyksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMucmVtb3ZlVG9vdGgob2JqLmluZGV4KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtLkdyb3VwPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IG51bGxcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkdyb3VwIGlubGluZT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5SYWRpb1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD0nQ29uIFJlYWJzb3JjacOzbidcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT0nb3A1J1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT0nQ29uIFJlYWJzb3JjacOzbidcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17dGhpcy5zdGF0ZS5vcDUgPT09ICdDb24gUmVhYnNvcmNpw7NuJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlQ2hhbmdlfS8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uUmFkaW9cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9J1NpbiBSZWFic29yY2nDs24nXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9J29wNSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9J1NpbiBSZWFic29yY2nDs24nXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3RoaXMuc3RhdGUub3A1ID09PSAnU2luIFJlYWJzb3JjacOzbid9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXt0aGlzLmhhbmRsZUNoYW5nZX0vPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5zdGF0ZS5vcDUgPT09ICdDb24gUmVhYnNvcmNpw7NuJyA/IFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5GaWVsZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWQgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sPXtTZWxlY3R9IFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9J1RpcG8nIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT0nb3A1X3R5cGUnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb25zPXtPUDVfVFlQRX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXt0aGlzLmhhbmRsZUNoYW5nZX0vPiA6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG51bGxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uR3JvdXA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5Hcm91cCBpbmxpbmU+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uUmFkaW9cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9J0NvbiBEZXNwbGF6YW1pZW50byBQaWV6YXMgRGVudGFyaWFzJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPSdvcDYnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPSdDb24gRGVzcGxhemFtaWVudG8gUGllemFzIERlbnRhcmlhcydcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17dGhpcy5zdGF0ZS5vcDYgPT09ICdDb24gRGVzcGxhemFtaWVudG8gUGllemFzIERlbnRhcmlhcyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXt0aGlzLmhhbmRsZUNoYW5nZX0vPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLlJhZGlvXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPSdTaW4gRGVzcGxhemFtaWVudG8gUGllemFzIERlbnRhcmlhcydcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT0nb3A2J1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT0nU2luIERlc3BsYXphbWllbnRvIFBpZXphcyBEZW50YXJpYXMnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3RoaXMuc3RhdGUub3A2ID09PSAnU2luIERlc3BsYXphbWllbnRvIFBpZXphcyBEZW50YXJpYXMnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17dGhpcy5oYW5kbGVDaGFuZ2V9Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybS5Hcm91cD5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnN0YXRlLm9wNiA9PT0gJ0NvbiBEZXNwbGF6YW1pZW50byBQaWV6YXMgRGVudGFyaWFzJyA/IFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuc3RhdGUudG9vdGhzLmZpbHRlcihcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdCA9PiB0Ll90eXBlID09PSAnQ29uIERlc3BsYXphbWllbnRvIFBpZXphcyBEZW50YXJpYXMnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKS5tYXAoKG9iaiwgaW5kZXgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uR3JvdXBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17J3Rvb3RoJyArIGluZGV4fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaW5saW5lPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uRmllbGRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZCBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sPXtTZWxlY3R9ICBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPXtvYmouaW5kZXh9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9J1BpZXphIERlbnRhbCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb25zPXt0aGlzLnRlZXRoT3B0aW9uc31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17dGhpcy5oYW5kbGVUb290aHNDaGFuZ2V9Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxiciBrZXk9eydicicgKyBpbmRleH0vPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2xPbmx5VG9MYXN0KFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvYmouaW5kZXgsIHRoaXMuc3RhdGUudG9vdGhzLCBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5hZGRUb290aCgnQ29uIERlc3BsYXphbWllbnRvIFBpZXphcyBEZW50YXJpYXMnKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5yZW1vdmVUb290aChvYmouaW5kZXgpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uR3JvdXA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogbnVsbFxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uR3JvdXAgaW5saW5lPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLlJhZGlvXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPSdDb24gRXhwYW5zacOzbiBkZSBDb3J0aWNhbGVzJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPSdvcDcnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPSdDb24gRXhwYW5zacOzbiBkZSBDb3J0aWNhbGVzJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXt0aGlzLnN0YXRlLm9wNyA9PT0gJ0NvbiBFeHBhbnNpw7NuIGRlIENvcnRpY2FsZXMnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17dGhpcy5oYW5kbGVDaGFuZ2V9Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5SYWRpb1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD0nU2luIEV4cGFuc2nDs24gZGUgQ29ydGljYWxlcydcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT0nb3A3J1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT0nU2luIEV4cGFuc2nDs24gZGUgQ29ydGljYWxlcydcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17dGhpcy5zdGF0ZS5vcDcgPT09ICdTaW4gRXhwYW5zacOzbiBkZSBDb3J0aWNhbGVzJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlQ2hhbmdlfS8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uUmFkaW9cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9J05vIGFwbGljYSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT0nb3A3J1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT0nTm8gYXBsaWNhJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXt0aGlzLnN0YXRlLm9wNyA9PT0gJ05vIGFwbGljYSd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXt0aGlzLmhhbmRsZUNoYW5nZX0vPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtLkdyb3VwPlxuICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uR3JvdXAgaW5saW5lPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLlJhZGlvXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPSdQaWV6YSBJbmNsdWlkYSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT0nb3A4J1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT0nUGllemEgSW5jbHVpZGEnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3RoaXMuc3RhdGUub3A4ID09PSAnUGllemEgSW5jbHVpZGEnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17dGhpcy5oYW5kbGVDaGFuZ2V9Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5SYWRpb1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD0nUGllemEgTm8gSW5jbHVpZGEnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9J29wOCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9J1BpZXphIE5vIEluY2x1aWRhJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXt0aGlzLnN0YXRlLm9wOCA9PT0gJ1BpZXphIE5vIEluY2x1aWRhJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlQ2hhbmdlfS8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uR3JvdXA+XG4gICAgICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5zdGF0ZS5vcDggPT09ICdQaWV6YSBJbmNsdWlkYScgPyBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnN0YXRlLnRvb3Rocy5maWx0ZXIoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHQgPT4gdC5fdHlwZSA9PT0gJ1BpZXphIEluY2x1aWRhJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkubWFwKChvYmosIGluZGV4KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkdyb3VwXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9eyd0b290aCcgKyBpbmRleH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlubGluZT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkZpZWxkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWQgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbD17U2VsZWN0fSAgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT17b2JqLmluZGV4fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPSdQaWV6YSBEZW50YWwnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9ucz17dGhpcy50ZWV0aE9wdGlvbnN9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlVG9vdGhzQ2hhbmdlfS8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnIga2V5PXsnYnInICsgaW5kZXh9Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sT25seVRvTGFzdChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb2JqLmluZGV4LCB0aGlzLnN0YXRlLnRvb3RocywgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuYWRkVG9vdGgoJ1BpZXphIEluY2x1aWRhJyksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMucmVtb3ZlVG9vdGgob2JqLmluZGV4KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtLkdyb3VwPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IG51bGxcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkdyb3VwIGlubGluZT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWw+PGI+RGlhZ27Ds3N0aWNvIERpZmVyZW5jaWFsPC9iPjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uRmllbGRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWQgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2w9e0lucHV0fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPSdkaWYxJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17dGhpcy5oYW5kbGVDaGFuZ2V9Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5GaWVsZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sPXtJbnB1dH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT0nZGlmMidcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlQ2hhbmdlfS8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uRmllbGQgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2w9e0lucHV0fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPSdkaWYzJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17dGhpcy5oYW5kbGVDaGFuZ2V9Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybS5Hcm91cD5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnN0YXRlLmVycm9yID9cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TWVzc2FnZSBuZWdhdGl2ZT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPE1lc3NhZ2UuSGVhZGVyPkVycm9yPC9NZXNzYWdlLkhlYWRlcj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHA+TGEgbGVzacOzbiBubyBwdWRvIHNlciBpbmdyZXNhZGE8L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9NZXNzYWdlPiA6IG51bGxcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b24gaW52ZXJ0ZWQgY29sb3I9J3B1cnBsZScgY29udGVudD0nRW52aWFyJyB0eXBlPSdzdWJtaXQnLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b24gaW52ZXJ0ZWQgY29sb3I9J2dyZXknIGNvbnRlbnQ9J0NhbmNlbGFyJyBvbkNsaWNrPXt0aGlzLmhhbmRsZUNsb3NlfS8+XG4gICAgICAgICAgICAgICAgICAgICA8L0Zvcm0+XG4gICAgICAgICAgICAgICAgICA8L01vZGFsLkRlc2NyaXB0aW9uPlxuICAgICAgICAgICAgICAgIDwvTW9kYWwuQ29udGVudD5cbiAgICAgICAgICAgICAgICA8L1NlZ21lbnQ+XG4gICAgICAgICAgICAgICAgPHN0eWxlIGpzeD57YFxuICAgICAgICAgICAgICAgICAgICBiLCBsYWJlbCB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogd2hpdGU7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBgfTwvc3R5bGU+XG4gICAgICAgICAgICA8L01vZGFsPlxuICAgICAgICApXG4gICAgfVxufVxuXG5jb25zdCBjb250cm9sT25seVRvTGFzdCA9IChpbmRleCwgbGlzdCwgYWRkLCByZW1vdmUpID0+IChcbiAgICBpbmRleCA9PT0gbGlzdC5sZW5ndGggLSAxID9cbiAgICA8ZGl2PlxuICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICBpY29uXG4gICAgICAgICAgICBjb21wYWN0XG4gICAgICAgICAgICBjb2xvcj0nYmx1ZSdcbiAgICAgICAgICAgIG9uQ2xpY2s9e2FkZH0+XG4gICAgICAgICAgICA8SWNvbiBuYW1lPSdwbHVzJy8+XG4gICAgICAgIDwvQnV0dG9uPiBcbiAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgaWNvblxuICAgICAgICAgICAgY29tcGFjdFxuICAgICAgICAgICAgY29sb3I9J3JlZCdcbiAgICAgICAgICAgIG9uQ2xpY2s9e3JlbW92ZX0+XG4gICAgICAgICAgICA8SWNvbiBuYW1lPSd4Jy8+XG4gICAgICAgIDwvQnV0dG9uPlxuICAgIDwvZGl2PiA6IG51bGxcbikiXX0= */\n/*@ sourceURL=/home/dsosa/Projects/dent-app/app/components/createinjurymodal.jsx */",
        __self: this
      }));
    }
  }]);

  return CreateInjuryModal;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);



var controlOnlyToLast = function controlOnlyToLast(index, list, add, remove) {
  return index === list.length - 1 ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 768
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Button"], {
    icon: true,
    compact: true,
    color: "blue",
    onClick: add,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 769
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Icon"], {
    name: "plus",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 774
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Button"], {
    icon: true,
    compact: true,
    color: "red",
    onClick: remove,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 776
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Icon"], {
    name: "x",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 781
    },
    __self: this
  }))) : null;
};

/***/ })

})
//# sourceMappingURL=main.js.e1701072d8beb29f2e61.hot-update.js.map