module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 20);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),
/* 1 */
/***/ (function(module, exports) {

module.exports = require("semantic-ui-react");

/***/ }),
/* 2 */
/***/ (function(module, exports) {

module.exports = require("@babel/runtime/regenerator");

/***/ }),
/* 3 */
/***/ (function(module, exports) {

module.exports = require("next/router");

/***/ }),
/* 4 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return DEFAULT_LOCATION; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return DEFAULT_TOOTH; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "l", function() { return REGISTER; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "e", function() { return GENDER; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "n", function() { return _TYPE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return FORM; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "i", function() { return OP3; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "f", function() { return LOCATION; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "k", function() { return POSITION; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "g", function() { return MANDIBULA_BRANCH; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "j", function() { return OP5_TYPE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "m", function() { return SINUS_MAXILAR_WALL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "h", function() { return MENUITEMS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return COLORS; });
var DEFAULT_LOCATION = {
  'location': '',
  'position': '',
  '_type': '',
  'branch_mandibula': null,
  'body_mandibula': false,
  'sinus_maxilar': false,
  'sinus_maxilar_wall': null
};
var DEFAULT_TOOTH = {
  'location': '',
  '_type': ''
};
var REGISTER = [{
  key: 'pi',
  text: 'PI',
  value: 'PI'
}, {
  key: 'pt',
  text: 'PT',
  value: 'PT'
}, {
  key: 'pce',
  text: 'PCE',
  value: 'PCE'
}];
var GENDER = [{
  key: 'm',
  text: 'Hombre',
  value: 'Hombre'
}, {
  key: 'f',
  text: 'Mujer',
  value: 'Mujer'
}];
var _TYPE = [{
  key: 'l',
  text: 'Lucente',
  value: 'Lucente'
}, {
  key: 'o',
  text: 'Opaca',
  value: 'Opaca'
}, {
  key: 'm',
  text: 'Mixta',
  value: 'Mixta'
}];
var FORM = [{
  key: 'c',
  text: 'Circular',
  value: 'Circular'
}, {
  key: 'o',
  text: 'Ovalada',
  value: 'Ovalada'
}, {
  key: 't',
  text: 'Triangular',
  value: 'Triangular'
}, {
  key: 'r',
  text: 'Rectangular',
  value: 'Rectangular'
}, {
  key: 'tr',
  text: 'Trapezoidal',
  value: 'Trapezoidal'
}, {
  key: 'cu',
  text: 'Cuadrada',
  value: 'Cuadrada'
}, {
  key: 'ir',
  text: 'Irregular',
  value: 'Irregular'
}, {
  key: 's',
  text: 'Semi Circular',
  value: 'Semi Circular'
}, {
  key: 'l',
  text: 'Lineal',
  value: 'Lineal'
}];
var OP3 = [{
  key: 'de',
  text: 'Definidos Esclerótico',
  value: 'Definidos Esclerótico'
}, {
  key: 'dn',
  text: 'Definidos No Esclerótico',
  value: 'Definidos No Esclerótico'
}, {
  key: 'di',
  text: 'Difusos',
  value: 'Difusos'
}];
var LOCATION = function LOCATION(index) {
  return [{
    key: 'bl-ligamento' + index,
    text: 'Ligamento Estilohioideo',
    value: {
      'name': 'Ligamento Estilohioideo',
      'type': 'Blando'
    }
  }, {
    key: 'bl-lengua' + index,
    text: 'Lengua',
    value: {
      'name': 'Lengua',
      'type': 'Blando'
    }
  }, {
    key: 'bl-glandula' + index,
    text: 'Glándula Tiroides',
    value: {
      'name': 'Glándula Tiroides',
      'type': 'Blando'
    }
  }, {
    key: 'bl-amigdala' + index,
    text: 'Amígdala',
    value: {
      'name': 'Amígdala',
      'type': 'Blando'
    }
  }, {
    key: 'bl-nariz' + index,
    text: 'Tejido Blando de Nariz',
    value: {
      'name': 'Tejido Blando de Nariz',
      'type': 'Blando'
    }
  }, {
    key: 'du-huesonasal' + index,
    text: 'Hueso Nasal',
    value: {
      'name': 'Hueso Nasal',
      'type': 'Duro'
    }
  }, {
    key: 'du-huesotemp' + index,
    text: 'Hueso Temporal',
    value: {
      'name': 'Hueso Temporal',
      'type': 'Duro'
    }
  }, {
    key: 'du-huesocigo' + index,
    text: 'Hueso Cigomático',
    value: {
      'name': 'Hueso Cigomático',
      'type': 'Duro'
    }
  }, {
    key: 'du-espacionasal' + index,
    text: 'Espacio de Fosas Nasales',
    value: {
      'name': 'Espacio de Fosas Nasales',
      'type': 'Duro'
    }
  }, {
    key: 'du-huesohio' + index,
    text: 'Hueso Hioides',
    value: {
      'name': 'Hueso Hioides',
      'type': 'Duro'
    }
  }, {
    key: 'du-vertebras' + index,
    text: 'Vertebras Cervicales',
    value: {
      'name': 'Vertebras Cervicales',
      'type': 'Duro'
    }
  }, {
    key: 'du-maxilar' + index,
    text: 'Maxilar',
    value: {
      'name': 'Maxilar',
      'type': 'Duro'
    }
  }, {
    key: 'du-mandibula' + index,
    text: 'Mandíbula',
    value: {
      'name': 'Mandíbula',
      'type': 'Duro'
    }
  }, {
    key: 'ae-oro' + index,
    text: 'Espacio de Orofaringe',
    value: {
      'name': 'Espacio de Orofaringe',
      'type': 'Aéreo'
    }
  }, {
    key: 'ae-naso' + index,
    text: 'Espacio de Nasofaringe',
    value: {
      'name': 'Espacio de Nasofaringe',
      'type': 'Aéreo'
    }
  }, {
    key: 'ae-hipo' + index,
    text: 'Espacio de Hipofaringe',
    value: {
      'name': 'Espacio de Hipofaringe',
      'type': 'Aéreo'
    }
  }];
};
var POSITION = function POSITION(index) {
  return [{
    key: 'de' + index,
    text: 'Derecho',
    value: 'Derecho'
  }, {
    key: 'di' + index,
    text: 'Izquierdo',
    value: 'Izquierdo'
  }, {
    key: 'bi' + index,
    text: 'Bilateral',
    value: 'Bilateral'
  }];
};
var MANDIBULA_BRANCH = function MANDIBULA_BRANCH(index) {
  return [{
    key: 'rama' + index,
    text: 'Rama Mandibular',
    value: 'Rama Mandibular'
  }, {
    key: 'con' + index,
    text: 'Cóndilo Mandibular',
    value: 'Cóndilo Mandibular'
  }, {
    key: 'apo' + index,
    text: 'Apófisis Coronoides',
    value: 'Apófisis Coronoides'
  }];
};
var OP5_TYPE = [{
  key: 'r',
  text: 'Raices Dentarias',
  value: 'Raices Dentarias'
}, {
  key: 'c',
  text: 'Coronas Dentarias',
  value: 'Coronas Dentarias'
}, {
  key: 'o',
  text: 'Óseas',
  value: 'Óseas'
}];
var SINUS_MAXILAR_WALL = function SINUS_MAXILAR_WALL(index) {
  return [{
    key: 'ant' + index,
    text: 'Pared Anterior',
    value: 'Pared Anterior'
  }, {
    key: 'post' + index,
    text: 'Pared Posterior',
    value: 'Pared Posterior'
  }, {
    key: 'techo' + index,
    text: 'Techo',
    value: 'Techo'
  }, {
    key: 'piso' + index,
    text: 'Piso',
    value: 'Piso'
  }];
};
var MENUITEMS = function MENUITEMS(currentType) {
  return [{
    title: 'Edad',
    filter: 'age',
    chartTitle: "Prevalencia de lesiones ".concat(currentType, " seg\xFAn edad")
  }, {
    title: 'Género',
    filter: 'gender',
    chartTitle: "Prevalencia de lesiones ".concat(currentType, " seg\xFAn g\xE9nero")
  }, {
    title: 'Tipo de Registro',
    filter: 'register',
    chartTitle: "Prevalencia de lesiones ".concat(currentType, " seg\xFAn registro")
  }, {
    title: 'Única-Múltiple',
    filter: 'op1',
    chartTitle: "Prevalencia de lesiones ".concat(currentType, " seg\xFAn cantidad")
  }, {
    title: 'Unilocular-Multilocular',
    filter: 'op2',
    chartTitle: "Prevalencia de lesiones ".concat(currentType, " seg\xFAn compartimientos")
  }, {
    title: 'Formas',
    filter: 'form',
    chartTitle: "Prevalencia de lesiones ".concat(currentType, " seg\xFAn forma")
  }, {
    title: 'Bordes',
    filter: 'op3',
    chartTitle: "Prevalencia de lesiones ".concat(currentType, " seg\xFAn tipo de bordes")
  }, {
    title: 'Localización',
    filter: 'location_sub',
    chartTitle: "Prevalencia de lesiones ".concat(currentType, " seg\xFAn localizaci\xF3n"),
    sub: [{
      title: 'Localización',
      filter: 'location_sub',
      chartTitle: "Prevalencia de lesiones ".concat(currentType, " seg\xFAn localizaci\xF3n")
    }, {
      title: 'Tipo',
      filter: 'location_div',
      chartTitle: "Prevalenc\xEDa de lesiones ".concat(currentType, " seg\xFAn la estructura o espacio que ocupa")
    }, {
      title: 'Tejido Blando',
      filter: 'location_div_0',
      chartTitle: "Prevalencia de lesiones ".concat(currentType, " en tejidos blandos"),
      sub: [{
        title: 'Tejido Blando',
        filter: 'location_div_0',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en tejidos blandos")
      }, {
        title: 'Ligamento Estilohioideo',
        filter: 'location_estilohioideo_position',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en ligamento estilohioideo")
      }, {
        title: 'Lengua',
        filter: 'location_lengua_position',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en lengua")
      }, {
        title: 'Glándula Tiroides',
        filter: 'location_tiroides_position',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en gl\xE1ndula tiroides")
      }, {
        title: 'Amígdala',
        filter: 'location_amigdala_position',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en am\xEDgdala")
      }, {
        title: 'Tejido Blando de Nariz',
        filter: 'location_blnariz_position',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en tejido blando de nariz")
      }]
    }, {
      title: 'Tejido Duro',
      filter: 'location_div_1',
      chartTitle: "Prevalencia de lesiones ".concat(currentType, " en tejidos duros"),
      sub: [{
        title: 'Tejido Duro',
        filter: 'location_div_1',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en tejidos duros")
      }, {
        title: 'Mandíbula',
        filter: 'location_mandibula_position',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en mand\xEDbula"),
        sub: [{
          title: 'Mandíbula',
          filter: 'location_mandibula_position',
          chartTitle: "Prevalencia de lesiones ".concat(currentType, " en mand\xEDbula")
        }, {
          title: 'Cuerpo de la Mandíbula',
          filter: 'location_body_mandibula',
          chartTitle: "Prevalencia de lesiones ".concat(currentType, " en cuerpo de la mand\xEDbula")
        }, {
          title: 'Rama Mandibular',
          filter: 'location_branch_mandibula',
          chartTitle: "Prevalencia de lesiones ".concat(currentType, " en rama mandibular")
        }]
      }, {
        title: 'Maxilar',
        filter: 'location_maxilar_position',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en maxilar"),
        sub: [{
          title: 'Maxilar',
          filter: 'location_maxilar_position',
          chartTitle: "Prevalencia de lesiones ".concat(currentType, " en maxilar")
        }, {
          title: 'Seno Maxilar',
          filter: 'location_sinus_maxilar',
          chartTitle: "Prevalencia de lesiones ".concat(currentType, " en seno maxilar")
        }, {
          title: 'Peredes del Seno Maxilar',
          filter: 'location_sinus_maxilar_wall',
          chartTitle: "Prevalencia de lesiones ".concat(currentType, " en paredes del seno maxilar")
        }]
      }, {
        title: 'Hueso Nasal',
        filter: 'location_nasal_position',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en hueso nasal")
      }, {
        title: 'Espacio de Fosas Nasales',
        filter: 'location_fosa_position',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en espacio de fosas nasales")
      }, {
        title: 'Hueso Temporal',
        filter: 'location_temporal_position',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en hueso temporal")
      }, {
        title: 'Hueso Cigomático',
        filter: 'location_cigomatico_position',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en hueso cigom\xE1tico")
      }, {
        title: 'Hueso Hioides',
        filter: 'location_hioides_position',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en hueso hioides")
      }, {
        title: 'Vertebras Cervicales',
        filter: 'location_cervicales_position',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en vertebras cervicales")
      }]
    }, {
      title: 'Espacio Aéreo',
      filter: 'location_div_2',
      chartTitle: "Prevalencia de lesiones ".concat(currentType, " en espacios a\xE9reos"),
      sub: [{
        title: 'Espacio Aéreo',
        filter: 'location_div_2',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en espacios a\xE9reos")
      }, {
        title: 'Espacio de Orofaringe',
        filter: 'location_oro_position',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en espacio de orofaringe")
      }, {
        title: 'Espacio de Nasofaringe',
        filter: 'location_naso_position',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en espacio de nasofaringe")
      }, {
        title: 'Espacio de Hipofaringe',
        filter: 'location_hipo_position',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en espacio de hipofaringe")
      }]
    }]
  }, {
    title: 'Asociada',
    filter: 'op4',
    chartTitle: "Prevalencia de lesiones ".concat(currentType, " asociadas a piezas dentales"),
    sub: [{
      title: 'Asociada',
      filter: 'op4',
      chartTitle: "Prevalencia de lesiones ".concat(currentType, " asociadas a piezas dentales")
    }, {
      title: 'Asociada Pieza Dental',
      filter: 'op4_super',
      chartTitle: "Frecuencia de piezas dentales asociadas por lesiones ".concat(currentType)
    }]
  }, {
    title: 'Reabsorción',
    filter: 'op5',
    chartTitle: "Prevalencia de lesiones ".concat(currentType, " provocando reabsorci\xF3n"),
    sub: [{
      title: 'Reabsorción',
      filter: 'op5',
      chartTitle: "Prevalencia de lesiones ".concat(currentType, " provocando reabsorci\xF3n")
    }, {
      title: 'Reabsorción Tipo',
      filter: 'op5_type',
      chartTitle: "Prevalencia de lesiones ".concat(currentType, " seg\xFAn tipo de reabsorci\xF3n")
    }]
  }, {
    title: 'Desplazamiento',
    filter: 'op6',
    chartTitle: "Prevalencia de lesiones ".concat(currentType, " con desplazamiento de piezas dentales"),
    sub: [{
      title: 'Desplazamiento',
      filter: 'op6',
      chartTitle: "Prevalencia de lesiones ".concat(currentType, " con desplazamiento de piezas dentales")
    }, {
      title: 'Desplazamiento Pieza Dental',
      filter: 'op6_super',
      chartTitle: "Frecuencia de piezas dentales desplazadas por lesiones ".concat(currentType)
    }]
  }, {
    title: 'Expansión de Corticales',
    filter: 'op7',
    chartTitle: "Prevalencia de lesiones ".concat(currentType, " con expansi\xF3n de corticales")
  }, {
    title: 'Pieza Incluida',
    filter: 'op8',
    chartTitle: "Prevalencia de lesiones ".concat(currentType, " con piezas dentales incluidas"),
    sub: [{
      title: 'Pieza Incluida',
      filter: 'op8',
      chartTitle: "Prevalencia de lesiones ".concat(currentType, " con piezas dentales incluidas")
    }, {
      title: 'Número de Pieza Incluida',
      filter: 'op8_super',
      chartTitle: "Frecuencia de piezas dentales incluidas por lesiones ".concat(currentType)
    }]
  }, {
    title: 'Diagnóstico Diferencial 1',
    filter: 'dif1',
    chartTitle: "Prevalencia de Diagn\xF3stico diferencial 1 de lesiones ".concat(currentType)
  }, {
    title: 'Diagnóstico Diferencial 2',
    filter: 'dif2',
    chartTitle: "Prevalencia de Diagn\xF3stico diferencial 2 de lesiones ".concat(currentType)
  }, {
    title: 'Diagnóstico Diferencial 3',
    filter: 'dif3',
    chartTitle: "Prevalencia de Diagn\xF3stico diferencial 3 de lesiones ".concat(currentType)
  }];
};
var COLORS = ["#0D855D", "#1B8F68", "#14CC8F", "#3DFFBD", "#1AFFBA"];

/***/ }),
/* 5 */
/***/ (function(module, exports) {

module.exports = require("js-cookie");

/***/ }),
/* 6 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: external "@babel/runtime/regenerator"
var regenerator_ = __webpack_require__(2);
var regenerator_default = /*#__PURE__*/__webpack_require__.n(regenerator_);

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(0);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);

// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(3);
var router_default = /*#__PURE__*/__webpack_require__.n(router_);

// EXTERNAL MODULE: external "next-cookies"
var external_next_cookies_ = __webpack_require__(9);
var external_next_cookies_default = /*#__PURE__*/__webpack_require__.n(external_next_cookies_);

// EXTERNAL MODULE: external "js-cookie"
var external_js_cookie_ = __webpack_require__(5);
var external_js_cookie_default = /*#__PURE__*/__webpack_require__.n(external_js_cookie_);

// EXTERNAL MODULE: external "isomorphic-unfetch"
var external_isomorphic_unfetch_ = __webpack_require__(10);

// CONCATENATED MODULE: ./utils/api.js


function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

var simulateApi =
/*#__PURE__*/
function () {
  var _ref = _asyncToGenerator(
  /*#__PURE__*/
  regenerator_default.a.mark(function _callee(payload) {
    var delay,
        _args = arguments;
    return regenerator_default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            delay = _args.length > 1 && _args[1] !== undefined ? _args[1] : 1000;
            _context.next = 3;
            return new Promise(function (resolve) {
              return setTimeout(resolve(payload), delay);
            });

          case 3:
            return _context.abrupt("return", _context.sent);

          case 4:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));

  return function simulateApi(_x) {
    return _ref.apply(this, arguments);
  };
}();
// CONCATENATED MODULE: ./utils/auth.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return login; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return auth_logout; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return auth_withAuthSync; });
/* unused harmony export auth */



function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function auth_asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function auth_asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { auth_asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { auth_asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }







var login =
/*#__PURE__*/
function () {
  var _ref2 = auth_asyncToGenerator(
  /*#__PURE__*/
  regenerator_default.a.mark(function _callee(_ref) {
    var username, password, url, response, error;
    return regenerator_default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            username = _ref.username, password = _ref.password, url = _ref.url;
            _context.prev = 1;
            _context.next = 4;
            return simulateApi({
              'ok': true,
              'status': 200
            }, 3000);

          case 4:
            response = _context.sent;
            console.log(response);

            if (!(response.status && response.status == 200)) {
              _context.next = 11;
              break;
            }

            /*const { token } = await response.json()*/
            external_js_cookie_default.a.set('token', 'token', {
              expires: 1
            });
            router_default.a.push('/main');
            _context.next = 15;
            break;

          case 11:
            console.log('Login failed.'); // https://github.com/developit/unfetch#caveats

            error = new Error(response.statusText);
            error.response = response;
            return _context.abrupt("return", Promise.reject(error));

          case 15:
            _context.next = 21;
            break;

          case 17:
            _context.prev = 17;
            _context.t0 = _context["catch"](1);
            console.error('You have an error in your code or there are Network issues.', _context.t0);
            throw new Error(_context.t0);

          case 21:
          case "end":
            return _context.stop();
        }
      }
    }, _callee, null, [[1, 17]]);
  }));

  return function login(_x) {
    return _ref2.apply(this, arguments);
  };
}();
var auth_logout = function logout() {
  external_js_cookie_default.a.remove('token'); // to support logging out from all windows
  //window.localStorage.setItem('logout', Date.now())

  router_default.a.push('/login');
}; // Gets the display name of a JSX component for dev tools

var getDisplayName = function getDisplayName(Component) {
  return Component.displayName || Component.name || 'Component';
};

var auth_withAuthSync = function withAuthSync(WrappedComponent) {
  var _class, _temp;

  return _temp = _class =
  /*#__PURE__*/
  function (_Component) {
    _inherits(_class, _Component);

    _createClass(_class, null, [{
      key: "getInitialProps",
      value: function () {
        var _getInitialProps = auth_asyncToGenerator(
        /*#__PURE__*/
        regenerator_default.a.mark(function _callee2(ctx) {
          var token, componentProps;
          return regenerator_default.a.wrap(function _callee2$(_context2) {
            while (1) {
              switch (_context2.prev = _context2.next) {
                case 0:
                  token = auth_auth(ctx);
                  _context2.t0 = WrappedComponent.getInitialProps;

                  if (!_context2.t0) {
                    _context2.next = 6;
                    break;
                  }

                  _context2.next = 5;
                  return WrappedComponent.getInitialProps(ctx);

                case 5:
                  _context2.t0 = _context2.sent;

                case 6:
                  componentProps = _context2.t0;
                  return _context2.abrupt("return", _objectSpread({}, componentProps, {
                    token: token
                  }));

                case 8:
                case "end":
                  return _context2.stop();
              }
            }
          }, _callee2);
        }));

        function getInitialProps(_x2) {
          return _getInitialProps.apply(this, arguments);
        }

        return getInitialProps;
      }()
    }]);

    function _class(props) {
      var _this;

      _classCallCheck(this, _class);

      _this = _possibleConstructorReturn(this, _getPrototypeOf(_class).call(this, props));
      _this.syncLogout = _this.syncLogout.bind(_assertThisInitialized(_this));
      return _this;
    }

    _createClass(_class, [{
      key: "componentDidMount",
      value: function componentDidMount() {
        window.addEventListener('storage', this.syncLogout);
      }
    }, {
      key: "componentWillUnmount",
      value: function componentWillUnmount() {
        window.removeEventListener('storage', this.syncLogout);
        window.localStorage.removeItem('logout');
      }
    }, {
      key: "syncLogout",
      value: function syncLogout(event) {
        if (event.key === 'logout') {
          console.log('logged out from storage!');
          router_default.a.push('/login');
        }
      }
    }, {
      key: "render",
      value: function render() {
        return external_react_default.a.createElement(WrappedComponent, this.props);
      }
    }]);

    return _class;
  }(external_react_["Component"]), _defineProperty(_class, "displayName", "withAuthSync(".concat(getDisplayName(WrappedComponent), ")")), _temp;
};
var auth_auth = function auth(ctx) {
  var _nextCookie = external_next_cookies_default()(ctx),
      token = _nextCookie.token;

  if (ctx.req && !token) {
    ctx.res.writeHead(302, {
      Location: '/login'
    });
    ctx.res.end();
    return;
  }

  if (!token) {
    router_default.a.push('/login');
  }

  return token;
};

/***/ }),
/* 7 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(0);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);


/* harmony default export */ __webpack_exports__["a"] = (function () {
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(next_head__WEBPACK_IMPORTED_MODULE_1___default.a, null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("link", {
    rel: "stylesheet",
    href: "//cdn.jsdelivr.net/npm/semantic-ui@2.4.2/dist/semantic.min.css"
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("style", null, "\n\t\t\t    \tbody { background: #3f0644; color: rgba(255,255,255,.9); }\n\t\t\t    \tlabel { color: white !important; }\n        \t")));
});

/***/ }),
/* 8 */
/***/ (function(module, exports) {

module.exports = require("next/head");

/***/ }),
/* 9 */
/***/ (function(module, exports) {

module.exports = require("next-cookies");

/***/ }),
/* 10 */
/***/ (function(module, exports) {

module.exports = require("isomorphic-unfetch");

/***/ }),
/* 11 */,
/* 12 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(0);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1);
/* harmony import */ var semantic_ui_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__);


/* harmony default export */ __webpack_exports__["a"] = (function (_ref) {
  var _ref$headerTitle = _ref.headerTitle,
      headerTitle = _ref$headerTitle === void 0 ? 'LESIONES ROENTGENOLÓGICAS' : _ref$headerTitle;
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    style: {
      marginBottom: 25,
      paddingTop: 10
    }
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
    style: {
      backgroundColor: 'white'
    }
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__["Grid"].Row, {
    columns: 3
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__["Grid"].Column, {
    width: 2
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__["Image"], {
    src: "static/usac-logo.png",
    style: {
      margin: 'auto'
    },
    width: 65,
    height: 65
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__["Grid"].Column, {
    width: 12
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__["Header"], {
    as: "h2",
    color: "purple",
    textAlign: "center",
    style: {
      'height': '100%',
      'width': '100%',
      'position': 'absolute',
      'top': '30%'
    }
  }, headerTitle)), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__["Grid"].Column, {
    width: 2
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__["Image"], {
    src: "static/fousac-logo.jpeg",
    style: {
      margin: 'auto'
    },
    width: 65,
    height: 65
  }))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__["Grid"].Row, {
    style: {
      'color': 'black',
      'textAlign': 'right',
      'padding': '0 35px 0 0',
      'display': 'block'
    }
  }, "Adriana Olivar")));
});

/***/ }),
/* 13 */
/***/ (function(module, exports) {

module.exports = require("next/link");

/***/ }),
/* 14 */
/***/ (function(module, exports) {

module.exports = require("styled-jsx/style");

/***/ }),
/* 15 */,
/* 16 */,
/* 17 */,
/* 18 */,
/* 19 */,
/* 20 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(30);


/***/ }),
/* 21 */,
/* 22 */,
/* 23 */,
/* 24 */,
/* 25 */,
/* 26 */,
/* 27 */,
/* 28 */,
/* 29 */,
/* 30 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(0);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);

// EXTERNAL MODULE: ./utils/auth.js + 1 modules
var auth = __webpack_require__(6);

// EXTERNAL MODULE: external "next/link"
var link_ = __webpack_require__(13);
var link_default = /*#__PURE__*/__webpack_require__.n(link_);

// EXTERNAL MODULE: external "semantic-ui-react"
var external_semantic_ui_react_ = __webpack_require__(1);

// EXTERNAL MODULE: external "styled-jsx/style"
var style_ = __webpack_require__(14);
var style_default = /*#__PURE__*/__webpack_require__.n(style_);

// EXTERNAL MODULE: ./components/css.jsx
var css = __webpack_require__(7);

// CONCATENATED MODULE: ./utils/functions.js
function range(start, stop, step) {
  var a = [start],
      b = start;

  while (b < stop) {
    a.push(b += step || 1);
  }

  return a;
}
// EXTERNAL MODULE: ./configuration/options.js
var options = __webpack_require__(4);

// CONCATENATED MODULE: ./components/createinjurymodal.jsx



function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






var DEFAULT_INIT_STATE = {
  'modalOpen': false,
  'locations': [_objectSpread({}, options["b" /* DEFAULT_LOCATION */])],
  'tooths': [],
  'error': null,
  'name': null,
  'lastname': null,
  'register': null,
  'register_num': null,
  'gender': null,
  'age': null,
  '_type': null,
  'op1': null,
  'op2': null,
  'form': null,
  'op3': null,
  'size_0': null,
  'size_1': null,
  'size_2': null,
  'op4': null,
  'op5': null,
  'op5_type': null,
  'op6': null,
  'op7': null,
  'op8': null,
  'dif1': null,
  'dif2': null,
  'dif3': null
};

var createinjurymodal_CreateInjuryModal =
/*#__PURE__*/
function (_Component) {
  _inherits(CreateInjuryModal, _Component);

  function CreateInjuryModal(props) {
    var _this;

    _classCallCheck(this, CreateInjuryModal);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(CreateInjuryModal).call(this, props));

    _defineProperty(_assertThisInitialized(_this), "teethOptions", []);

    _defineProperty(_assertThisInitialized(_this), "handleChange", function (e, _ref) {
      var name = _ref.name,
          value = _ref.value,
          checked = _ref.checked;
      console.log('handleChange');
      console.log("".concat(name, " ").concat(value, " ").concat(checked));

      if (value === undefined && checked !== undefined) {
        value = checked;
      }

      if (name === 'op4' && value === 'Asociada') {
        _this.checkTooth(value);
      } else if (name === 'op4' && value === 'No Asociado') {
        _this.removeToothByType('Asociada');
      } else if (name === 'op6' && value === 'Con Desplazamiento Piezas Dentarias') {
        _this.checkTooth(value);
      } else if (name === 'op6' && value === 'Sin Desplazamiento Piezas Dentarias') {
        _this.removeToothByType('Con Desplazamiento Piezas Dentarias');
      } else if (name === 'op8' && value === 'Pieza Incluida') {
        _this.checkTooth(value);
      } else if (name === 'op8' && value === 'Pieza No Incluida') {
        _this.removeToothByType('Pieza Incluida');
      }

      _this.setState(_defineProperty({}, name, value));
    });

    _defineProperty(_assertThisInitialized(_this), "handleLocationChange", function (e, _ref2) {
      var name = _ref2.name,
          value = _ref2.value;

      if (name <= _this.state.locations.length - 1) {
        var locations = _this.state.locations;
        locations[name]['location'] = value['name'];
        locations[name]['_type'] = value['type'];
        locations[name]['body_mandibula'] = false;
        locations[name]['sinus_maxilar'] = false;

        _this.setState({
          'locations': _toConsumableArray(locations)
        });
      }
    });

    _defineProperty(_assertThisInitialized(_this), "handleToothsChange", function (e, _ref3) {
      var name = _ref3.name,
          value = _ref3.value;

      if (name <= _this.state.tooths.length - 1) {
        var tooths = _toConsumableArray(_this.state.tooths);

        tooths[name]['location'] = value;

        _this.setState({
          'tooths': _toConsumableArray(tooths)
        });
      }
    });

    _defineProperty(_assertThisInitialized(_this), "handlePositionChange", function (e, _ref4) {
      var name = _ref4.name,
          value = _ref4.value;

      if (name <= _this.state.locations.length - 1) {
        var locations = _this.state.locations;
        locations[name]['position'] = value;

        _this.setState({
          'locations': _toConsumableArray(locations)
        });
      }
    });

    _defineProperty(_assertThisInitialized(_this), "handleBranchChange", function (e, _ref5) {
      var name = _ref5.name,
          value = _ref5.value;

      if (name <= _this.state.locations.length - 1) {
        var locations = _this.state.locations;
        locations[name]['branch_mandibula'] = value;

        _this.setState({
          'locations': _toConsumableArray(locations)
        });
      }
    });

    _defineProperty(_assertThisInitialized(_this), "handleWallChange", function (e, _ref6) {
      var name = _ref6.name,
          value = _ref6.value;

      if (name <= _this.state.locations.length - 1) {
        var locations = _this.state.locations;
        locations[name]['sinus_maxilar_wall'] = value;

        _this.setState({
          'locations': _toConsumableArray(locations)
        });
      }
    });

    _defineProperty(_assertThisInitialized(_this), "handleBodyChange", function (index, _ref7) {
      var name = _ref7.name,
          checked = _ref7.checked;

      if (name <= _this.state.locations.length - 1) {
        var locations = _this.state.locations;
        locations[name]['body_mandibula'] = checked;

        _this.setState({
          'locations': _toConsumableArray(locations)
        });
      }
    });

    _defineProperty(_assertThisInitialized(_this), "handleSinusChange", function (index, _ref8) {
      var name = _ref8.name,
          checked = _ref8.checked;

      if (name <= _this.state.locations.length - 1) {
        var locations = _this.state.locations;
        locations[name]['sinus_maxilar'] = checked;

        _this.setState({
          'locations': _toConsumableArray(locations)
        });
      }
    });

    _defineProperty(_assertThisInitialized(_this), "addLocation", function (e) {
      e.preventDefault();

      _this.setState(function (state) {
        return _objectSpread({}, state, {
          'locations': [].concat(_toConsumableArray(state.locations), [_objectSpread({}, options["b" /* DEFAULT_LOCATION */])])
        });
      });
    });

    _defineProperty(_assertThisInitialized(_this), "removeLocation", function (e) {
      e.preventDefault();

      _this.setState(function (state) {
        var locations = _toConsumableArray(state.locations);

        locations.pop();

        if (locations.length > 0) {
          return _objectSpread({}, state, {
            locations: locations
          });
        } else {
          return _objectSpread({}, state);
        }
      });
    });

    _defineProperty(_assertThisInitialized(_this), "addTooth", function (currentType) {
      return function (e) {
        e.preventDefault();

        _this.setState(function (state) {
          var new_tooth = Object.assign({}, options["c" /* DEFAULT_TOOTH */]);
          new_tooth['_type'] = currentType;
          new_tooth['index'] = state.tooths.length;
          return _objectSpread({}, state, {
            'tooths': [].concat(_toConsumableArray(state.tooths), [_objectSpread({}, new_tooth)])
          });
        });
      };
    });

    _defineProperty(_assertThisInitialized(_this), "removeTooth", function (index) {
      return function (e) {
        e.preventDefault();

        _this.removeToothByIndex(index);
      };
    });

    _this.state = Object.assign({}, DEFAULT_INIT_STATE);
    _this.teethOptions = _this.initTeethOptions();
    _this.handleOpen = _this.handleOpen.bind(_assertThisInitialized(_this));
    _this.handleClose = _this.handleClose.bind(_assertThisInitialized(_this));
    _this.handleSubmit = _this.handleSubmit.bind(_assertThisInitialized(_this));
    _this.handleChange = _this.handleChange.bind(_assertThisInitialized(_this));
    _this.handleBranchChange = _this.handleBranchChange.bind(_assertThisInitialized(_this));
    _this.handleBodyChange = _this.handleBodyChange.bind(_assertThisInitialized(_this));
    _this.handleSinusChange = _this.handleSinusChange.bind(_assertThisInitialized(_this));
    _this.handleWallChange = _this.handleWallChange.bind(_assertThisInitialized(_this));
    return _this;
  }

  _createClass(CreateInjuryModal, [{
    key: "initTeethOptions",
    value: function initTeethOptions() {
      var teethRange = range(1, 32).map(function (number) {
        var numberString = number.toString();
        return {
          'key': numberString,
          'value': numberString,
          'text': numberString
        };
      });
      return [].concat(_toConsumableArray(teethRange), [{
        'key': 'sp',
        'value': 'Super Numeraria',
        'text': 'Super Numeraria'
      }]);
    }
  }, {
    key: "handleOpen",
    value: function handleOpen() {
      this.setState(_objectSpread({}, DEFAULT_INIT_STATE));
      this.setState({
        'locations': [_objectSpread({}, options["b" /* DEFAULT_LOCATION */])]
      });
      this.setState({
        'modalOpen': true
      });
    }
  }, {
    key: "handleClose",
    value: function handleClose() {
      this.setState({
        'modalOpen': false
      });
    }
  }, {
    key: "handleSubmit",
    value: function handleSubmit(e) {
      var _this2 = this;

      console.log("******************");
      console.log(e);
      console.log("******************");
      e.target.reset();
      var tmp_locations = this.state.locations;

      if (tmp_locations && tmp_locations.length < 2 && tmp_locations[0] === options["b" /* DEFAULT_LOCATION */]) {
        this.setState('locations', []);
      }

      console.log(this.state);
      fetch('http://127.0.0.1:5000/injury', {
        method: 'POST',
        headers: new Headers({
          "Content-Type": "application/json",
          "Accept": "application/json"
        }),
        body: JSON.stringify(this.state)
      }).then(function (response) {
        _this2.setState(_objectSpread({}, DEFAULT_INIT_STATE));

        _this2.handleClose();
      }).catch(function (error) {
        _this2.setState({
          error: error
        });
      });
    }
  }, {
    key: "checkTooth",
    value: function checkTooth(currentType) {
      var tooths = this.state.tooths.filter(function (tooth) {
        return tooth._type === currentType;
      });

      if (tooths.length === 0) {
        this.setState(function (state) {
          var new_tooth = Object.assign({}, options["c" /* DEFAULT_TOOTH */]);
          new_tooth['_type'] = currentType;
          new_tooth['index'] = state.tooths.length;
          return _objectSpread({}, state, {
            'tooths': [].concat(_toConsumableArray(state.tooths), [_objectSpread({}, new_tooth)])
          });
        });
      }
    }
  }, {
    key: "removeToothByType",
    value: function removeToothByType(currentType) {
      var _this3 = this;

      this.setState(function (state) {
        var tooths = _this3.state.tooths.filter(function (tooth) {
          return tooth._type !== currentType;
        });

        return _objectSpread({}, state, {
          'tooths': _this3.updateToothsIndex(tooths)
        });
      });
    }
  }, {
    key: "removeToothByTypeAndEmpty",
    value: function removeToothByTypeAndEmpty(currentType, cb) {
      var _this4 = this;

      this.setState(function (state) {
        var tooths = _this4.state.tooths.filter(function (tooth) {
          console.log(tooth.location);
          return tooth._type !== currentType && tooth.location === "";
        });

        return _objectSpread({}, state, {
          'tooths': _this4.updateToothsIndex(tooths)
        });
      }, cb());
    }
  }, {
    key: "removeToothByIndex",
    value: function removeToothByIndex(index) {
      var _this5 = this;

      this.setState(function (state) {
        var tooths = _this5.state.tooths.filter(function (tooth) {
          return tooth.index !== index;
        });

        return _objectSpread({}, state, {
          'tooths': _this5.updateToothsIndex(tooths)
        });
      });
    }
  }, {
    key: "updateToothsIndex",
    value: function updateToothsIndex(tooths) {
      var newTooths = _toConsumableArray(tooths.map(function (tooth, index) {
        tooth.index = index;
        return tooth;
      }));

      console.log(newTooths);
      return newTooths;
    }
  }, {
    key: "render",
    value: function render() {
      var _this6 = this;

      return external_react_default.a.createElement(external_semantic_ui_react_["Modal"], {
        open: this.state.modalOpen,
        onClose: this.handleClose,
        trigger: external_react_default.a.createElement(external_semantic_ui_react_["Button"], {
          inverted: true,
          color: "purple",
          onClick: this.handleOpen
        }, "Ingresar nueva lesi\xF3n")
      }, external_react_default.a.createElement(external_semantic_ui_react_["Segment"], {
        inverted: true
      }, external_react_default.a.createElement(external_semantic_ui_react_["Modal"].Header, {
        as: "h1",
        style: {
          margin: 2
        }
      }, external_react_default.a.createElement("b", {
        className: "jsx-2839058981"
      }, "Nueva Lesi\xF3n")), external_react_default.a.createElement(external_semantic_ui_react_["Modal"].Content, null, external_react_default.a.createElement(external_semantic_ui_react_["Modal"].Description, null, external_react_default.a.createElement(external_semantic_ui_react_["Form"], {
        onSubmit: this.handleSubmit
      }, external_react_default.a.createElement(external_semantic_ui_react_["Form"].Group, {
        widths: "equal"
      }, external_react_default.a.createElement(external_semantic_ui_react_["Form"].Field, {
        required: true,
        control: external_semantic_ui_react_["Input"],
        label: "Nombre",
        name: "name",
        onChange: this.handleChange
      }), external_react_default.a.createElement(external_semantic_ui_react_["Form"].Field, {
        required: true,
        control: external_semantic_ui_react_["Input"],
        label: "Apellido",
        name: "lastname",
        onChange: this.handleChange
      })), external_react_default.a.createElement(external_semantic_ui_react_["Form"].Group, {
        widths: "equal"
      }, external_react_default.a.createElement(external_semantic_ui_react_["Form"].Field, {
        required: true,
        control: external_semantic_ui_react_["Select"],
        label: "Registro",
        name: "register",
        options: options["l" /* REGISTER */],
        onChange: this.handleChange
      }), external_react_default.a.createElement(external_semantic_ui_react_["Form"].Field, {
        required: true,
        control: external_semantic_ui_react_["Input"],
        label: "Registro",
        name: "register_num",
        type: "number",
        onChange: this.handleChange
      })), external_react_default.a.createElement(external_semantic_ui_react_["Form"].Group, {
        widths: "equal"
      }, external_react_default.a.createElement(external_semantic_ui_react_["Form"].Field, {
        required: true,
        control: external_semantic_ui_react_["Select"],
        label: "G\xE9nero",
        name: "gender",
        options: options["e" /* GENDER */],
        onChange: this.handleChange
      }), external_react_default.a.createElement(external_semantic_ui_react_["Form"].Field, {
        required: true,
        control: external_semantic_ui_react_["Input"],
        label: "Edad",
        name: "age",
        type: "number",
        onChange: this.handleChange
      })), external_react_default.a.createElement(external_semantic_ui_react_["Form"].Field, {
        required: true,
        control: external_semantic_ui_react_["Select"],
        label: "Aspecto General",
        name: "_type",
        options: options["n" /* _TYPE */],
        onChange: this.handleChange
      }), external_react_default.a.createElement(external_semantic_ui_react_["Form"].Group, {
        inline: true
      }, external_react_default.a.createElement(external_semantic_ui_react_["Form"].Radio, {
        label: "\xDAnica",
        name: "op1",
        value: "\xDAnica",
        checked: this.state.op1 === 'Única',
        onChange: this.handleChange
      }), external_react_default.a.createElement(external_semantic_ui_react_["Form"].Radio, {
        label: "M\xFAltiple",
        name: "op1",
        value: "M\xFAltiple",
        checked: this.state.op1 === 'Múltiple',
        onChange: this.handleChange
      })), external_react_default.a.createElement(external_semantic_ui_react_["Form"].Group, {
        inline: true
      }, external_react_default.a.createElement(external_semantic_ui_react_["Form"].Radio, {
        label: "Unilocular",
        name: "op2",
        value: "Unilocular",
        checked: this.state.op2 === 'Unilocular',
        onChange: this.handleChange
      }), external_react_default.a.createElement(external_semantic_ui_react_["Form"].Radio, {
        label: "Multilocular",
        name: "op2",
        value: "Multilocular",
        checked: this.state.op2 === 'Multilocular',
        onChange: this.handleChange
      })), external_react_default.a.createElement(external_semantic_ui_react_["Form"].Group, {
        inline: true
      }, external_react_default.a.createElement(external_semantic_ui_react_["Form"].Field, {
        control: external_semantic_ui_react_["Select"],
        label: "Forma",
        name: "form",
        options: options["d" /* FORM */],
        onChange: this.handleChange
      }), external_react_default.a.createElement(external_semantic_ui_react_["Form"].Field, {
        control: external_semantic_ui_react_["Select"],
        label: "Bordes",
        name: "op3",
        options: options["i" /* OP3 */],
        onChange: this.handleChange
      })), this.state.locations.map(function (obj, index) {
        return external_react_default.a.createElement(external_semantic_ui_react_["Form"].Group, {
          key: 'location' + index,
          inline: true
        }, external_react_default.a.createElement(external_semantic_ui_react_["Form"].Field, {
          control: external_semantic_ui_react_["Select"],
          name: index,
          label: "Localizaci\xF3n",
          options: Object(options["f" /* LOCATION */])(index),
          onChange: _this6.handleLocationChange
        }), external_react_default.a.createElement(external_semantic_ui_react_["Form"].Field, {
          control: external_semantic_ui_react_["Select"],
          name: index,
          label: "Posici\xF3n",
          options: Object(options["k" /* POSITION */])(index),
          onChange: _this6.handlePositionChange
        }), obj.location === 'Mandíbula' ? external_react_default.a.createElement(external_semantic_ui_react_["Form"].Field, {
          control: external_semantic_ui_react_["Select"],
          label: "Rama",
          name: index,
          options: Object(options["g" /* MANDIBULA_BRANCH */])(index),
          onChange: _this6.handleBranchChange
        }) : null, obj.location === 'Mandíbula' ? external_react_default.a.createElement(external_semantic_ui_react_["Form"].Field, {
          control: external_semantic_ui_react_["Checkbox"],
          label: "Cuerpo",
          name: index,
          onChange: _this6.handleBodyChange
        }) : null, obj.location === 'Maxilar' ? external_react_default.a.createElement(external_semantic_ui_react_["Form"].Field, {
          control: external_semantic_ui_react_["Checkbox"],
          label: "Seno Maxilar",
          name: index,
          onChange: _this6.handleSinusChange
        }) : null, obj.sinus_maxilar ? external_react_default.a.createElement(external_semantic_ui_react_["Form"].Field, {
          control: external_semantic_ui_react_["Select"],
          label: "Pared",
          name: index,
          options: Object(options["m" /* SINUS_MAXILAR_WALL */])(index),
          onChange: _this6.handleWallChange
        }) : null, external_react_default.a.createElement("br", {
          key: 'br' + index,
          className: "jsx-2839058981"
        }), createinjurymodal_controlOnlyToLast(index, _this6.state.locations, _this6.addLocation, _this6.removeLocation));
      }), external_react_default.a.createElement(external_semantic_ui_react_["Form"].Group, null, external_react_default.a.createElement(external_semantic_ui_react_["Form"].Field, {
        control: external_semantic_ui_react_["Input"],
        label: "Eje Mayor",
        name: "size_0",
        type: "number",
        step: "0.1",
        onChange: this.handleChange
      }), external_react_default.a.createElement(external_semantic_ui_react_["Form"].Field, {
        control: external_semantic_ui_react_["Input"],
        label: "Eje Menor",
        name: "size_1",
        type: "number",
        step: "0.1",
        onChange: this.handleChange
      }), external_react_default.a.createElement(external_semantic_ui_react_["Form"].Field, {
        control: external_semantic_ui_react_["Input"],
        label: "Diametro",
        name: "size_2",
        type: "number",
        step: "0.1",
        onChange: this.handleChange
      }), external_react_default.a.createElement("label", {
        className: "jsx-2839058981"
      }, "mm")), external_react_default.a.createElement(external_semantic_ui_react_["Form"].Group, {
        inline: true
      }, external_react_default.a.createElement(external_semantic_ui_react_["Form"].Radio, {
        label: "Asociada",
        name: "op4",
        value: "Asociada",
        checked: this.state.op4 === 'Asociada',
        onChange: this.handleChange
      }), external_react_default.a.createElement(external_semantic_ui_react_["Form"].Radio, {
        label: "No Asociado",
        name: "op4",
        value: "No Asociado",
        checked: this.state.op4 === 'No Asociado',
        onChange: this.handleChange
      })), this.state.op4 === 'Asociada' ? this.state.tooths.filter(function (t) {
        return t._type === 'Asociada';
      }).map(function (obj, index) {
        return external_react_default.a.createElement(external_semantic_ui_react_["Form"].Group, {
          key: 'tooth' + index,
          inline: true
        }, external_react_default.a.createElement(external_semantic_ui_react_["Form"].Field, {
          required: true,
          control: external_semantic_ui_react_["Select"],
          name: obj.index,
          label: "Pieza Dental",
          options: _this6.teethOptions,
          onChange: _this6.handleToothsChange
        }), external_react_default.a.createElement("br", {
          key: 'br' + index,
          className: "jsx-2839058981"
        }), createinjurymodal_controlOnlyToLast(obj.index, _this6.state.tooths, _this6.addTooth('Asociada'), _this6.removeTooth(obj.index)));
      }) : null, external_react_default.a.createElement(external_semantic_ui_react_["Form"].Group, {
        inline: true
      }, external_react_default.a.createElement(external_semantic_ui_react_["Form"].Radio, {
        label: "Con Reabsorci\xF3n",
        name: "op5",
        value: "Con Reabsorci\xF3n",
        checked: this.state.op5 === 'Con Reabsorción',
        onChange: this.handleChange
      }), external_react_default.a.createElement(external_semantic_ui_react_["Form"].Radio, {
        label: "Sin Reabsorci\xF3n",
        name: "op5",
        value: "Sin Reabsorci\xF3n",
        checked: this.state.op5 === 'Sin Reabsorción',
        onChange: this.handleChange
      }), this.state.op5 === 'Con Reabsorción' ? external_react_default.a.createElement(external_semantic_ui_react_["Form"].Field, {
        required: true,
        control: external_semantic_ui_react_["Select"],
        label: "Tipo",
        name: "op5_type",
        options: options["j" /* OP5_TYPE */],
        onChange: this.handleChange
      }) : null), external_react_default.a.createElement(external_semantic_ui_react_["Form"].Group, {
        inline: true
      }, external_react_default.a.createElement(external_semantic_ui_react_["Form"].Radio, {
        label: "Con Desplazamiento Piezas Dentarias",
        name: "op6",
        value: "Con Desplazamiento Piezas Dentarias",
        checked: this.state.op6 === 'Con Desplazamiento Piezas Dentarias',
        onChange: this.handleChange
      }), external_react_default.a.createElement(external_semantic_ui_react_["Form"].Radio, {
        label: "Sin Desplazamiento Piezas Dentarias",
        name: "op6",
        value: "Sin Desplazamiento Piezas Dentarias",
        checked: this.state.op6 === 'Sin Desplazamiento Piezas Dentarias',
        onChange: this.handleChange
      })), this.state.op6 === 'Con Desplazamiento Piezas Dentarias' ? this.state.tooths.filter(function (t) {
        return t._type === 'Con Desplazamiento Piezas Dentarias';
      }).map(function (obj, index) {
        return external_react_default.a.createElement(external_semantic_ui_react_["Form"].Group, {
          key: 'tooth' + index,
          inline: true
        }, external_react_default.a.createElement(external_semantic_ui_react_["Form"].Field, {
          required: true,
          control: external_semantic_ui_react_["Select"],
          name: obj.index,
          label: "Pieza Dental",
          options: _this6.teethOptions,
          onChange: _this6.handleToothsChange
        }), external_react_default.a.createElement("br", {
          key: 'br' + index,
          className: "jsx-2839058981"
        }), createinjurymodal_controlOnlyToLast(obj.index, _this6.state.tooths, _this6.addTooth('Con Desplazamiento Piezas Dentarias'), _this6.removeTooth(obj.index)));
      }) : null, external_react_default.a.createElement(external_semantic_ui_react_["Form"].Group, {
        inline: true
      }, external_react_default.a.createElement(external_semantic_ui_react_["Form"].Radio, {
        label: "Con Expansi\xF3n de Corticales",
        name: "op7",
        value: "Con Expansi\xF3n de Corticales",
        checked: this.state.op7 === 'Con Expansión de Corticales',
        onChange: this.handleChange
      }), external_react_default.a.createElement(external_semantic_ui_react_["Form"].Radio, {
        label: "Sin Expansi\xF3n de Corticales",
        name: "op7",
        value: "Sin Expansi\xF3n de Corticales",
        checked: this.state.op7 === 'Sin Expansión de Corticales',
        onChange: this.handleChange
      }), external_react_default.a.createElement(external_semantic_ui_react_["Form"].Radio, {
        label: "No aplica",
        name: "op7",
        value: "No aplica",
        checked: this.state.op7 === 'No aplica',
        onChange: this.handleChange
      })), external_react_default.a.createElement(external_semantic_ui_react_["Form"].Group, {
        inline: true
      }, external_react_default.a.createElement(external_semantic_ui_react_["Form"].Radio, {
        label: "Pieza Incluida",
        name: "op8",
        value: "Pieza Incluida",
        checked: this.state.op8 === 'Pieza Incluida',
        onChange: this.handleChange
      }), external_react_default.a.createElement(external_semantic_ui_react_["Form"].Radio, {
        label: "Pieza No Incluida",
        name: "op8",
        value: "Pieza No Incluida",
        checked: this.state.op8 === 'Pieza No Incluida',
        onChange: this.handleChange
      })), this.state.op8 === 'Pieza Incluida' ? this.state.tooths.filter(function (t) {
        return t._type === 'Pieza Incluida';
      }).map(function (obj, index) {
        return external_react_default.a.createElement(external_semantic_ui_react_["Form"].Group, {
          key: 'tooth' + index,
          inline: true
        }, external_react_default.a.createElement(external_semantic_ui_react_["Form"].Field, {
          required: true,
          control: external_semantic_ui_react_["Select"],
          name: obj.index,
          label: "Pieza Dental",
          options: _this6.teethOptions,
          onChange: _this6.handleToothsChange
        }), external_react_default.a.createElement("br", {
          key: 'br' + index,
          className: "jsx-2839058981"
        }), createinjurymodal_controlOnlyToLast(obj.index, _this6.state.tooths, _this6.addTooth('Pieza Incluida'), _this6.removeTooth(obj.index)));
      }) : null, external_react_default.a.createElement(external_semantic_ui_react_["Form"].Group, {
        inline: true
      }, external_react_default.a.createElement("label", {
        className: "jsx-2839058981"
      }, external_react_default.a.createElement("b", {
        className: "jsx-2839058981"
      }, "Diagn\xF3stico Diferencial")), external_react_default.a.createElement(external_semantic_ui_react_["Form"].Field, {
        required: true,
        control: external_semantic_ui_react_["Input"],
        name: "dif1",
        onChange: this.handleChange
      }), external_react_default.a.createElement(external_semantic_ui_react_["Form"].Field, {
        control: external_semantic_ui_react_["Input"],
        name: "dif2",
        onChange: this.handleChange
      }), external_react_default.a.createElement(external_semantic_ui_react_["Form"].Field, {
        control: external_semantic_ui_react_["Input"],
        name: "dif3",
        onChange: this.handleChange
      })), this.state.error ? external_react_default.a.createElement(external_semantic_ui_react_["Message"], {
        negative: true
      }, external_react_default.a.createElement(external_semantic_ui_react_["Message"].Header, null, "Error"), external_react_default.a.createElement("p", {
        className: "jsx-2839058981"
      }, "La lesi\xF3n no pudo ser ingresada")) : null, external_react_default.a.createElement(external_semantic_ui_react_["Button"], {
        inverted: true,
        color: "purple",
        content: "Enviar",
        type: "submit"
      }), external_react_default.a.createElement(external_semantic_ui_react_["Button"], {
        inverted: true,
        color: "grey",
        content: "Cancelar",
        onClick: this.handleClose
      }))))), external_react_default.a.createElement(style_default.a, {
        styleId: "2839058981",
        css: ["b.jsx-2839058981,label.jsx-2839058981{color:white;}"]
      }));
    }
  }]);

  return CreateInjuryModal;
}(external_react_["Component"]);



var createinjurymodal_controlOnlyToLast = function controlOnlyToLast(index, list, add, remove) {
  return index === list.length - 1 ? external_react_default.a.createElement("div", null, external_react_default.a.createElement(external_semantic_ui_react_["Button"], {
    icon: true,
    compact: true,
    color: "blue",
    onClick: add
  }, external_react_default.a.createElement(external_semantic_ui_react_["Icon"], {
    name: "plus"
  })), external_react_default.a.createElement(external_semantic_ui_react_["Button"], {
    icon: true,
    compact: true,
    color: "red",
    onClick: remove
  }, external_react_default.a.createElement(external_semantic_ui_react_["Icon"], {
    name: "x"
  }))) : null;
};
// EXTERNAL MODULE: ./components/headerlayout.jsx
var headerlayout = __webpack_require__(12);

// CONCATENATED MODULE: ./pages/main.jsx


function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance"); }

function _iterableToArrayLimit(arr, i) { if (!(Symbol.iterator in Object(arr) || Object.prototype.toString.call(arr) === "[object Arguments]")) { return; } var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }










var main_Main = function Main(props) {
  var _useState = Object(external_react_["useState"])([]),
      _useState2 = _slicedToArray(_useState, 2),
      injuries = _useState2[0],
      setInjuries = _useState2[1];

  var _useState3 = Object(external_react_["useState"])(null),
      _useState4 = _slicedToArray(_useState3, 2),
      error = _useState4[0],
      setError = _useState4[1];

  var getInjuries = function getInjuries() {
    return fetch('http://127.0.0.1:5000/injury').then(function (response) {
      return response.json();
    }).then(function (data) {
      setInjuries(data);
    });
  };

  Object(external_react_["useEffect"])(function () {
    getInjuries();
  }, [injuries]);

  var deleteInjury = function deleteInjury(id) {
    return fetch("http://127.0.0.1:5000/injury/".concat(id), {
      method: 'DELETE'
    }).then(function (response) {
      return getInjuries();
    }).catch(function (error) {
      return setError(error.response);
    });
  };

  var onLogout = function onLogout() {
    return Object(auth["b" /* logout */])();
  };

  return external_react_default.a.createElement("div", null, external_react_default.a.createElement(css["a" /* default */], null), external_react_default.a.createElement(headerlayout["a" /* default */], null), external_react_default.a.createElement(external_semantic_ui_react_["Grid"], null, external_react_default.a.createElement(external_semantic_ui_react_["Grid"].Row, {
    columns: 3
  }, external_react_default.a.createElement(external_semantic_ui_react_["Grid"].Column, {
    width: 2
  }), external_react_default.a.createElement(external_semantic_ui_react_["Grid"].Column, {
    width: 12
  }, external_react_default.a.createElement(external_semantic_ui_react_["Segment"], {
    inverted: true,
    color: "purple"
  }, external_react_default.a.createElement(external_semantic_ui_react_["Grid"], {
    columns: "equal",
    container: true
  }, external_react_default.a.createElement(external_semantic_ui_react_["Grid"].Row, null, external_react_default.a.createElement(external_semantic_ui_react_["Grid"].Column, {
    columns: "equal"
  }, external_react_default.a.createElement(external_semantic_ui_react_["Card"], {
    color: "purple"
  }, external_react_default.a.createElement(external_semantic_ui_react_["Card"].Content, null, external_react_default.a.createElement(external_semantic_ui_react_["Card"].Header, null, "Lucentes")), external_react_default.a.createElement(external_semantic_ui_react_["Card"].Content, {
    extra: true
  }, external_react_default.a.createElement(link_default.a, {
    href: '/chart?title=Lucente'
  }, external_react_default.a.createElement("a", null, "Mas Informaci\xF3n"))))), external_react_default.a.createElement(external_semantic_ui_react_["Grid"].Column, {
    columns: "equal"
  }, external_react_default.a.createElement(external_semantic_ui_react_["Card"], null, external_react_default.a.createElement(external_semantic_ui_react_["Card"].Content, {
    style: {
      'backgroundColor': 'black'
    }
  }, external_react_default.a.createElement(external_semantic_ui_react_["Card"].Header, {
    style: {
      'color': 'white'
    }
  }, "Opacas")), external_react_default.a.createElement(external_semantic_ui_react_["Card"].Content, {
    extra: true
  }, external_react_default.a.createElement(link_default.a, {
    href: '/chart?title=Opaca'
  }, external_react_default.a.createElement("a", null, "Mas Informaci\xF3n"))))), external_react_default.a.createElement(external_semantic_ui_react_["Grid"].Column, {
    columns: "equal"
  }, external_react_default.a.createElement(external_semantic_ui_react_["Card"], null, external_react_default.a.createElement(external_semantic_ui_react_["Card"].Content, {
    style: {
      'backgroundColor': 'grey'
    }
  }, external_react_default.a.createElement(external_semantic_ui_react_["Card"].Header, {
    style: {
      'color': 'white'
    }
  }, "Mixtas")), external_react_default.a.createElement(external_semantic_ui_react_["Card"].Content, {
    extra: true
  }, external_react_default.a.createElement(link_default.a, {
    href: '/chart?title=Mixta'
  }, external_react_default.a.createElement("a", null, "Mas Informaci\xF3n"))))), external_react_default.a.createElement(external_semantic_ui_react_["Grid"].Column, {
    columns: "equal"
  }, external_react_default.a.createElement(external_semantic_ui_react_["Card"], {
    color: "purple"
  }, external_react_default.a.createElement(external_semantic_ui_react_["Card"].Content, {
    style: {
      'backgroundColor': 'purple'
    }
  }, external_react_default.a.createElement(external_semantic_ui_react_["Card"].Header, {
    style: {
      'color': 'white'
    }
  }, "Todas")), external_react_default.a.createElement(external_semantic_ui_react_["Card"].Content, {
    extra: true
  }, external_react_default.a.createElement(link_default.a, {
    href: '/chart?title=todas'
  }, external_react_default.a.createElement("a", null, "Mas Informaci\xF3n")))))), injuries && injuries.length > 0 ? external_react_default.a.createElement(external_semantic_ui_react_["Grid"].Row, {
    columns: 3
  }, external_react_default.a.createElement(external_semantic_ui_react_["Grid"].Column, {
    width: 2
  }), external_react_default.a.createElement(external_semantic_ui_react_["Grid"].Column, null, external_react_default.a.createElement(external_semantic_ui_react_["Segment"], {
    inverted: true
  }, external_react_default.a.createElement(external_semantic_ui_react_["List"], {
    divided: true,
    verticalAlign: "middle"
  }, injuries.map(function (injury) {
    return external_react_default.a.createElement(external_semantic_ui_react_["List"].Item, {
      key: injury.injury_id
    }, external_react_default.a.createElement(external_semantic_ui_react_["List"].Content, {
      floated: "right"
    }, external_react_default.a.createElement(external_semantic_ui_react_["Button"], {
      onClick: function onClick() {
        return deleteInjury(injury.injury_id);
      }
    }, 'Eliminar')), external_react_default.a.createElement(external_semantic_ui_react_["List"].Content, null, ' ID: ' + injury.register_num + ' Registro:' + injury.register + ' Paciente: ' + injury.name + ' ' + injury.lastname));
  })))), external_react_default.a.createElement(external_semantic_ui_react_["Grid"].Column, {
    width: 2
  })) : null, external_react_default.a.createElement(external_semantic_ui_react_["Grid"].Row, null, external_react_default.a.createElement(external_semantic_ui_react_["Grid"].Column, {
    width: 10
  }), external_react_default.a.createElement(createinjurymodal_CreateInjuryModal, {
    callback: getInjuries
  }), external_react_default.a.createElement(external_semantic_ui_react_["Button"], {
    onClick: onLogout
  }, " Cerrar Sesion "))))), external_react_default.a.createElement(external_semantic_ui_react_["Grid"].Column, {
    width: 2
  }))));
};

/* harmony default export */ var main = __webpack_exports__["default"] = (Object(auth["c" /* withAuthSync */])(main_Main));

/***/ })
/******/ ]);