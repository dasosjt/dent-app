webpackHotUpdate("static/development/pages/chart.js",{

/***/ "./components/filterpie.jsx":
/*!**********************************!*\
  !*** ./components/filterpie.jsx ***!
  \**********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var recharts__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! recharts */ "./node_modules/recharts/es6/index.js");
/* harmony import */ var _configuration_options__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../configuration/options */ "./configuration/options.js");
var _jsxFileName = "/home/dsosa/Documents/dent-app/app/components/filterpie.jsx";




var FilterPie = function FilterPie(props) {
  //console.log(props)
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    style: {
      width: '100%',
      height: 500,
      padding: "0 0 0 15%"
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 16
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(recharts__WEBPACK_IMPORTED_MODULE_1__["ResponsiveContainer"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 17
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(recharts__WEBPACK_IMPORTED_MODULE_1__["PieChart"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 18
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(recharts__WEBPACK_IMPORTED_MODULE_1__["Pie"], {
    dataKey: "value",
    isAnimationActive: true,
    data: props.data,
    label: true,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 19
    },
    __self: this
  }, props.data.map(function (entry, index) {
    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(recharts__WEBPACK_IMPORTED_MODULE_1__["Cell"], {
      key: index,
      fill: _configuration_options__WEBPACK_IMPORTED_MODULE_2__["COLORS"][index % _configuration_options__WEBPACK_IMPORTED_MODULE_2__["COLORS"].length],
      __source: {
        fileName: _jsxFileName,
        lineNumber: 26
      },
      __self: this
    });
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(recharts__WEBPACK_IMPORTED_MODULE_1__["Legend"], {
    verticalAlign: "bottom",
    layout: "vertical",
    align: "right",
    wrapperStyle: {
      paddingLeft: "15px"
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 32
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(recharts__WEBPACK_IMPORTED_MODULE_1__["Tooltip"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 39
    },
    __self: this
  }))));
};

var renderLegend = function renderLegend(props) {
  var payload = props.payload;
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("ul", {
    class: "recharts-default-legend",
    style: {
      listStyle: "none"
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 49
    },
    __self: this
  }, payload.slice(0, 24).map(function (entry, index) {
    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("li", {
      key: "item-".concat(index),
      __source: {
        fileName: _jsxFileName,
        lineNumber: 53
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("svg", {
      class: "recharts-surface",
      width: "14",
      height: "14",
      style: {
        display: "inline-block",
        verticalAlign: "middle",
        marginRight: "4px"
      },
      viewBox: "0 0 32 32",
      version: "1.1",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 54
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("path", {
      stroke: "none",
      fill: entry.color,
      d: "M0,4h32v24h-32z",
      class: "recharts-legend-icon",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 61
      },
      __self: this
    })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("span", {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 64
      },
      __self: this
    }, entry.value, " "));
  }));
};

/* harmony default export */ __webpack_exports__["default"] = (FilterPie);

/***/ })

})
//# sourceMappingURL=chart.js.4e52dbe5055ba46bfe57.hot-update.js.map