module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 5);
/******/ })
/************************************************************************/
/******/ ({

/***/ "./components/createinjurymodal.jsx":
/*!******************************************!*\
  !*** ./components/createinjurymodal.jsx ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CreateInjuryModal; });
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-jsx/style */ "styled-jsx/style");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! semantic-ui-react */ "semantic-ui-react");
/* harmony import */ var semantic_ui_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./css */ "./components/css.jsx");
/* harmony import */ var _utils_functions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../utils/functions */ "./utils/functions.js");
/* harmony import */ var _configuration_options__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../configuration/options */ "./configuration/options.js");
var _jsxFileName = "/home/dsosa/Projects/dent-app/app/components/createinjurymodal.jsx";



function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






var DEFAULT_INIT_STATE = {
  'modalOpen': false,
  'locations': [_objectSpread({}, _configuration_options__WEBPACK_IMPORTED_MODULE_5__["DEFAULT_LOCATION"])],
  'tooths': [],
  'error': null,
  'name': null,
  'lastname': null,
  'register': null,
  'register_num': null,
  'gender': null,
  'age': null,
  '_type': null,
  'op1': null,
  'op2': null,
  'form': null,
  'op3': null,
  'size_0': null,
  'size_1': null,
  'size_2': null,
  'op4': null,
  'op5': null,
  'op5_type': null,
  'op6': null,
  'op7': null,
  'op8': null,
  'dif1': null,
  'dif2': null,
  'dif3': null
};

var CreateInjuryModal =
/*#__PURE__*/
function (_Component) {
  _inherits(CreateInjuryModal, _Component);

  function CreateInjuryModal(props) {
    var _this;

    _classCallCheck(this, CreateInjuryModal);

    _this = _possibleConstructorReturn(this, _getPrototypeOf(CreateInjuryModal).call(this, props));

    _defineProperty(_assertThisInitialized(_this), "teethOptions", []);

    _defineProperty(_assertThisInitialized(_this), "handleChange", function (e, _ref) {
      var name = _ref.name,
          value = _ref.value,
          checked = _ref.checked;
      console.log('handleChange');
      console.log("".concat(name, " ").concat(value, " ").concat(checked));

      if (value === undefined && checked !== undefined) {
        value = checked;
      }

      if (name === 'op4' && value === 'Asociada') {
        _this.checkTooth(value);
      } else if (name === 'op4' && value === 'No Asociado') {
        _this.removeToothByType('Asociada');
      } else if (name === 'op6' && value === 'Con Desplazamiento Piezas Dentarias') {
        _this.checkTooth(value);
      } else if (name === 'op6' && value === 'Sin Desplazamiento Piezas Dentarias') {
        _this.removeToothByType('Con Desplazamiento Piezas Dentarias');
      } else if (name === 'op8' && value === 'Pieza Incluida') {
        _this.checkTooth(value);
      } else if (name === 'op8' && value === 'Pieza No Incluida') {
        _this.removeToothByType('Pieza Incluida');
      }

      _this.setState(_defineProperty({}, name, value));
    });

    _defineProperty(_assertThisInitialized(_this), "handleLocationChange", function (e, _ref2) {
      var name = _ref2.name,
          value = _ref2.value;

      if (name <= _this.state.locations.length - 1) {
        var locations = _this.state.locations;
        locations[name]['location'] = value['name'];
        locations[name]['_type'] = value['type'];
        locations[name]['body_mandibula'] = false;
        locations[name]['sinus_maxilar'] = false;

        _this.setState({
          'locations': _toConsumableArray(locations)
        });
      }
    });

    _defineProperty(_assertThisInitialized(_this), "handleToothsChange", function (e, _ref3) {
      var name = _ref3.name,
          value = _ref3.value;

      if (name <= _this.state.tooths.length - 1) {
        var tooths = _toConsumableArray(_this.state.tooths);

        tooths[name]['location'] = value;

        _this.setState({
          'tooths': _toConsumableArray(tooths)
        });
      }
    });

    _defineProperty(_assertThisInitialized(_this), "handlePositionChange", function (e, _ref4) {
      var name = _ref4.name,
          value = _ref4.value;

      if (name <= _this.state.locations.length - 1) {
        var locations = _this.state.locations;
        locations[name]['position'] = value;

        _this.setState({
          'locations': _toConsumableArray(locations)
        });
      }
    });

    _defineProperty(_assertThisInitialized(_this), "handleBranchChange", function (e, _ref5) {
      var name = _ref5.name,
          value = _ref5.value;

      if (name <= _this.state.locations.length - 1) {
        var locations = _this.state.locations;
        locations[name]['branch_mandibula'] = value;

        _this.setState({
          'locations': _toConsumableArray(locations)
        });
      }
    });

    _defineProperty(_assertThisInitialized(_this), "handleWallChange", function (e, _ref6) {
      var name = _ref6.name,
          value = _ref6.value;

      if (name <= _this.state.locations.length - 1) {
        var locations = _this.state.locations;
        locations[name]['sinus_maxilar_wall'] = value;

        _this.setState({
          'locations': _toConsumableArray(locations)
        });
      }
    });

    _defineProperty(_assertThisInitialized(_this), "handleBodyChange", function (index, _ref7) {
      var name = _ref7.name,
          checked = _ref7.checked;

      if (name <= _this.state.locations.length - 1) {
        var locations = _this.state.locations;
        locations[name]['body_mandibula'] = checked;

        _this.setState({
          'locations': _toConsumableArray(locations)
        });
      }
    });

    _defineProperty(_assertThisInitialized(_this), "handleSinusChange", function (index, _ref8) {
      var name = _ref8.name,
          checked = _ref8.checked;

      if (name <= _this.state.locations.length - 1) {
        var locations = _this.state.locations;
        locations[name]['sinus_maxilar'] = checked;

        _this.setState({
          'locations': _toConsumableArray(locations)
        });
      }
    });

    _defineProperty(_assertThisInitialized(_this), "addLocation", function (e) {
      e.preventDefault();

      _this.setState(function (state) {
        return _objectSpread({}, state, {
          'locations': [].concat(_toConsumableArray(state.locations), [_objectSpread({}, _configuration_options__WEBPACK_IMPORTED_MODULE_5__["DEFAULT_LOCATION"])])
        });
      });
    });

    _defineProperty(_assertThisInitialized(_this), "removeLocation", function (e) {
      e.preventDefault();

      _this.setState(function (state) {
        var locations = _toConsumableArray(state.locations);

        locations.pop();

        if (locations.length > 0) {
          return _objectSpread({}, state, {
            locations: locations
          });
        } else {
          return _objectSpread({}, state);
        }
      });
    });

    _defineProperty(_assertThisInitialized(_this), "addTooth", function (currentType) {
      return function (e) {
        e.preventDefault();

        _this.setState(function (state) {
          var new_tooth = Object.assign({}, _configuration_options__WEBPACK_IMPORTED_MODULE_5__["DEFAULT_TOOTH"]);
          new_tooth['_type'] = currentType;
          new_tooth['index'] = state.tooths.length;
          return _objectSpread({}, state, {
            'tooths': [].concat(_toConsumableArray(state.tooths), [_objectSpread({}, new_tooth)])
          });
        });
      };
    });

    _defineProperty(_assertThisInitialized(_this), "removeTooth", function (index) {
      return function (e) {
        e.preventDefault();

        _this.removeToothByIndex(index);
      };
    });

    _this.state = Object.assign({}, DEFAULT_INIT_STATE);
    _this.teethOptions = _this.initTeethOptions();
    _this.handleOpen = _this.handleOpen.bind(_assertThisInitialized(_this));
    _this.handleClose = _this.handleClose.bind(_assertThisInitialized(_this));
    _this.handleSubmit = _this.handleSubmit.bind(_assertThisInitialized(_this));
    _this.handleChange = _this.handleChange.bind(_assertThisInitialized(_this));
    _this.handleBranchChange = _this.handleBranchChange.bind(_assertThisInitialized(_this));
    _this.handleBodyChange = _this.handleBodyChange.bind(_assertThisInitialized(_this));
    _this.handleSinusChange = _this.handleSinusChange.bind(_assertThisInitialized(_this));
    _this.handleWallChange = _this.handleWallChange.bind(_assertThisInitialized(_this));
    return _this;
  }

  _createClass(CreateInjuryModal, [{
    key: "initTeethOptions",
    value: function initTeethOptions() {
      var teethRange = Object(_utils_functions__WEBPACK_IMPORTED_MODULE_4__["range"])(1, 32).map(function (number) {
        var numberString = number.toString();
        return {
          'key': numberString,
          'value': numberString,
          'text': numberString
        };
      });
      return [].concat(_toConsumableArray(teethRange), [{
        'key': 'sp',
        'value': 'Super Numeraria',
        'text': 'Super Numeraria'
      }]);
    }
  }, {
    key: "handleOpen",
    value: function handleOpen() {
      this.setState(_objectSpread({}, DEFAULT_INIT_STATE));
      this.setState({
        'locations': [_objectSpread({}, _configuration_options__WEBPACK_IMPORTED_MODULE_5__["DEFAULT_LOCATION"])]
      });
      this.setState({
        'modalOpen': true
      });
    }
  }, {
    key: "handleClose",
    value: function handleClose() {
      this.setState({
        'modalOpen': false
      });
    }
  }, {
    key: "handleSubmit",
    value: function handleSubmit(e) {
      var _this2 = this;

      console.log("******************");
      console.log(e);
      console.log("******************");
      e.target.reset();
      var tmp_locations = this.state.locations;

      if (tmp_locations && tmp_locations.length < 2 && tmp_locations[0] === _configuration_options__WEBPACK_IMPORTED_MODULE_5__["DEFAULT_LOCATION"]) {
        this.setState('locations', []);
      }

      console.log(this.state);
      fetch('http://127.0.0.1:5000/injury', {
        method: 'POST',
        headers: new Headers({
          "Content-Type": "application/json",
          "Accept": "application/json"
        }),
        body: JSON.stringify(this.state)
      }).then(function (response) {
        _this2.setState(_objectSpread({}, DEFAULT_INIT_STATE));

        _this2.handleClose();
      }).catch(function (error) {
        _this2.setState({
          error: error
        });
      });
    }
  }, {
    key: "checkTooth",
    value: function checkTooth(currentType) {
      var tooths = this.state.tooths.filter(function (tooth) {
        return tooth._type === currentType;
      });

      if (tooths.length === 0) {
        this.setState(function (state) {
          var new_tooth = Object.assign({}, _configuration_options__WEBPACK_IMPORTED_MODULE_5__["DEFAULT_TOOTH"]);
          new_tooth['_type'] = currentType;
          new_tooth['index'] = state.tooths.length;
          return _objectSpread({}, state, {
            'tooths': [].concat(_toConsumableArray(state.tooths), [_objectSpread({}, new_tooth)])
          });
        });
      }
    }
  }, {
    key: "removeToothByType",
    value: function removeToothByType(currentType) {
      var _this3 = this;

      this.setState(function (state) {
        var tooths = _this3.state.tooths.filter(function (tooth) {
          return tooth._type !== currentType;
        });

        return _objectSpread({}, state, {
          'tooths': _this3.updateToothsIndex(tooths)
        });
      });
    }
  }, {
    key: "removeToothByTypeAndEmpty",
    value: function removeToothByTypeAndEmpty(currentType, cb) {
      var _this4 = this;

      this.setState(function (state) {
        var tooths = _this4.state.tooths.filter(function (tooth) {
          console.log(tooth.location);
          return tooth._type !== currentType && tooth.location === "";
        });

        return _objectSpread({}, state, {
          'tooths': _this4.updateToothsIndex(tooths)
        });
      }, cb());
    }
  }, {
    key: "removeToothByIndex",
    value: function removeToothByIndex(index) {
      var _this5 = this;

      this.setState(function (state) {
        var tooths = _this5.state.tooths.filter(function (tooth) {
          return tooth.index !== index;
        });

        return _objectSpread({}, state, {
          'tooths': _this5.updateToothsIndex(tooths)
        });
      });
    }
  }, {
    key: "updateToothsIndex",
    value: function updateToothsIndex(tooths) {
      var newTooths = _toConsumableArray(tooths.map(function (tooth, index) {
        tooth.index = index;
        return tooth;
      }));

      console.log(newTooths);
      return newTooths;
    }
  }, {
    key: "render",
    value: function render() {
      var _this6 = this;

      return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Modal"], {
        open: this.state.modalOpen,
        onClose: this.handleClose,
        trigger: react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Button"], {
          inverted: true,
          color: "purple",
          onClick: this.handleOpen,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 357
          },
          __self: this
        }, "Ingresar nueva lesi\xF3n"),
        __source: {
          fileName: _jsxFileName,
          lineNumber: 353
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Segment"], {
        inverted: true,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 364
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Modal"].Header, {
        as: "h1",
        style: {
          margin: 2
        },
        __source: {
          fileName: _jsxFileName,
          lineNumber: 365
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("b", {
        className: "jsx-2839058981",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 368
        },
        __self: this
      }, "Nueva Lesi\xF3n")), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Modal"].Content, {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 370
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Modal"].Description, {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 371
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"], {
        onSubmit: this.handleSubmit,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 372
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
        widths: "equal",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 374
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
        required: true,
        control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Input"],
        label: "Nombre",
        name: "name",
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 375
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
        required: true,
        control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Input"],
        label: "Apellido",
        name: "lastname",
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 381
        },
        __self: this
      })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
        widths: "equal",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 388
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
        required: true,
        control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Select"],
        label: "Registro",
        name: "register",
        options: _configuration_options__WEBPACK_IMPORTED_MODULE_5__["REGISTER"],
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 389
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
        required: true,
        control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Input"],
        label: "Registro",
        name: "register_num",
        type: "number",
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 396
        },
        __self: this
      })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
        widths: "equal",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 404
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
        required: true,
        control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Select"],
        label: "G\xE9nero",
        name: "gender",
        options: _configuration_options__WEBPACK_IMPORTED_MODULE_5__["GENDER"],
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 405
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
        required: true,
        control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Input"],
        label: "Edad",
        name: "age",
        type: "number",
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 412
        },
        __self: this
      })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
        required: true,
        control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Select"],
        label: "Aspecto General",
        name: "_type",
        options: _configuration_options__WEBPACK_IMPORTED_MODULE_5__["_TYPE"],
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 420
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
        inline: true,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 427
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Radio, {
        label: "\xDAnica",
        name: "op1",
        value: "\xDAnica",
        checked: this.state.op1 === 'Única',
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 428
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Radio, {
        label: "M\xFAltiple",
        name: "op1",
        value: "M\xFAltiple",
        checked: this.state.op1 === 'Múltiple',
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 434
        },
        __self: this
      })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
        inline: true,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 441
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Radio, {
        label: "Unilocular",
        name: "op2",
        value: "Unilocular",
        checked: this.state.op2 === 'Unilocular',
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 442
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Radio, {
        label: "Multilocular",
        name: "op2",
        value: "Multilocular",
        checked: this.state.op2 === 'Multilocular',
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 448
        },
        __self: this
      })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
        inline: true,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 455
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
        control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Select"],
        label: "Forma",
        name: "form",
        options: _configuration_options__WEBPACK_IMPORTED_MODULE_5__["FORM"],
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 456
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
        control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Select"],
        label: "Bordes",
        name: "op3",
        options: _configuration_options__WEBPACK_IMPORTED_MODULE_5__["OP3"],
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 462
        },
        __self: this
      })), this.state.locations.map(function (obj, index) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
          key: 'location' + index,
          inline: true,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 471
          },
          __self: this
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
          control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Select"],
          name: index,
          label: "Localizaci\xF3n",
          options: Object(_configuration_options__WEBPACK_IMPORTED_MODULE_5__["LOCATION"])(index),
          onChange: _this6.handleLocationChange,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 474
          },
          __self: this
        }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
          control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Select"],
          name: index,
          label: "Posici\xF3n",
          options: Object(_configuration_options__WEBPACK_IMPORTED_MODULE_5__["POSITION"])(index),
          onChange: _this6.handlePositionChange,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 480
          },
          __self: this
        }), obj.location === 'Mandíbula' ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
          control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Select"],
          label: "Rama",
          name: index,
          options: Object(_configuration_options__WEBPACK_IMPORTED_MODULE_5__["MANDIBULA_BRANCH"])(index),
          defaultValue: Object(_configuration_options__WEBPACK_IMPORTED_MODULE_5__["MANDIBULA_BRANCH"])(index)[0].value,
          onChange: _this6.handleBranchChange,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 489
          },
          __self: this
        }) : null, obj.location === 'Mandíbula' ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
          control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Checkbox"],
          label: "Cuerpo",
          name: index,
          onChange: _this6.handleBodyChange,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 500
          },
          __self: this
        }) : null, obj.location === 'Maxilar' ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
          control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Checkbox"],
          label: "Seno Maxilar",
          name: index,
          onChange: _this6.handleSinusChange,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 509
          },
          __self: this
        }) : null, obj.sinus_maxilar ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
          control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Select"],
          label: "Pared",
          name: index,
          options: Object(_configuration_options__WEBPACK_IMPORTED_MODULE_5__["SINUS_MAXILAR_WALL"])(index),
          defaultValue: Object(_configuration_options__WEBPACK_IMPORTED_MODULE_5__["SINUS_MAXILAR_WALL"])(index)[0].value,
          onChange: _this6.handleWallChange,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 518
          },
          __self: this
        }) : null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", {
          key: 'br' + index,
          className: "jsx-2839058981",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 527
          },
          __self: this
        }), controlOnlyToLast(index, _this6.state.locations, _this6.addLocation, _this6.removeLocation));
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 537
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
        control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Input"],
        label: "Eje Mayor",
        name: "size_0",
        type: "number",
        step: "0.1",
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 538
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
        control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Input"],
        label: "Eje Menor",
        name: "size_1",
        type: "number",
        step: "0.1",
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 545
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
        control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Input"],
        label: "Diametro",
        name: "size_2",
        type: "number",
        step: "0.1",
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 552
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("label", {
        className: "jsx-2839058981",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 559
        },
        __self: this
      }, "mm")), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
        inline: true,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 561
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Radio, {
        label: "Asociada",
        name: "op4",
        value: "Asociada",
        checked: this.state.op4 === 'Asociada',
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 562
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Radio, {
        label: "No Asociado",
        name: "op4",
        value: "No Asociado",
        checked: this.state.op4 === 'No Asociado',
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 568
        },
        __self: this
      })), this.state.op4 === 'Asociada' ? this.state.tooths.filter(function (t) {
        return t._type === 'Asociada';
      }).map(function (obj, index) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
          key: 'tooth' + index,
          inline: true,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 580
          },
          __self: this
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
          required: true,
          control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Select"],
          name: obj.index,
          label: "Pieza Dental",
          options: _this6.teethOptions,
          onChange: _this6.handleToothsChange,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 583
          },
          __self: this
        }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", {
          key: 'br' + index,
          className: "jsx-2839058981",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 590
          },
          __self: this
        }), controlOnlyToLast(obj.index, _this6.state.tooths, _this6.addTooth('Asociada'), _this6.removeTooth(obj.index)));
      }) : null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
        inline: true,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 602
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Radio, {
        label: "Con Reabsorci\xF3n",
        name: "op5",
        value: "Con Reabsorci\xF3n",
        checked: this.state.op5 === 'Con Reabsorción',
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 603
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Radio, {
        label: "Sin Reabsorci\xF3n",
        name: "op5",
        value: "Sin Reabsorci\xF3n",
        checked: this.state.op5 === 'Sin Reabsorción',
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 609
        },
        __self: this
      }), this.state.op5 === 'Con Reabsorción' ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
        required: true,
        control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Select"],
        label: "Tipo",
        name: "op5_type",
        options: _configuration_options__WEBPACK_IMPORTED_MODULE_5__["OP5_TYPE"],
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 617
        },
        __self: this
      }) : null), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
        inline: true,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 627
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Radio, {
        label: "Con Desplazamiento Piezas Dentarias",
        name: "op6",
        value: "Con Desplazamiento Piezas Dentarias",
        checked: this.state.op6 === 'Con Desplazamiento Piezas Dentarias',
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 628
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Radio, {
        label: "Sin Desplazamiento Piezas Dentarias",
        name: "op6",
        value: "Sin Desplazamiento Piezas Dentarias",
        checked: this.state.op6 === 'Sin Desplazamiento Piezas Dentarias',
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 634
        },
        __self: this
      })), this.state.op6 === 'Con Desplazamiento Piezas Dentarias' ? this.state.tooths.filter(function (t) {
        return t._type === 'Con Desplazamiento Piezas Dentarias';
      }).map(function (obj, index) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
          key: 'tooth' + index,
          inline: true,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 647
          },
          __self: this
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
          required: true,
          control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Select"],
          name: obj.index,
          label: "Pieza Dental",
          options: _this6.teethOptions,
          onChange: _this6.handleToothsChange,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 650
          },
          __self: this
        }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", {
          key: 'br' + index,
          className: "jsx-2839058981",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 657
          },
          __self: this
        }), controlOnlyToLast(obj.index, _this6.state.tooths, _this6.addTooth('Con Desplazamiento Piezas Dentarias'), _this6.removeTooth(obj.index)));
      }) : null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
        inline: true,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 669
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Radio, {
        label: "Con Expansi\xF3n de Corticales",
        name: "op7",
        value: "Con Expansi\xF3n de Corticales",
        checked: this.state.op7 === 'Con Expansión de Corticales',
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 670
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Radio, {
        label: "Sin Expansi\xF3n de Corticales",
        name: "op7",
        value: "Sin Expansi\xF3n de Corticales",
        checked: this.state.op7 === 'Sin Expansión de Corticales',
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 676
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Radio, {
        label: "No aplica",
        name: "op7",
        value: "No aplica",
        checked: this.state.op7 === 'No aplica',
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 682
        },
        __self: this
      })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
        inline: true,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 689
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Radio, {
        label: "Pieza Incluida",
        name: "op8",
        value: "Pieza Incluida",
        checked: this.state.op8 === 'Pieza Incluida',
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 690
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Radio, {
        label: "Pieza No Incluida",
        name: "op8",
        value: "Pieza No Incluida",
        checked: this.state.op8 === 'Pieza No Incluida',
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 696
        },
        __self: this
      })), this.state.op8 === 'Pieza Incluida' ? this.state.tooths.filter(function (t) {
        return t._type === 'Pieza Incluida';
      }).map(function (obj, index) {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
          key: 'tooth' + index,
          inline: true,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 708
          },
          __self: this
        }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
          required: true,
          control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Select"],
          name: obj.index,
          label: "Pieza Dental",
          options: _this6.teethOptions,
          onChange: _this6.handleToothsChange,
          __source: {
            fileName: _jsxFileName,
            lineNumber: 711
          },
          __self: this
        }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("br", {
          key: 'br' + index,
          className: "jsx-2839058981",
          __source: {
            fileName: _jsxFileName,
            lineNumber: 718
          },
          __self: this
        }), controlOnlyToLast(obj.index, _this6.state.tooths, _this6.addTooth('Pieza Incluida'), _this6.removeTooth(obj.index)));
      }) : null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Group, {
        inline: true,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 730
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("label", {
        className: "jsx-2839058981",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 731
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("b", {
        className: "jsx-2839058981",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 731
        },
        __self: this
      }, "Diagn\xF3stico Diferencial")), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
        required: true,
        control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Input"],
        name: "dif1",
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 732
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
        control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Input"],
        name: "dif2",
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 737
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Form"].Field, {
        control: semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Input"],
        name: "dif3",
        onChange: this.handleChange,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 741
        },
        __self: this
      })), this.state.error ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Message"], {
        negative: true,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 748
        },
        __self: this
      }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Message"].Header, {
        __source: {
          fileName: _jsxFileName,
          lineNumber: 749
        },
        __self: this
      }, "Error"), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("p", {
        className: "jsx-2839058981",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 750
        },
        __self: this
      }, "La lesi\xF3n no pudo ser ingresada")) : null, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Button"], {
        inverted: true,
        color: "purple",
        content: "Enviar",
        type: "submit",
        __source: {
          fileName: _jsxFileName,
          lineNumber: 753
        },
        __self: this
      }), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Button"], {
        inverted: true,
        color: "grey",
        content: "Cancelar",
        onClick: this.handleClose,
        __source: {
          fileName: _jsxFileName,
          lineNumber: 754
        },
        __self: this
      }))))), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a, {
        styleId: "2839058981",
        css: "b.jsx-2839058981,label.jsx-2839058981{color:white;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9ob21lL2Rzb3NhL1Byb2plY3RzL2RlbnQtYXBwL2FwcC9jb21wb25lbnRzL2NyZWF0ZWluanVyeW1vZGFsLmpzeCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFzdkI0QixBQUdxQyxZQUNoQiIsImZpbGUiOiIvaG9tZS9kc29zYS9Qcm9qZWN0cy9kZW50LWFwcC9hcHAvY29tcG9uZW50cy9jcmVhdGVpbmp1cnltb2RhbC5qc3giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7XG4gICAgRm9ybSxcbiAgICBCdXR0b24sXG4gICAgTW9kYWwsXG4gICAgSW5wdXQsXG4gICAgU2VsZWN0LFxuICAgIFNlZ21lbnQsXG4gICAgSWNvbixcbiAgICBDaGVja2JveCxcbiAgICBNZXNzYWdlXG59IGZyb20gJ3NlbWFudGljLXVpLXJlYWN0J1xuaW1wb3J0IENTUyBmcm9tICcuL2NzcydcbmltcG9ydCB7IHJhbmdlIH0gZnJvbSAnLi4vdXRpbHMvZnVuY3Rpb25zJ1xuaW1wb3J0IHtcbiAgICBERUZBVUxUX0xPQ0FUSU9OLCBERUZBVUxUX1RPT1RILFxuICAgIFJFR0lTVEVSLCBHRU5ERVIsIF9UWVBFLFxuICAgIEZPUk0sIE9QMywgTE9DQVRJT04sIFBPU0lUSU9OLFxuICAgIE1BTkRJQlVMQV9CUkFOQ0gsIE9QNV9UWVBFLCBTSU5VU19NQVhJTEFSX1dBTExcbn0gZnJvbSAnLi4vY29uZmlndXJhdGlvbi9vcHRpb25zJ1xuXG5jb25zdCBERUZBVUxUX0lOSVRfU1RBVEUgPSB7XG4gICAgJ21vZGFsT3Blbic6IGZhbHNlLFxuICAgICdsb2NhdGlvbnMnOiBbeyAuLi5ERUZBVUxUX0xPQ0FUSU9OIH1dLFxuICAgICd0b290aHMnOiBbXSxcbiAgICAnZXJyb3InOiBudWxsLFxuICAgICduYW1lJzogbnVsbCxcbiAgICAnbGFzdG5hbWUnOiBudWxsLFxuICAgICdyZWdpc3Rlcic6IG51bGwsXG4gICAgJ3JlZ2lzdGVyX251bSc6IG51bGwsXG4gICAgJ2dlbmRlcic6IG51bGwsXG4gICAgJ2FnZSc6IG51bGwsXG4gICAgJ190eXBlJzogbnVsbCxcbiAgICAnb3AxJzogbnVsbCxcbiAgICAnb3AyJzogbnVsbCxcbiAgICAnZm9ybSc6IG51bGwsXG4gICAgJ29wMyc6IG51bGwsXG4gICAgJ3NpemVfMCc6IG51bGwsXG4gICAgJ3NpemVfMSc6IG51bGwsXG4gICAgJ3NpemVfMic6IG51bGwsXG4gICAgJ29wNCc6IG51bGwsXG4gICAgJ29wNSc6IG51bGwsXG4gICAgJ29wNV90eXBlJzogbnVsbCxcbiAgICAnb3A2JzogbnVsbCxcbiAgICAnb3A3JzogbnVsbCxcbiAgICAnb3A4JzogbnVsbCxcbiAgICAnZGlmMSc6IG51bGwsXG4gICAgJ2RpZjInOiBudWxsLFxuICAgICdkaWYzJzogbnVsbCxcbn1cblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgQ3JlYXRlSW5qdXJ5TW9kYWwgZXh0ZW5kcyBDb21wb25lbnQge1xuICAgIHRlZXRoT3B0aW9ucyA9IFtdXG5cbiAgICBjb25zdHJ1Y3Rvcihwcm9wcyl7XG4gICAgICAgIHN1cGVyKHByb3BzKVxuXG4gICAgICAgIHRoaXMuc3RhdGUgPSBPYmplY3QuYXNzaWduKHt9LCBERUZBVUxUX0lOSVRfU1RBVEUpXG5cbiAgICAgICAgdGhpcy50ZWV0aE9wdGlvbnMgPSB0aGlzLmluaXRUZWV0aE9wdGlvbnMoKVxuXG4gICAgICAgIHRoaXMuaGFuZGxlT3BlbiA9IHRoaXMuaGFuZGxlT3Blbi5iaW5kKHRoaXMpXG4gICAgICAgIHRoaXMuaGFuZGxlQ2xvc2UgPSB0aGlzLmhhbmRsZUNsb3NlLmJpbmQodGhpcylcbiAgICAgICAgdGhpcy5oYW5kbGVTdWJtaXQgPSB0aGlzLmhhbmRsZVN1Ym1pdC5iaW5kKHRoaXMpXG4gICAgICAgIHRoaXMuaGFuZGxlQ2hhbmdlID0gdGhpcy5oYW5kbGVDaGFuZ2UuYmluZCh0aGlzKVxuICAgICAgICB0aGlzLmhhbmRsZUJyYW5jaENoYW5nZSA9IHRoaXMuaGFuZGxlQnJhbmNoQ2hhbmdlLmJpbmQodGhpcylcbiAgICAgICAgdGhpcy5oYW5kbGVCb2R5Q2hhbmdlID0gdGhpcy5oYW5kbGVCb2R5Q2hhbmdlLmJpbmQodGhpcylcbiAgICAgICAgdGhpcy5oYW5kbGVTaW51c0NoYW5nZSA9IHRoaXMuaGFuZGxlU2ludXNDaGFuZ2UuYmluZCh0aGlzKVxuICAgICAgICB0aGlzLmhhbmRsZVdhbGxDaGFuZ2UgPSB0aGlzLmhhbmRsZVdhbGxDaGFuZ2UuYmluZCh0aGlzKVxuICAgIH1cblxuICAgIGluaXRUZWV0aE9wdGlvbnMoKXtcbiAgICAgICAgY29uc3QgdGVldGhSYW5nZSA9IHJhbmdlKDEsIDMyKS5tYXAoXG4gICAgICAgICAgICBudW1iZXIgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IG51bWJlclN0cmluZyA9IG51bWJlci50b1N0cmluZygpXG4gICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgJ2tleSc6IG51bWJlclN0cmluZyxcbiAgICAgICAgICAgICAgICAgICAgJ3ZhbHVlJzogbnVtYmVyU3RyaW5nLFxuICAgICAgICAgICAgICAgICAgICAndGV4dCc6IG51bWJlclN0cmluZ1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgKVxuXG4gICAgICAgIHJldHVybiBbXG4gICAgICAgICAgICAuLi50ZWV0aFJhbmdlLFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICdrZXknOiAnc3AnLFxuICAgICAgICAgICAgICAgICd2YWx1ZSc6ICdTdXBlciBOdW1lcmFyaWEnLFxuICAgICAgICAgICAgICAgICd0ZXh0JzogJ1N1cGVyIE51bWVyYXJpYSdcbiAgICAgICAgICAgIH1cbiAgICAgICAgXVxuICAgIH1cblxuICAgIGhhbmRsZU9wZW4oKXtcbiAgICAgICAgdGhpcy5zZXRTdGF0ZSh7Li4uREVGQVVMVF9JTklUX1NUQVRFfSlcbiAgICAgICAgdGhpcy5zZXRTdGF0ZSh7ICdsb2NhdGlvbnMnOiBbeyAuLi5ERUZBVUxUX0xPQ0FUSU9OIH1dIH0pXG4gICAgICAgIHRoaXMuc2V0U3RhdGUoeyAnbW9kYWxPcGVuJzogdHJ1ZSB9KVxuICAgIH1cblxuICAgIGhhbmRsZUNsb3NlKCl7XG4gICAgICAgIHRoaXMuc2V0U3RhdGUoeyAnbW9kYWxPcGVuJzogZmFsc2UgfSlcbiAgICB9XG5cbiAgICBoYW5kbGVDaGFuZ2UgPSAoZSwgeyBuYW1lLCB2YWx1ZSwgY2hlY2tlZCB9KSA9PiB7XG4gICAgICAgIGNvbnNvbGUubG9nKCdoYW5kbGVDaGFuZ2UnKVxuICAgICAgICBjb25zb2xlLmxvZyhgJHtuYW1lfSAke3ZhbHVlfSAke2NoZWNrZWR9YClcbiAgICAgICAgaWYgKHZhbHVlID09PSB1bmRlZmluZWQgJiYgY2hlY2tlZCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICB2YWx1ZSA9IGNoZWNrZWRcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChuYW1lID09PSAnb3A0JyAmJiB2YWx1ZSA9PT0gJ0Fzb2NpYWRhJykge1xuICAgICAgICAgICAgdGhpcy5jaGVja1Rvb3RoKHZhbHVlKVxuICAgICAgICB9IGVsc2UgaWYgKG5hbWUgPT09ICdvcDQnICYmIHZhbHVlID09PSAnTm8gQXNvY2lhZG8nKSB7XG4gICAgICAgICAgICB0aGlzLnJlbW92ZVRvb3RoQnlUeXBlKCdBc29jaWFkYScpXG4gICAgICAgIH0gZWxzZSBpZiAobmFtZSA9PT0gJ29wNicgJiYgdmFsdWUgPT09ICdDb24gRGVzcGxhemFtaWVudG8gUGllemFzIERlbnRhcmlhcycpIHtcbiAgICAgICAgICAgIHRoaXMuY2hlY2tUb290aCh2YWx1ZSlcbiAgICAgICAgfSBlbHNlIGlmIChuYW1lID09PSAnb3A2JyAmJiB2YWx1ZSA9PT0gJ1NpbiBEZXNwbGF6YW1pZW50byBQaWV6YXMgRGVudGFyaWFzJykge1xuICAgICAgICAgICAgdGhpcy5yZW1vdmVUb290aEJ5VHlwZSgnQ29uIERlc3BsYXphbWllbnRvIFBpZXphcyBEZW50YXJpYXMnKVxuICAgICAgICB9IGVsc2UgaWYgKG5hbWUgPT09ICdvcDgnICYmIHZhbHVlID09PSAnUGllemEgSW5jbHVpZGEnKSB7XG4gICAgICAgICAgICB0aGlzLmNoZWNrVG9vdGgodmFsdWUpXG4gICAgICAgIH0gZWxzZSBpZiAobmFtZSA9PT0gJ29wOCcgJiYgdmFsdWUgPT09ICdQaWV6YSBObyBJbmNsdWlkYScpIHtcbiAgICAgICAgICAgIHRoaXMucmVtb3ZlVG9vdGhCeVR5cGUoJ1BpZXphIEluY2x1aWRhJylcbiAgICAgICAgfVxuXG4gICAgICAgIHRoaXMuc2V0U3RhdGUoeyBbbmFtZV06IHZhbHVlIH0pXG4gICAgfVxuXG4gICAgaGFuZGxlTG9jYXRpb25DaGFuZ2UgPSAoZSwgeyBuYW1lLCB2YWx1ZSB9KSA9PiB7XG4gICAgICAgIGlmKG5hbWUgPD0gdGhpcy5zdGF0ZS5sb2NhdGlvbnMubGVuZ3RoIC0gMSl7XG4gICAgICAgICAgICBsZXQgbG9jYXRpb25zID0gdGhpcy5zdGF0ZS5sb2NhdGlvbnNcblxuICAgICAgICAgICAgbG9jYXRpb25zW25hbWVdWydsb2NhdGlvbiddID0gdmFsdWVbJ25hbWUnXVxuICAgICAgICAgICAgbG9jYXRpb25zW25hbWVdWydfdHlwZSddID0gdmFsdWVbJ3R5cGUnXVxuICAgICAgICAgICAgbG9jYXRpb25zW25hbWVdWydib2R5X21hbmRpYnVsYSddID0gZmFsc2VcbiAgICAgICAgICAgIGxvY2F0aW9uc1tuYW1lXVsnc2ludXNfbWF4aWxhciddID0gZmFsc2VcblxuICAgICAgICAgICAgdGhpcy5zZXRTdGF0ZSh7ICdsb2NhdGlvbnMnOiAgWy4uLmxvY2F0aW9uc10gfSlcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGhhbmRsZVRvb3Roc0NoYW5nZSA9IChlLCB7IG5hbWUsIHZhbHVlIH0pID0+IHtcbiAgICAgICAgaWYobmFtZSA8PSB0aGlzLnN0YXRlLnRvb3Rocy5sZW5ndGggLSAxKXtcbiAgICAgICAgICAgIGxldCB0b290aHMgPSBbLi4udGhpcy5zdGF0ZS50b290aHNdXG5cbiAgICAgICAgICAgIHRvb3Roc1tuYW1lXVsnbG9jYXRpb24nXSA9IHZhbHVlXG5cbiAgICAgICAgICAgIHRoaXMuc2V0U3RhdGUoeyAndG9vdGhzJzogIFsuLi50b290aHNdIH0pXG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBoYW5kbGVQb3NpdGlvbkNoYW5nZSA9IChlLCB7IG5hbWUsIHZhbHVlIH0pID0+IHtcbiAgICAgICAgaWYobmFtZSA8PSB0aGlzLnN0YXRlLmxvY2F0aW9ucy5sZW5ndGggLSAxKXtcbiAgICAgICAgICAgIGxldCBsb2NhdGlvbnMgPSB0aGlzLnN0YXRlLmxvY2F0aW9uc1xuICAgICAgICAgICAgbG9jYXRpb25zW25hbWVdWydwb3NpdGlvbiddID0gdmFsdWVcblxuICAgICAgICAgICAgdGhpcy5zZXRTdGF0ZSh7ICdsb2NhdGlvbnMnOiAgWy4uLmxvY2F0aW9uc10gfSlcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGhhbmRsZUJyYW5jaENoYW5nZSA9IChlLCB7IG5hbWUsICB2YWx1ZSB9KSA9PiB7XG4gICAgICAgIGlmKG5hbWUgPD0gdGhpcy5zdGF0ZS5sb2NhdGlvbnMubGVuZ3RoIC0gMSl7XG4gICAgICAgICAgICBsZXQgbG9jYXRpb25zID0gdGhpcy5zdGF0ZS5sb2NhdGlvbnNcbiAgICAgICAgICAgIGxvY2F0aW9uc1tuYW1lXVsnYnJhbmNoX21hbmRpYnVsYSddID0gdmFsdWVcblxuICAgICAgICAgICAgdGhpcy5zZXRTdGF0ZSh7ICdsb2NhdGlvbnMnOiAgWy4uLmxvY2F0aW9uc10gfSlcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGhhbmRsZVdhbGxDaGFuZ2UgPSAoZSwgeyBuYW1lLCAgdmFsdWUgfSkgPT4ge1xuICAgICAgICBpZihuYW1lIDw9IHRoaXMuc3RhdGUubG9jYXRpb25zLmxlbmd0aCAtIDEpe1xuICAgICAgICAgICAgbGV0IGxvY2F0aW9ucyA9IHRoaXMuc3RhdGUubG9jYXRpb25zXG4gICAgICAgICAgICBsb2NhdGlvbnNbbmFtZV1bJ3NpbnVzX21heGlsYXJfd2FsbCddID0gdmFsdWVcblxuICAgICAgICAgICAgdGhpcy5zZXRTdGF0ZSh7ICdsb2NhdGlvbnMnOiAgWy4uLmxvY2F0aW9uc10gfSlcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGhhbmRsZUJvZHlDaGFuZ2UgPSAoaW5kZXgsIHsgbmFtZSwgY2hlY2tlZCB9KSA9PiB7XG4gICAgICAgIGlmKG5hbWUgPD0gdGhpcy5zdGF0ZS5sb2NhdGlvbnMubGVuZ3RoIC0gMSl7XG4gICAgICAgICAgICBsZXQgbG9jYXRpb25zID0gdGhpcy5zdGF0ZS5sb2NhdGlvbnNcbiAgICAgICAgICAgIGxvY2F0aW9uc1tuYW1lXVsnYm9keV9tYW5kaWJ1bGEnXSA9IGNoZWNrZWRcblxuICAgICAgICAgICAgdGhpcy5zZXRTdGF0ZSh7ICdsb2NhdGlvbnMnOiAgWy4uLmxvY2F0aW9uc10gfSlcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGhhbmRsZVNpbnVzQ2hhbmdlID0gKGluZGV4LCB7IG5hbWUsIGNoZWNrZWQgfSkgPT4ge1xuICAgICAgICBpZihuYW1lIDw9IHRoaXMuc3RhdGUubG9jYXRpb25zLmxlbmd0aCAtIDEpe1xuICAgICAgICAgICAgbGV0IGxvY2F0aW9ucyA9IHRoaXMuc3RhdGUubG9jYXRpb25zXG4gICAgICAgICAgICBsb2NhdGlvbnNbbmFtZV1bJ3NpbnVzX21heGlsYXInXSA9IGNoZWNrZWRcblxuICAgICAgICAgICAgdGhpcy5zZXRTdGF0ZSh7ICdsb2NhdGlvbnMnOiAgWy4uLmxvY2F0aW9uc10gfSlcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGFkZExvY2F0aW9uID0gZSA9PiB7XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgICAgICB0aGlzLnNldFN0YXRlKHN0YXRlID0+ICh7XG4gICAgICAgICAgICAuLi5zdGF0ZSxcbiAgICAgICAgICAgICdsb2NhdGlvbnMnOiBbXG4gICAgICAgICAgICAgICAgLi4uc3RhdGUubG9jYXRpb25zLFxuICAgICAgICAgICAgICAgIHsgLi4uREVGQVVMVF9MT0NBVElPTiB9XG4gICAgICAgICAgICBdXG4gICAgICAgIH0pKVxuICAgIH1cblxuICAgIHJlbW92ZUxvY2F0aW9uID0gZSA9PiB7XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgICAgICB0aGlzLnNldFN0YXRlKHN0YXRlID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGxvY2F0aW9ucyA9IFsgLi4uc3RhdGUubG9jYXRpb25zIF1cbiAgICAgICAgICAgIGxvY2F0aW9ucy5wb3AoKVxuXG4gICAgICAgICAgICBpZihsb2NhdGlvbnMubGVuZ3RoID4gMCl7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgLi4uc3RhdGUsXG4gICAgICAgICAgICAgICAgICAgIGxvY2F0aW9ucyxcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHJldHVybiB7Li4uc3RhdGV9XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pXG4gICAgfVxuXG4gICAgYWRkVG9vdGggPSBjdXJyZW50VHlwZSA9PiBlID0+IHtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpXG4gICAgICAgIHRoaXMuc2V0U3RhdGUoc3RhdGUgPT4ge1xuICAgICAgICAgICAgbGV0IG5ld190b290aCA9IE9iamVjdC5hc3NpZ24oe30sIERFRkFVTFRfVE9PVEgpXG4gICAgICAgICAgICBuZXdfdG9vdGhbJ190eXBlJ10gPSBjdXJyZW50VHlwZVxuICAgICAgICAgICAgbmV3X3Rvb3RoWydpbmRleCddID0gc3RhdGUudG9vdGhzLmxlbmd0aFxuXG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIC4uLnN0YXRlLFxuICAgICAgICAgICAgICAgICd0b290aHMnOiBbXG4gICAgICAgICAgICAgICAgICAgIC4uLnN0YXRlLnRvb3RocyxcbiAgICAgICAgICAgICAgICAgICAgeyAuLi5uZXdfdG9vdGggfVxuICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfSlcbiAgICB9XG5cbiAgICByZW1vdmVUb290aCA9IGluZGV4ID0+IGUgPT4ge1xuICAgICAgICBlLnByZXZlbnREZWZhdWx0KClcbiAgICAgICAgdGhpcy5yZW1vdmVUb290aEJ5SW5kZXgoaW5kZXgpXG4gICAgfVxuXG4gICAgaGFuZGxlU3VibWl0KGUpe1xuICAgICAgICBjb25zb2xlLmxvZyhcIioqKioqKioqKioqKioqKioqKlwiKVxuICAgICAgICBjb25zb2xlLmxvZyhlKVxuICAgICAgICBjb25zb2xlLmxvZyhcIioqKioqKioqKioqKioqKioqKlwiKVxuICAgICAgICBlLnRhcmdldC5yZXNldCgpXG4gICAgICAgIGNvbnN0IHRtcF9sb2NhdGlvbnMgPSB0aGlzLnN0YXRlLmxvY2F0aW9uc1xuXG4gICAgICAgIGlmICh0bXBfbG9jYXRpb25zICYmIHRtcF9sb2NhdGlvbnMubGVuZ3RoIDwgMiAmJiB0bXBfbG9jYXRpb25zWzBdID09PSBERUZBVUxUX0xPQ0FUSU9OKXtcbiAgICAgICAgICAgIHRoaXMuc2V0U3RhdGUoJ2xvY2F0aW9ucycsIFtdKVxuICAgICAgICB9XG5cbiAgICAgICAgY29uc29sZS5sb2codGhpcy5zdGF0ZSlcblxuICAgICAgICBmZXRjaCgnaHR0cDovLzEyNy4wLjAuMTo1MDAwL2luanVyeScsIHtcbiAgICAgICAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgICAgICAgICBoZWFkZXJzOiBuZXcgSGVhZGVycyh7XG4gICAgICAgICAgICAgICAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiLFxuICAgICAgICAgICAgICAgICAgICBcIkFjY2VwdFwiOlwiYXBwbGljYXRpb24vanNvblwiXG4gICAgICAgICAgICAgICAgfSksXG4gICAgICAgICAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkodGhpcy5zdGF0ZSlcbiAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5zZXRTdGF0ZSh7Li4uREVGQVVMVF9JTklUX1NUQVRFfSlcbiAgICAgICAgICAgICAgICB0aGlzLmhhbmRsZUNsb3NlKClcbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAuY2F0Y2goKGVycm9yKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5zZXRTdGF0ZSh7IGVycm9yIH0pXG4gICAgICAgICAgICB9KVxuICAgIH1cblxuICAgIGNoZWNrVG9vdGgoY3VycmVudFR5cGUpe1xuICAgICAgICBjb25zdCB0b290aHMgPSB0aGlzLnN0YXRlLnRvb3Rocy5maWx0ZXIoXG4gICAgICAgICAgICB0b290aCA9PiB0b290aC5fdHlwZSA9PT0gY3VycmVudFR5cGVcbiAgICAgICAgKVxuXG4gICAgICAgIGlmICh0b290aHMubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICB0aGlzLnNldFN0YXRlKHN0YXRlID0+IHtcbiAgICAgICAgICAgICAgICBsZXQgbmV3X3Rvb3RoID0gT2JqZWN0LmFzc2lnbih7fSwgREVGQVVMVF9UT09USClcbiAgICAgICAgICAgICAgICBuZXdfdG9vdGhbJ190eXBlJ10gPSBjdXJyZW50VHlwZVxuICAgICAgICAgICAgICAgIG5ld190b290aFsnaW5kZXgnXSA9IHN0YXRlLnRvb3Rocy5sZW5ndGhcbiAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgICAuLi5zdGF0ZSxcbiAgICAgICAgICAgICAgICAgICAgJ3Rvb3Rocyc6IFtcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLnN0YXRlLnRvb3RocyxcbiAgICAgICAgICAgICAgICAgICAgICAgIHsgLi4ubmV3X3Rvb3RoIH1cbiAgICAgICAgICAgICAgICAgICAgXVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pXG4gICAgICAgIH1cbiAgICB9XG5cbiAgICByZW1vdmVUb290aEJ5VHlwZShjdXJyZW50VHlwZSl7XG4gICAgICAgIHRoaXMuc2V0U3RhdGUoc3RhdGUgPT4ge1xuICAgICAgICAgICAgY29uc3QgdG9vdGhzID0gdGhpcy5zdGF0ZS50b290aHMuZmlsdGVyKFxuICAgICAgICAgICAgICAgIHRvb3RoID0+IHRvb3RoLl90eXBlICE9PSBjdXJyZW50VHlwZVxuICAgICAgICAgICAgKVxuXG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIC4uLnN0YXRlLFxuICAgICAgICAgICAgICAgICd0b290aHMnOiB0aGlzLnVwZGF0ZVRvb3Roc0luZGV4KHRvb3RocylcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSlcbiAgICB9XG5cbiAgICByZW1vdmVUb290aEJ5VHlwZUFuZEVtcHR5KGN1cnJlbnRUeXBlLCBjYil7XG4gICAgICAgIHRoaXMuc2V0U3RhdGUoc3RhdGUgPT4ge1xuICAgICAgICAgICAgbGV0IHRvb3RocyA9IHRoaXMuc3RhdGUudG9vdGhzLmZpbHRlcihcbiAgICAgICAgICAgICAgICB0b290aCA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKHRvb3RoLmxvY2F0aW9uKVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdG9vdGguX3R5cGUgIT09IGN1cnJlbnRUeXBlICYmIHRvb3RoLmxvY2F0aW9uID09PSBcIlwiXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgKVxuXG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIC4uLnN0YXRlLFxuICAgICAgICAgICAgICAgICd0b290aHMnOiB0aGlzLnVwZGF0ZVRvb3Roc0luZGV4KHRvb3RocylcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSwgY2IoKSlcbiAgICB9XG5cbiAgICByZW1vdmVUb290aEJ5SW5kZXgoaW5kZXgpIHtcbiAgICAgICAgdGhpcy5zZXRTdGF0ZShzdGF0ZSA9PiB7XG4gICAgICAgICAgICBjb25zdCB0b290aHMgPSB0aGlzLnN0YXRlLnRvb3Rocy5maWx0ZXIoXG4gICAgICAgICAgICAgICAgdG9vdGggPT4gdG9vdGguaW5kZXggIT09IGluZGV4XG4gICAgICAgICAgICApXG5cbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgLi4uc3RhdGUsXG4gICAgICAgICAgICAgICAgJ3Rvb3Rocyc6IHRoaXMudXBkYXRlVG9vdGhzSW5kZXgodG9vdGhzKVxuICAgICAgICAgICAgfVxuICAgICAgICB9KVxuICAgIH1cblxuICAgIHVwZGF0ZVRvb3Roc0luZGV4KHRvb3Rocykge1xuICAgICAgICBjb25zdCBuZXdUb290aHMgPSBbLi4udG9vdGhzLm1hcChcbiAgICAgICAgICAgICh0b290aCwgaW5kZXgpID0+IHsgXG4gICAgICAgICAgICAgICAgdG9vdGguaW5kZXggPSBpbmRleFxuICAgICAgICAgICAgICAgIHJldHVybiB0b290aFxuICAgICAgICAgICAgfVxuICAgICAgICApXVxuXG4gICAgICAgIGNvbnNvbGUubG9nKG5ld1Rvb3RocylcbiAgICAgICAgcmV0dXJuIG5ld1Rvb3Roc1xuICAgIH1cblxuICAgIHJlbmRlcigpe1xuICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgPE1vZGFsXG4gICAgICAgICAgICAgICAgb3Blbj17dGhpcy5zdGF0ZS5tb2RhbE9wZW59XG4gICAgICAgICAgICAgICAgb25DbG9zZT17dGhpcy5oYW5kbGVDbG9zZX1cbiAgICAgICAgICAgICAgICB0cmlnZ2VyPXtcbiAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgaW52ZXJ0ZWRcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPSdwdXJwbGUnXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXt0aGlzLmhhbmRsZU9wZW59PlxuICAgICAgICAgICAgICAgICAgICAgICAgSW5ncmVzYXIgbnVldmEgbGVzacOzblxuICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICB9PlxuICAgICAgICAgICAgICAgIDxTZWdtZW50IGludmVydGVkPlxuICAgICAgICAgICAgICAgIDxNb2RhbC5IZWFkZXJcbiAgICAgICAgICAgICAgICAgICAgYXM9J2gxJ1xuICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBtYXJnaW46IDIgfX0+XG4gICAgICAgICAgICAgICAgICAgIDxiPk51ZXZhIExlc2nDs248L2I+XG4gICAgICAgICAgICAgICAgPC9Nb2RhbC5IZWFkZXI+XG4gICAgICAgICAgICAgICAgPE1vZGFsLkNvbnRlbnQ+XG4gICAgICAgICAgICAgICAgICAgIDxNb2RhbC5EZXNjcmlwdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgPEZvcm0gXG4gICAgICAgICAgICAgICAgICAgICAgICBvblN1Ym1pdD17dGhpcy5oYW5kbGVTdWJtaXR9PlxuICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uR3JvdXAgd2lkdGhzPSdlcXVhbCc+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uRmllbGQgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2w9e0lucHV0fSBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9J05vbWJyZScgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9J25hbWUnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXt0aGlzLmhhbmRsZUNoYW5nZX0vPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkZpZWxkIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZCBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbD17SW5wdXR9IFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD0nQXBlbGxpZG8nIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPSdsYXN0bmFtZSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlQ2hhbmdlfS8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uR3JvdXA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5Hcm91cCB3aWR0aHM9J2VxdWFsJz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5GaWVsZCBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWQgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2w9e1NlbGVjdH0gXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPSdSZWdpc3RybycgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9J3JlZ2lzdGVyJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb25zPXtSRUdJU1RFUn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlQ2hhbmdlfS8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uRmllbGQgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sPXtJbnB1dH0gXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPSdSZWdpc3RybycgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9J3JlZ2lzdGVyX251bScgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9J251bWJlcidcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlQ2hhbmdlfS8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uR3JvdXA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5Hcm91cCB3aWR0aHM9J2VxdWFsJz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5GaWVsZCBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWQgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2w9e1NlbGVjdH0gXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPSdHw6luZXJvJyBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT0nZ2VuZGVyJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb25zPXtHRU5ERVJ9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXt0aGlzLmhhbmRsZUNoYW5nZX0vPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkZpZWxkIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZCBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbD17SW5wdXR9IFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD0nRWRhZCcgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9J2FnZScgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9J251bWJlcidcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlQ2hhbmdlfS8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uR3JvdXA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5GaWVsZCBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZCBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sPXtTZWxlY3R9IFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPSdBc3BlY3RvIEdlbmVyYWwnIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9J190eXBlJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbnM9e19UWVBFfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXt0aGlzLmhhbmRsZUNoYW5nZX0vPlxuICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uR3JvdXAgaW5saW5lPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLlJhZGlvXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPSfDmm5pY2EnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9J29wMSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9J8OabmljYSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17dGhpcy5zdGF0ZS5vcDEgPT09ICfDmm5pY2EnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17dGhpcy5oYW5kbGVDaGFuZ2V9Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5SYWRpb1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD0nTcO6bHRpcGxlJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPSdvcDEnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPSdNw7psdGlwbGUnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3RoaXMuc3RhdGUub3AxID09PSAnTcO6bHRpcGxlJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlQ2hhbmdlfS8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uR3JvdXA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5Hcm91cCBpbmxpbmU+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uUmFkaW9cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9J1VuaWxvY3VsYXInXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9J29wMidcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9J1VuaWxvY3VsYXInXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3RoaXMuc3RhdGUub3AyID09PSAnVW5pbG9jdWxhcid9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXt0aGlzLmhhbmRsZUNoYW5nZX0vPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLlJhZGlvXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPSdNdWx0aWxvY3VsYXInXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9J29wMidcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9J011bHRpbG9jdWxhcidcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17dGhpcy5zdGF0ZS5vcDIgPT09ICdNdWx0aWxvY3VsYXInfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17dGhpcy5oYW5kbGVDaGFuZ2V9Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybS5Hcm91cD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkdyb3VwIGlubGluZT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5GaWVsZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sPXtTZWxlY3R9IFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD0nRm9ybWEnIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPSdmb3JtJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb25zPXtGT1JNfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17dGhpcy5oYW5kbGVDaGFuZ2V9Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5GaWVsZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sPXtTZWxlY3R9IFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD0nQm9yZGVzJyBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT0nb3AzJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb25zPXtPUDN9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXt0aGlzLmhhbmRsZUNoYW5nZX0vPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtLkdyb3VwPlxuICAgICAgICAgICAgICAgICAgICAgICAgeyBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnN0YXRlLmxvY2F0aW9ucy5tYXAoKG9iaiwgaW5kZXgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uR3JvdXBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17J2xvY2F0aW9uJyArIGluZGV4fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaW5saW5lPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uRmllbGRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sPXtTZWxlY3R9ICBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPXtpbmRleH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD0nTG9jYWxpemFjacOzbidcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb25zPXtMT0NBVElPTihpbmRleCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlTG9jYXRpb25DaGFuZ2V9Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkZpZWxkIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2w9e1NlbGVjdH0gIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9e2luZGV4fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPSdQb3NpY2nDs24nXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9ucz17UE9TSVRJT04oaW5kZXgpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXt0aGlzLmhhbmRsZVBvc2l0aW9uQ2hhbmdlfS8+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb2JqLmxvY2F0aW9uID09PSAnTWFuZMOtYnVsYScgP1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5GaWVsZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbD17U2VsZWN0fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9J1JhbWEnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPXtpbmRleH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbnM9e01BTkRJQlVMQV9CUkFOQ0goaW5kZXgpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVmYXVsdFZhbHVlPXtNQU5ESUJVTEFfQlJBTkNIKGluZGV4KVswXS52YWx1ZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXt0aGlzLmhhbmRsZUJyYW5jaENoYW5nZX0vPiA6IG51bGxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvYmoubG9jYXRpb24gPT09ICdNYW5kw61idWxhJyA/XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkZpZWxkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sPXtDaGVja2JveH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPSdDdWVycG8nXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPXtpbmRleH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXt0aGlzLmhhbmRsZUJvZHlDaGFuZ2V9Lz4gOiBudWxsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb2JqLmxvY2F0aW9uID09PSAnTWF4aWxhcicgP1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5GaWVsZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbD17Q2hlY2tib3h9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD0nU2VubyBNYXhpbGFyJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT17aW5kZXh9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17dGhpcy5oYW5kbGVTaW51c0NoYW5nZX0vPiA6IG51bGxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvYmouc2ludXNfbWF4aWxhciA/XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkZpZWxkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sPXtTZWxlY3R9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD0nUGFyZWQnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPXtpbmRleH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbnM9e1NJTlVTX01BWElMQVJfV0FMTChpbmRleCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZWZhdWx0VmFsdWU9e1NJTlVTX01BWElMQVJfV0FMTChpbmRleClbMF0udmFsdWV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17dGhpcy5oYW5kbGVXYWxsQ2hhbmdlfS8+IDogbnVsbFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnIga2V5PXsnYnInICsgaW5kZXh9Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sT25seVRvTGFzdChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaW5kZXgsIHRoaXMuc3RhdGUubG9jYXRpb25zLCBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5hZGRMb2NhdGlvbiwgdGhpcy5yZW1vdmVMb2NhdGlvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtLkdyb3VwPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpXG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5Hcm91cD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5GaWVsZCBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbD17SW5wdXR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPSdFamUgTWF5b3InIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPSdzaXplXzAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9J251bWJlcidcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RlcD0nMC4xJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17dGhpcy5oYW5kbGVDaGFuZ2V9Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5GaWVsZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sPXtJbnB1dH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9J0VqZSBNZW5vcicgIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPSdzaXplXzEnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9J251bWJlcidcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RlcD0nMC4xJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17dGhpcy5oYW5kbGVDaGFuZ2V9Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5GaWVsZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sPXtJbnB1dH0gXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPSdEaWFtZXRybycgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9J3NpemVfMidcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT0nbnVtYmVyJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdGVwPScwLjEnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXt0aGlzLmhhbmRsZUNoYW5nZX0vPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbD5tbTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uR3JvdXA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5Hcm91cCBpbmxpbmU+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uUmFkaW9cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9J0Fzb2NpYWRhJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPSdvcDQnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPSdBc29jaWFkYSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17dGhpcy5zdGF0ZS5vcDQgPT09ICdBc29jaWFkYSd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXt0aGlzLmhhbmRsZUNoYW5nZX0vPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLlJhZGlvXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPSdObyBBc29jaWFkbydcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT0nb3A0J1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT0nTm8gQXNvY2lhZG8nXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3RoaXMuc3RhdGUub3A0ID09PSAnTm8gQXNvY2lhZG8nfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17dGhpcy5oYW5kbGVDaGFuZ2V9Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybS5Hcm91cD5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnN0YXRlLm9wNCA9PT0gJ0Fzb2NpYWRhJyA/IFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuc3RhdGUudG9vdGhzLmZpbHRlcihcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdCA9PiB0Ll90eXBlID09PSAnQXNvY2lhZGEnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKS5tYXAoKG9iaiwgaW5kZXgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uR3JvdXBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17J3Rvb3RoJyArIGluZGV4fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaW5saW5lPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uRmllbGRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZCBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sPXtTZWxlY3R9ICBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPXtvYmouaW5kZXh9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9J1BpZXphIERlbnRhbCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb25zPXt0aGlzLnRlZXRoT3B0aW9uc31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17dGhpcy5oYW5kbGVUb290aHNDaGFuZ2V9Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxiciBrZXk9eydicicgKyBpbmRleH0vPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2xPbmx5VG9MYXN0KFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvYmouaW5kZXgsIHRoaXMuc3RhdGUudG9vdGhzLCBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5hZGRUb290aCgnQXNvY2lhZGEnKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5yZW1vdmVUb290aChvYmouaW5kZXgpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uR3JvdXA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogbnVsbFxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uR3JvdXAgaW5saW5lPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLlJhZGlvXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPSdDb24gUmVhYnNvcmNpw7NuJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPSdvcDUnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPSdDb24gUmVhYnNvcmNpw7NuJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXt0aGlzLnN0YXRlLm9wNSA9PT0gJ0NvbiBSZWFic29yY2nDs24nfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17dGhpcy5oYW5kbGVDaGFuZ2V9Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5SYWRpb1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD0nU2luIFJlYWJzb3JjacOzbidcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT0nb3A1J1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT0nU2luIFJlYWJzb3JjacOzbidcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17dGhpcy5zdGF0ZS5vcDUgPT09ICdTaW4gUmVhYnNvcmNpw7NuJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlQ2hhbmdlfS8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnN0YXRlLm9wNSA9PT0gJ0NvbiBSZWFic29yY2nDs24nID8gXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkZpZWxkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZCBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2w9e1NlbGVjdH0gXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD0nVGlwbycgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPSdvcDVfdHlwZSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbnM9e09QNV9UWVBFfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlQ2hhbmdlfS8+IDpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbnVsbFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybS5Hcm91cD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkdyb3VwIGlubGluZT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5SYWRpb1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD0nQ29uIERlc3BsYXphbWllbnRvIFBpZXphcyBEZW50YXJpYXMnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9J29wNidcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9J0NvbiBEZXNwbGF6YW1pZW50byBQaWV6YXMgRGVudGFyaWFzJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXt0aGlzLnN0YXRlLm9wNiA9PT0gJ0NvbiBEZXNwbGF6YW1pZW50byBQaWV6YXMgRGVudGFyaWFzJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlQ2hhbmdlfS8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uUmFkaW9cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9J1NpbiBEZXNwbGF6YW1pZW50byBQaWV6YXMgRGVudGFyaWFzJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPSdvcDYnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPSdTaW4gRGVzcGxhemFtaWVudG8gUGllemFzIERlbnRhcmlhcydcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17dGhpcy5zdGF0ZS5vcDYgPT09ICdTaW4gRGVzcGxhemFtaWVudG8gUGllemFzIERlbnRhcmlhcyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXt0aGlzLmhhbmRsZUNoYW5nZX0vPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtLkdyb3VwPlxuICAgICAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuc3RhdGUub3A2ID09PSAnQ29uIERlc3BsYXphbWllbnRvIFBpZXphcyBEZW50YXJpYXMnID8gXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5zdGF0ZS50b290aHMuZmlsdGVyKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ID0+IHQuX3R5cGUgPT09ICdDb24gRGVzcGxhemFtaWVudG8gUGllemFzIERlbnRhcmlhcydcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApLm1hcCgob2JqLCBpbmRleCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5Hcm91cFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXsndG9vdGgnICsgaW5kZXh9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbmxpbmU+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5GaWVsZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2w9e1NlbGVjdH0gIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9e29iai5pbmRleH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD0nUGllemEgRGVudGFsJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wdGlvbnM9e3RoaXMudGVldGhPcHRpb25zfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXt0aGlzLmhhbmRsZVRvb3Roc0NoYW5nZX0vPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJyIGtleT17J2JyJyArIGluZGV4fS8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbE9ubHlUb0xhc3QoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9iai5pbmRleCwgdGhpcy5zdGF0ZS50b290aHMsIFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmFkZFRvb3RoKCdDb24gRGVzcGxhemFtaWVudG8gUGllemFzIERlbnRhcmlhcycpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnJlbW92ZVRvb3RoKG9iai5pbmRleClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybS5Hcm91cD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkgOiBudWxsXG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5Hcm91cCBpbmxpbmU+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uUmFkaW9cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9J0NvbiBFeHBhbnNpw7NuIGRlIENvcnRpY2FsZXMnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9J29wNydcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9J0NvbiBFeHBhbnNpw7NuIGRlIENvcnRpY2FsZXMnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3RoaXMuc3RhdGUub3A3ID09PSAnQ29uIEV4cGFuc2nDs24gZGUgQ29ydGljYWxlcyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXt0aGlzLmhhbmRsZUNoYW5nZX0vPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLlJhZGlvXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPSdTaW4gRXhwYW5zacOzbiBkZSBDb3J0aWNhbGVzJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPSdvcDcnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPSdTaW4gRXhwYW5zacOzbiBkZSBDb3J0aWNhbGVzJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXt0aGlzLnN0YXRlLm9wNyA9PT0gJ1NpbiBFeHBhbnNpw7NuIGRlIENvcnRpY2FsZXMnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17dGhpcy5oYW5kbGVDaGFuZ2V9Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5SYWRpb1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD0nTm8gYXBsaWNhJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPSdvcDcnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPSdObyBhcGxpY2EnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3RoaXMuc3RhdGUub3A3ID09PSAnTm8gYXBsaWNhJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlQ2hhbmdlfS8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uR3JvdXA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5Hcm91cCBpbmxpbmU+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uUmFkaW9cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9J1BpZXphIEluY2x1aWRhJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPSdvcDgnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPSdQaWV6YSBJbmNsdWlkYSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17dGhpcy5zdGF0ZS5vcDggPT09ICdQaWV6YSBJbmNsdWlkYSd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXt0aGlzLmhhbmRsZUNoYW5nZX0vPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLlJhZGlvXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPSdQaWV6YSBObyBJbmNsdWlkYSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT0nb3A4J1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT0nUGllemEgTm8gSW5jbHVpZGEnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3RoaXMuc3RhdGUub3A4ID09PSAnUGllemEgTm8gSW5jbHVpZGEnfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17dGhpcy5oYW5kbGVDaGFuZ2V9Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybS5Hcm91cD5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnN0YXRlLm9wOCA9PT0gJ1BpZXphIEluY2x1aWRhJyA/IFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuc3RhdGUudG9vdGhzLmZpbHRlcihcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdCA9PiB0Ll90eXBlID09PSAnUGllemEgSW5jbHVpZGEnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKS5tYXAoKG9iaiwgaW5kZXgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uR3JvdXBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17J3Rvb3RoJyArIGluZGV4fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaW5saW5lPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uRmllbGRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZCBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sPXtTZWxlY3R9ICBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPXtvYmouaW5kZXh9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9J1BpZXphIERlbnRhbCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcHRpb25zPXt0aGlzLnRlZXRoT3B0aW9uc31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17dGhpcy5oYW5kbGVUb290aHNDaGFuZ2V9Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxiciBrZXk9eydicicgKyBpbmRleH0vPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2xPbmx5VG9MYXN0KFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvYmouaW5kZXgsIHRoaXMuc3RhdGUudG9vdGhzLCBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5hZGRUb290aCgnUGllemEgSW5jbHVpZGEnKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5yZW1vdmVUb290aChvYmouaW5kZXgpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm0uR3JvdXA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogbnVsbFxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm0uR3JvdXAgaW5saW5lPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbD48Yj5EaWFnbsOzc3RpY28gRGlmZXJlbmNpYWw8L2I+PC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5GaWVsZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZCBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbD17SW5wdXR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9J2RpZjEnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXt0aGlzLmhhbmRsZUNoYW5nZX0vPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtLkZpZWxkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2w9e0lucHV0fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPSdkaWYyJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17dGhpcy5oYW5kbGVDaGFuZ2V9Lz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybS5GaWVsZCBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbD17SW5wdXR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9J2RpZjMnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXt0aGlzLmhhbmRsZUNoYW5nZX0vPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtLkdyb3VwPlxuICAgICAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuc3RhdGUuZXJyb3IgP1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxNZXNzYWdlIG5lZ2F0aXZlPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TWVzc2FnZS5IZWFkZXI+RXJyb3I8L01lc3NhZ2UuSGVhZGVyPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cD5MYSBsZXNpw7NuIG5vIHB1ZG8gc2VyIGluZ3Jlc2FkYTwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L01lc3NhZ2U+IDogbnVsbFxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbiBpbnZlcnRlZCBjb2xvcj0ncHVycGxlJyBjb250ZW50PSdFbnZpYXInIHR5cGU9J3N1Ym1pdCcvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbiBpbnZlcnRlZCBjb2xvcj0nZ3JleScgY29udGVudD0nQ2FuY2VsYXInIG9uQ2xpY2s9e3RoaXMuaGFuZGxlQ2xvc2V9Lz5cbiAgICAgICAgICAgICAgICAgICAgIDwvRm9ybT5cbiAgICAgICAgICAgICAgICAgIDwvTW9kYWwuRGVzY3JpcHRpb24+XG4gICAgICAgICAgICAgICAgPC9Nb2RhbC5Db250ZW50PlxuICAgICAgICAgICAgICAgIDwvU2VnbWVudD5cbiAgICAgICAgICAgICAgICA8c3R5bGUganN4PntgXG4gICAgICAgICAgICAgICAgICAgIGIsIGxhYmVsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiB3aGl0ZTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGB9PC9zdHlsZT5cbiAgICAgICAgICAgIDwvTW9kYWw+XG4gICAgICAgIClcbiAgICB9XG59XG5cbmNvbnN0IGNvbnRyb2xPbmx5VG9MYXN0ID0gKGluZGV4LCBsaXN0LCBhZGQsIHJlbW92ZSkgPT4gKFxuICAgIGluZGV4ID09PSBsaXN0Lmxlbmd0aCAtIDEgP1xuICAgIDxkaXY+XG4gICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgIGljb25cbiAgICAgICAgICAgIGNvbXBhY3RcbiAgICAgICAgICAgIGNvbG9yPSdibHVlJ1xuICAgICAgICAgICAgb25DbGljaz17YWRkfT5cbiAgICAgICAgICAgIDxJY29uIG5hbWU9J3BsdXMnLz5cbiAgICAgICAgPC9CdXR0b24+IFxuICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICBpY29uXG4gICAgICAgICAgICBjb21wYWN0XG4gICAgICAgICAgICBjb2xvcj0ncmVkJ1xuICAgICAgICAgICAgb25DbGljaz17cmVtb3ZlfT5cbiAgICAgICAgICAgIDxJY29uIG5hbWU9J3gnLz5cbiAgICAgICAgPC9CdXR0b24+XG4gICAgPC9kaXY+IDogbnVsbFxuKSJdfQ== */\n/*@ sourceURL=/home/dsosa/Projects/dent-app/app/components/createinjurymodal.jsx */",
        __self: this
      }));
    }
  }]);

  return CreateInjuryModal;
}(react__WEBPACK_IMPORTED_MODULE_1__["Component"]);



var controlOnlyToLast = function controlOnlyToLast(index, list, add, remove) {
  return index === list.length - 1 ? react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement("div", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 771
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Button"], {
    icon: true,
    compact: true,
    color: "blue",
    onClick: add,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 772
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Icon"], {
    name: "plus",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 777
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Button"], {
    icon: true,
    compact: true,
    color: "red",
    onClick: remove,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 779
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_2__["Icon"], {
    name: "x",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 784
    },
    __self: this
  }))) : null;
};

/***/ }),

/***/ "./components/css.jsx":
/*!****************************!*\
  !*** ./components/css.jsx ***!
  \****************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/head */ "next/head");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
var _jsxFileName = "/home/dsosa/Projects/dent-app/app/components/css.jsx";


/* harmony default export */ __webpack_exports__["default"] = (function () {
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 4
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(next_head__WEBPACK_IMPORTED_MODULE_1___default.a, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 5
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("link", {
    rel: "stylesheet",
    href: "//cdn.jsdelivr.net/npm/semantic-ui@2.4.2/dist/semantic.min.css",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 6
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("style", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 9
    },
    __self: this
  }, "\n\t\t\t    \tbody { background: #3f0644; color: rgba(255,255,255,.9); }\n\t\t\t    \tlabel { color: white !important; }\n        \t")));
});

/***/ }),

/***/ "./components/headerlayout.jsx":
/*!*************************************!*\
  !*** ./components/headerlayout.jsx ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! semantic-ui-react */ "semantic-ui-react");
/* harmony import */ var semantic_ui_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__);
var _jsxFileName = "/home/dsosa/Projects/dent-app/app/components/headerlayout.jsx";


/* harmony default export */ __webpack_exports__["default"] = (function (_ref) {
  var _ref$headerTitle = _ref.headerTitle,
      headerTitle = _ref$headerTitle === void 0 ? 'LESIONES ROENTGENOLÓGICAS' : _ref$headerTitle;
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    style: {
      marginBottom: 25,
      paddingTop: 10
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 12
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
    style: {
      backgroundColor: 'white'
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 16
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__["Grid"].Row, {
    columns: 3,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 17
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__["Grid"].Column, {
    width: 2,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 18
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__["Image"], {
    src: "static/usac-logo.png",
    style: {
      margin: 'auto'
    },
    width: 65,
    height: 65,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 19
    },
    __self: this
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__["Grid"].Column, {
    width: 12,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 25
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__["Header"], {
    as: "h2",
    color: "purple",
    textAlign: "center",
    style: {
      'height': '100%',
      'width': '100%',
      'position': 'absolute',
      'top': '30%'
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 26
    },
    __self: this
  }, headerTitle)), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__["Grid"].Column, {
    width: 2,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 39
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__["Image"], {
    src: "static/fousac-logo.jpeg",
    style: {
      margin: 'auto'
    },
    width: 65,
    height: 65,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 40
    },
    __self: this
  }))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__["Grid"].Row, {
    style: {
      'color': 'black',
      'textAlign': 'right',
      'padding': '0 35px 0 0',
      'display': 'block'
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 47
    },
    __self: this
  }, "Adriana Olivar")));
});

/***/ }),

/***/ "./configuration/options.js":
/*!**********************************!*\
  !*** ./configuration/options.js ***!
  \**********************************/
/*! exports provided: DEFAULT_LOCATION, DEFAULT_TOOTH, REGISTER, GENDER, _TYPE, FORM, OP3, LOCATION, POSITION, MANDIBULA_BRANCH, OP5_TYPE, SINUS_MAXILAR_WALL, MENUITEMS, COLORS */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DEFAULT_LOCATION", function() { return DEFAULT_LOCATION; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DEFAULT_TOOTH", function() { return DEFAULT_TOOTH; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "REGISTER", function() { return REGISTER; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GENDER", function() { return GENDER; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "_TYPE", function() { return _TYPE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FORM", function() { return FORM; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OP3", function() { return OP3; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LOCATION", function() { return LOCATION; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "POSITION", function() { return POSITION; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MANDIBULA_BRANCH", function() { return MANDIBULA_BRANCH; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OP5_TYPE", function() { return OP5_TYPE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SINUS_MAXILAR_WALL", function() { return SINUS_MAXILAR_WALL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MENUITEMS", function() { return MENUITEMS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "COLORS", function() { return COLORS; });
var DEFAULT_LOCATION = {
  'location': '',
  'position': '',
  '_type': '',
  'branch_mandibula': null,
  'body_mandibula': false,
  'sinus_maxilar': false,
  'sinus_maxilar_wall': null
};
var DEFAULT_TOOTH = {
  'location': '',
  '_type': ''
};
var REGISTER = [{
  key: 'pi',
  text: 'PI',
  value: 'PI'
}, {
  key: 'pt',
  text: 'PT',
  value: 'PT'
}, {
  key: 'pce',
  text: 'PCE',
  value: 'PCE'
}];
var GENDER = [{
  key: 'm',
  text: 'Hombre',
  value: 'Hombre'
}, {
  key: 'f',
  text: 'Mujer',
  value: 'Mujer'
}];
var _TYPE = [{
  key: 'l',
  text: 'Lucente',
  value: 'Lucente'
}, {
  key: 'o',
  text: 'Opaca',
  value: 'Opaca'
}, {
  key: 'm',
  text: 'Mixta',
  value: 'Mixta'
}];
var FORM = [{
  key: 'c',
  text: 'Circular',
  value: 'Circular'
}, {
  key: 'o',
  text: 'Ovalada',
  value: 'Ovalada'
}, {
  key: 't',
  text: 'Triangular',
  value: 'Triangular'
}, {
  key: 'r',
  text: 'Rectangular',
  value: 'Rectangular'
}, {
  key: 'tr',
  text: 'Trapezoidal',
  value: 'Trapezoidal'
}, {
  key: 'cu',
  text: 'Cuadrada',
  value: 'Cuadrada'
}, {
  key: 'ir',
  text: 'Irregular',
  value: 'Irregular'
}, {
  key: 's',
  text: 'Semi Circular',
  value: 'Semi Circular'
}, {
  key: 'l',
  text: 'Lineal',
  value: 'Lineal'
}];
var OP3 = [{
  key: 'de',
  text: 'Definidos Esclerótico',
  value: 'Definidos Esclerótico'
}, {
  key: 'dn',
  text: 'Definidos No Esclerótico',
  value: 'Definidos No Esclerótico'
}, {
  key: 'di',
  text: 'Difusos',
  value: 'Difusos'
}];
var LOCATION = function LOCATION(index) {
  return [{
    key: 'bl-ligamento' + index,
    text: 'Ligamento Estilohioideo',
    value: {
      'name': 'Ligamento Estilohioideo',
      'type': 'Blando'
    }
  }, {
    key: 'bl-lengua' + index,
    text: 'Lengua',
    value: {
      'name': 'Lengua',
      'type': 'Blando'
    }
  }, {
    key: 'bl-glandula' + index,
    text: 'Glándula Tiroides',
    value: {
      'name': 'Glándula Tiroides',
      'type': 'Blando'
    }
  }, {
    key: 'bl-amigdala' + index,
    text: 'Amígdala',
    value: {
      'name': 'Amígdala',
      'type': 'Blando'
    }
  }, {
    key: 'bl-nariz' + index,
    text: 'Tejido Blando de Nariz',
    value: {
      'name': 'Tejido Blando de Nariz',
      'type': 'Blando'
    }
  }, {
    key: 'du-huesonasal' + index,
    text: 'Hueso Nasal',
    value: {
      'name': 'Hueso Nasal',
      'type': 'Duro'
    }
  }, {
    key: 'du-huesotemp' + index,
    text: 'Hueso Temporal',
    value: {
      'name': 'Hueso Temporal',
      'type': 'Duro'
    }
  }, {
    key: 'du-huesocigo' + index,
    text: 'Hueso Cigomático',
    value: {
      'name': 'Hueso Cigomático',
      'type': 'Duro'
    }
  }, {
    key: 'du-espacionasal' + index,
    text: 'Espacio de Fosas Nasales',
    value: {
      'name': 'Espacio de Fosas Nasales',
      'type': 'Duro'
    }
  }, {
    key: 'du-huesohio' + index,
    text: 'Hueso Hioides',
    value: {
      'name': 'Hueso Hioides',
      'type': 'Duro'
    }
  }, {
    key: 'du-vertebras' + index,
    text: 'Vertebras Cervicales',
    value: {
      'name': 'Vertebras Cervicales',
      'type': 'Duro'
    }
  }, {
    key: 'du-maxilar' + index,
    text: 'Maxilar',
    value: {
      'name': 'Maxilar',
      'type': 'Duro'
    }
  }, {
    key: 'du-mandibula' + index,
    text: 'Mandíbula',
    value: {
      'name': 'Mandíbula',
      'type': 'Duro'
    }
  }, {
    key: 'ae-oro' + index,
    text: 'Espacio de Orofaringe',
    value: {
      'name': 'Espacio de Orofaringe',
      'type': 'Aéreo'
    }
  }, {
    key: 'ae-naso' + index,
    text: 'Espacio de Nasofaringe',
    value: {
      'name': 'Espacio de Nasofaringe',
      'type': 'Aéreo'
    }
  }, {
    key: 'ae-hipo' + index,
    text: 'Espacio de Hipofaringe',
    value: {
      'name': 'Espacio de Hipofaringe',
      'type': 'Aéreo'
    }
  }];
};
var POSITION = function POSITION(index) {
  return [{
    key: 'de' + index,
    text: 'Derecho',
    value: 'Derecho'
  }, {
    key: 'di' + index,
    text: 'Izquierdo',
    value: 'Izquierdo'
  }, {
    key: 'bi' + index,
    text: 'Bilateral',
    value: 'Bilateral'
  }];
};
var MANDIBULA_BRANCH = function MANDIBULA_BRANCH(index) {
  return [{
    key: 'null' + index,
    text: 'No aplica',
    value: 'None'
  }, {
    key: 'rama' + index,
    text: 'Rama Mandibular',
    value: 'Rama Mandibular'
  }, {
    key: 'con' + index,
    text: 'Cóndilo Mandibular',
    value: 'Cóndilo Mandibular'
  }, {
    key: 'apo' + index,
    text: 'Apófisis Coronoides',
    value: 'Apófisis Coronoides'
  }];
};
var OP5_TYPE = [{
  key: 'r',
  text: 'Raices Dentarias',
  value: 'Raices Dentarias'
}, {
  key: 'c',
  text: 'Coronas Dentarias',
  value: 'Coronas Dentarias'
}, {
  key: 'o',
  text: 'Óseas',
  value: 'Óseas'
}];
var SINUS_MAXILAR_WALL = function SINUS_MAXILAR_WALL(index) {
  return [{
    key: 'null' + index,
    text: 'No aplica',
    value: 'None'
  }, {
    key: 'ant' + index,
    text: 'Pared Anterior',
    value: 'Pared Anterior'
  }, {
    key: 'post' + index,
    text: 'Pared Posterior',
    value: 'Pared Posterior'
  }, {
    key: 'techo' + index,
    text: 'Techo',
    value: 'Techo'
  }, {
    key: 'piso' + index,
    text: 'Piso',
    value: 'Piso'
  }];
};
var MENUITEMS = function MENUITEMS(currentType) {
  return [{
    title: 'Tipo de Lesión',
    filter: '_type',
    chartTitle: "Prevalencia de lesiones ".concat(currentType, " seg\xFAn tipo")
  }, {
    title: 'Edad',
    filter: 'age',
    chartTitle: "Prevalencia de lesiones ".concat(currentType, " seg\xFAn edad")
  }, {
    title: 'Género',
    filter: 'gender',
    chartTitle: "Prevalencia de lesiones ".concat(currentType, " seg\xFAn g\xE9nero")
  }, {
    title: 'Tipo de Registro',
    filter: 'register',
    chartTitle: "Prevalencia de lesiones ".concat(currentType, " seg\xFAn registro")
  }, {
    title: 'Única-Múltiple',
    filter: 'op1',
    chartTitle: "Prevalencia de lesiones ".concat(currentType, " seg\xFAn cantidad")
  }, {
    title: 'Unilocular-Multilocular',
    filter: 'op2',
    chartTitle: "Prevalencia de lesiones ".concat(currentType, " seg\xFAn compartimientos")
  }, {
    title: 'Formas',
    filter: 'form',
    chartTitle: "Prevalencia de lesiones ".concat(currentType, " seg\xFAn forma")
  }, {
    title: 'Bordes',
    filter: 'op3',
    chartTitle: "Prevalencia de lesiones ".concat(currentType, " seg\xFAn tipo de bordes")
  }, {
    title: 'Localización',
    filter: 'location_sub',
    chartTitle: "Prevalencia de lesiones ".concat(currentType, " seg\xFAn localizaci\xF3n"),
    sub: [{
      title: 'Localización',
      filter: 'location_sub',
      chartTitle: "Prevalencia de lesiones ".concat(currentType, " seg\xFAn localizaci\xF3n")
    }, {
      title: 'Tipo',
      filter: 'location_div',
      chartTitle: "Prevalenc\xEDa de lesiones ".concat(currentType, " seg\xFAn la estructura o espacio que ocupa")
    }, {
      title: 'Tejido Blando',
      filter: 'location_div_0',
      chartTitle: "Prevalencia de lesiones ".concat(currentType, " en tejidos blandos"),
      sub: [{
        title: 'Tejido Blando',
        filter: 'location_div_0',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en tejidos blandos")
      }, {
        title: 'Ligamento Estilohioideo',
        filter: 'location_estilohioideo_position',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en ligamento estilohioideo")
      }, {
        title: 'Lengua',
        filter: 'location_lengua_position',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en lengua")
      }, {
        title: 'Glándula Tiroides',
        filter: 'location_tiroides_position',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en gl\xE1ndula tiroides")
      }, {
        title: 'Amígdala',
        filter: 'location_amigdala_position',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en am\xEDgdala")
      }, {
        title: 'Tejido Blando de Nariz',
        filter: 'location_blnariz_position',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en tejido blando de nariz")
      }]
    }, {
      title: 'Tejido Duro',
      filter: 'location_div_1',
      chartTitle: "Prevalencia de lesiones ".concat(currentType, " en tejidos duros"),
      sub: [{
        title: 'Tejido Duro',
        filter: 'location_div_1',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en tejidos duros")
      }, {
        title: 'Mandíbula',
        filter: 'location_mandibula_position',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en mand\xEDbula"),
        sub: [{
          title: 'Mandíbula',
          filter: 'location_mandibula_position',
          chartTitle: "Prevalencia de lesiones ".concat(currentType, " en mand\xEDbula")
        }, {
          title: 'Cuerpo de la Mandíbula',
          filter: 'location_body_mandibula',
          chartTitle: "Prevalencia de lesiones ".concat(currentType, " en cuerpo de la mand\xEDbula")
        }, {
          title: 'Rama Mandibular',
          filter: 'location_branch_mandibula',
          chartTitle: "Prevalencia de lesiones ".concat(currentType, " en rama mandibular")
        }]
      }, {
        title: 'Maxilar',
        filter: 'location_maxilar_position',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en maxilar"),
        sub: [{
          title: 'Maxilar',
          filter: 'location_maxilar_position',
          chartTitle: "Prevalencia de lesiones ".concat(currentType, " en maxilar")
        }, {
          title: 'Seno Maxilar',
          filter: 'location_sinus_maxilar',
          chartTitle: "Prevalencia de lesiones ".concat(currentType, " en seno maxilar")
        }, {
          title: 'Peredes del Seno Maxilar',
          filter: 'location_sinus_maxilar_wall',
          chartTitle: "Prevalencia de lesiones ".concat(currentType, " en paredes del seno maxilar")
        }]
      }, {
        title: 'Hueso Nasal',
        filter: 'location_nasal_position',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en hueso nasal")
      }, {
        title: 'Espacio de Fosas Nasales',
        filter: 'location_fosa_position',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en espacio de fosas nasales")
      }, {
        title: 'Hueso Temporal',
        filter: 'location_temporal_position',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en hueso temporal")
      }, {
        title: 'Hueso Cigomático',
        filter: 'location_cigomatico_position',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en hueso cigom\xE1tico")
      }, {
        title: 'Hueso Hioides',
        filter: 'location_hioides_position',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en hueso hioides")
      }, {
        title: 'Vertebras Cervicales',
        filter: 'location_cervicales_position',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en vertebras cervicales")
      }]
    }, {
      title: 'Espacio Aéreo',
      filter: 'location_div_2',
      chartTitle: "Prevalencia de lesiones ".concat(currentType, " en espacios a\xE9reos"),
      sub: [{
        title: 'Espacio Aéreo',
        filter: 'location_div_2',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en espacios a\xE9reos")
      }, {
        title: 'Espacio de Orofaringe',
        filter: 'location_oro_position',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en espacio de orofaringe")
      }, {
        title: 'Espacio de Nasofaringe',
        filter: 'location_naso_position',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en espacio de nasofaringe")
      }, {
        title: 'Espacio de Hipofaringe',
        filter: 'location_hipo_position',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en espacio de hipofaringe")
      }]
    }]
  }, {
    title: 'Asociada',
    filter: 'op4',
    chartTitle: "Prevalencia de lesiones ".concat(currentType, " asociadas a piezas dentales"),
    sub: [{
      title: 'Asociada',
      filter: 'op4',
      chartTitle: "Prevalencia de lesiones ".concat(currentType, " asociadas a piezas dentales")
    }, {
      title: 'Asociada Pieza Dental',
      filter: 'op4_super',
      chartTitle: "Frecuencia de piezas dentales asociadas por lesiones ".concat(currentType)
    }]
  }, {
    title: 'Reabsorción',
    filter: 'op5',
    chartTitle: "Prevalencia de lesiones ".concat(currentType, " provocando reabsorci\xF3n"),
    sub: [{
      title: 'Reabsorción',
      filter: 'op5',
      chartTitle: "Prevalencia de lesiones ".concat(currentType, " provocando reabsorci\xF3n")
    }, {
      title: 'Reabsorción Tipo',
      filter: 'op5_type',
      chartTitle: "Prevalencia de lesiones ".concat(currentType, " seg\xFAn tipo de reabsorci\xF3n")
    }]
  }, {
    title: 'Desplazamiento',
    filter: 'op6',
    chartTitle: "Prevalencia de lesiones ".concat(currentType, " con desplazamiento de piezas dentales"),
    sub: [{
      title: 'Desplazamiento',
      filter: 'op6',
      chartTitle: "Prevalencia de lesiones ".concat(currentType, " con desplazamiento de piezas dentales")
    }, {
      title: 'Desplazamiento Pieza Dental',
      filter: 'op6_super',
      chartTitle: "Frecuencia de piezas dentales desplazadas por lesiones ".concat(currentType)
    }]
  }, {
    title: 'Expansión de Corticales',
    filter: 'op7',
    chartTitle: "Prevalencia de lesiones ".concat(currentType, " con expansi\xF3n de corticales")
  }, {
    title: 'Pieza Incluida',
    filter: 'op8',
    chartTitle: "Prevalencia de lesiones ".concat(currentType, " con piezas dentales incluidas"),
    sub: [{
      title: 'Pieza Incluida',
      filter: 'op8',
      chartTitle: "Prevalencia de lesiones ".concat(currentType, " con piezas dentales incluidas")
    }, {
      title: 'Número de Pieza Incluida',
      filter: 'op8_super',
      chartTitle: "Frecuencia de piezas dentales incluidas por lesiones ".concat(currentType)
    }]
  }, {
    title: 'Diagnóstico Diferencial 1',
    filter: 'dif1',
    chartTitle: "Prevalencia de Diagn\xF3stico diferencial 1 de lesiones ".concat(currentType)
  }, {
    title: 'Diagnóstico Diferencial 2',
    filter: 'dif2',
    chartTitle: "Prevalencia de Diagn\xF3stico diferencial 2 de lesiones ".concat(currentType)
  }, {
    title: 'Diagnóstico Diferencial 3',
    filter: 'dif3',
    chartTitle: "Prevalencia de Diagn\xF3stico diferencial 3 de lesiones ".concat(currentType)
  }];
};
var COLORS = ["#0D855D", "#1B8F68", "#14CC8F", "#3DFFBD", "#1AFFBA"];

/***/ }),

/***/ "./pages/main.jsx":
/*!************************!*\
  !*** ./pages/main.jsx ***!
  \************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_auth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils/auth */ "./utils/auth.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ "next/link");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var semantic_ui_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! semantic-ui-react */ "semantic-ui-react");
/* harmony import */ var semantic_ui_react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(semantic_ui_react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_createinjurymodal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../components/createinjurymodal */ "./components/createinjurymodal.jsx");
/* harmony import */ var _components_headerlayout__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../components/headerlayout */ "./components/headerlayout.jsx");
/* harmony import */ var _components_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../components/css */ "./components/css.jsx");
var _jsxFileName = "/home/dsosa/Projects/dent-app/app/pages/main.jsx";


function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance"); }

function _iterableToArrayLimit(arr, i) { if (!(Symbol.iterator in Object(arr) || Object.prototype.toString.call(arr) === "[object Arguments]")) { return; } var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }










var Main = function Main(props) {
  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])([]),
      _useState2 = _slicedToArray(_useState, 2),
      injuries = _useState2[0],
      setInjuries = _useState2[1];

  var _useState3 = Object(react__WEBPACK_IMPORTED_MODULE_0__["useState"])(null),
      _useState4 = _slicedToArray(_useState3, 2),
      error = _useState4[0],
      setError = _useState4[1];

  var getInjuries = function getInjuries() {
    return fetch('http://127.0.0.1:5000/injury').then(function (response) {
      return response.json();
    }).then(function (data) {
      setInjuries(data);
    });
  };

  Object(react__WEBPACK_IMPORTED_MODULE_0__["useEffect"])(function () {
    getInjuries();
  }, [injuries]);

  var deleteInjury = function deleteInjury(id) {
    return fetch("http://127.0.0.1:5000/injury/".concat(id), {
      method: 'DELETE'
    }).then(function (response) {
      return getInjuries();
    }).catch(function (error) {
      return setError(error.response);
    });
  };

  var onLogout = function onLogout() {
    return Object(_utils_auth__WEBPACK_IMPORTED_MODULE_1__["logout"])();
  };

  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 42
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_css__WEBPACK_IMPORTED_MODULE_6__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 43
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_headerlayout__WEBPACK_IMPORTED_MODULE_5__["default"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 44
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_3__["Grid"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 45
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_3__["Grid"].Row, {
    columns: 3,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 46
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_3__["Grid"].Column, {
    width: 2,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 47
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_3__["Grid"].Column, {
    width: 12,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 48
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_3__["Segment"], {
    inverted: true,
    color: "purple",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 49
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_3__["Grid"], {
    columns: "equal",
    container: true,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 50
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_3__["Grid"].Row, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 51
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_3__["Grid"].Column, {
    columns: "equal",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 52
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_3__["Card"], {
    color: "purple",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 53
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_3__["Card"].Content, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 54
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_3__["Card"].Header, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 55
    },
    __self: this
  }, "Lucentes")), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_3__["Card"].Content, {
    extra: true,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 57
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
    href: '/chart?title=Lucente',
    __source: {
      fileName: _jsxFileName,
      lineNumber: 58
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("a", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 59
    },
    __self: this
  }, "Mas Informaci\xF3n"))))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_3__["Grid"].Column, {
    columns: "equal",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 64
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_3__["Card"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 65
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_3__["Card"].Content, {
    style: {
      'backgroundColor': 'black'
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 66
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_3__["Card"].Header, {
    style: {
      'color': 'white'
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 67
    },
    __self: this
  }, "Opacas")), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_3__["Card"].Content, {
    extra: true,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 69
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
    href: '/chart?title=Opaca',
    __source: {
      fileName: _jsxFileName,
      lineNumber: 70
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("a", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 71
    },
    __self: this
  }, "Mas Informaci\xF3n"))))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_3__["Grid"].Column, {
    columns: "equal",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 76
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_3__["Card"], {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 77
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_3__["Card"].Content, {
    style: {
      'backgroundColor': 'grey'
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 78
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_3__["Card"].Header, {
    style: {
      'color': 'white'
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 79
    },
    __self: this
  }, "Mixtas")), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_3__["Card"].Content, {
    extra: true,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 81
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
    href: '/chart?title=Mixta',
    __source: {
      fileName: _jsxFileName,
      lineNumber: 82
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("a", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 83
    },
    __self: this
  }, "Mas Informaci\xF3n"))))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_3__["Grid"].Column, {
    columns: "equal",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 88
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_3__["Card"], {
    color: "purple",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 89
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_3__["Card"].Content, {
    style: {
      'backgroundColor': 'purple'
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 90
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_3__["Card"].Header, {
    style: {
      'color': 'white'
    },
    __source: {
      fileName: _jsxFileName,
      lineNumber: 91
    },
    __self: this
  }, "Todas")), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_3__["Card"].Content, {
    extra: true,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 93
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(next_link__WEBPACK_IMPORTED_MODULE_2___default.a, {
    href: '/chart?title=todas',
    __source: {
      fileName: _jsxFileName,
      lineNumber: 94
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("a", {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 95
    },
    __self: this
  }, "Mas Informaci\xF3n")))))), injuries && injuries.length > 0 ? react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_3__["Grid"].Row, {
    columns: 3,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 103
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_3__["Grid"].Column, {
    width: 2,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 104
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_3__["Grid"].Column, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 105
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_3__["Segment"], {
    inverted: true,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 106
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_3__["List"], {
    divided: true,
    verticalAlign: "middle",
    __source: {
      fileName: _jsxFileName,
      lineNumber: 107
    },
    __self: this
  }, injuries.map(function (injury) {
    return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_3__["List"].Item, {
      key: injury.injury_id,
      __source: {
        fileName: _jsxFileName,
        lineNumber: 112
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_3__["List"].Content, {
      floated: "right",
      __source: {
        fileName: _jsxFileName,
        lineNumber: 113
      },
      __self: this
    }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_3__["Button"], {
      onClick: function onClick() {
        return deleteInjury(injury.injury_id);
      },
      __source: {
        fileName: _jsxFileName,
        lineNumber: 114
      },
      __self: this
    }, 'Eliminar')), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_3__["List"].Content, {
      __source: {
        fileName: _jsxFileName,
        lineNumber: 118
      },
      __self: this
    }, ' ID: ' + injury.register_num + ' Registro:' + injury.register + ' Paciente: ' + injury.name + ' ' + injury.lastname));
  })))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_3__["Grid"].Column, {
    width: 2,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 131
    },
    __self: this
  })) : null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_3__["Grid"].Row, {
    __source: {
      fileName: _jsxFileName,
      lineNumber: 135
    },
    __self: this
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_3__["Grid"].Column, {
    width: 10,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 136
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(_components_createinjurymodal__WEBPACK_IMPORTED_MODULE_4__["default"], {
    callback: getInjuries,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 137
    },
    __self: this
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_3__["Button"], {
    onClick: onLogout,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 138
    },
    __self: this
  }, " Cerrar Sesion "))))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_3__["Grid"].Column, {
    width: 2,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 143
    },
    __self: this
  }))));
};

/* harmony default export */ __webpack_exports__["default"] = (Object(_utils_auth__WEBPACK_IMPORTED_MODULE_1__["withAuthSync"])(Main));

/***/ }),

/***/ "./utils/api.js":
/*!**********************!*\
  !*** ./utils/api.js ***!
  \**********************/
/*! exports provided: simulateApi */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "simulateApi", function() { return simulateApi; });
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator */ "@babel/runtime/regenerator");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);


function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

var simulateApi =
/*#__PURE__*/
function () {
  var _ref = _asyncToGenerator(
  /*#__PURE__*/
  _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee(payload) {
    var delay,
        _args = arguments;
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            delay = _args.length > 1 && _args[1] !== undefined ? _args[1] : 1000;
            _context.next = 3;
            return new Promise(function (resolve) {
              return setTimeout(resolve(payload), delay);
            });

          case 3:
            return _context.abrupt("return", _context.sent);

          case 4:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));

  return function simulateApi(_x) {
    return _ref.apply(this, arguments);
  };
}();

/***/ }),

/***/ "./utils/auth.js":
/*!***********************!*\
  !*** ./utils/auth.js ***!
  \***********************/
/*! exports provided: login, logout, withAuthSync, auth */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "login", function() { return login; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "logout", function() { return logout; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "withAuthSync", function() { return withAuthSync; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "auth", function() { return auth; });
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator */ "@babel/runtime/regenerator");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ "next/router");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_cookies__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next-cookies */ "next-cookies");
/* harmony import */ var next_cookies__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_cookies__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! js-cookie */ "js-cookie");
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(js_cookie__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! isomorphic-unfetch */ "isomorphic-unfetch");
/* harmony import */ var isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./api */ "./utils/api.js");

var _jsxFileName = "/home/dsosa/Projects/dent-app/app/utils/auth.js";


function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }







var login =
/*#__PURE__*/
function () {
  var _ref2 = _asyncToGenerator(
  /*#__PURE__*/
  _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee(_ref) {
    var username, password, url, response, error;
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            username = _ref.username, password = _ref.password, url = _ref.url;
            _context.prev = 1;
            _context.next = 4;
            return Object(_api__WEBPACK_IMPORTED_MODULE_6__["simulateApi"])({
              'ok': true,
              'status': 200
            }, 3000);

          case 4:
            response = _context.sent;
            console.log(response);

            if (!(response.status && response.status == 200)) {
              _context.next = 11;
              break;
            }

            /*const { token } = await response.json()*/
            js_cookie__WEBPACK_IMPORTED_MODULE_4___default.a.set('token', 'token', {
              expires: 1
            });
            next_router__WEBPACK_IMPORTED_MODULE_2___default.a.push('/main');
            _context.next = 15;
            break;

          case 11:
            console.log('Login failed.'); // https://github.com/developit/unfetch#caveats

            error = new Error(response.statusText);
            error.response = response;
            return _context.abrupt("return", Promise.reject(error));

          case 15:
            _context.next = 21;
            break;

          case 17:
            _context.prev = 17;
            _context.t0 = _context["catch"](1);
            console.error('You have an error in your code or there are Network issues.', _context.t0);
            throw new Error(_context.t0);

          case 21:
          case "end":
            return _context.stop();
        }
      }
    }, _callee, null, [[1, 17]]);
  }));

  return function login(_x) {
    return _ref2.apply(this, arguments);
  };
}();
var logout = function logout() {
  js_cookie__WEBPACK_IMPORTED_MODULE_4___default.a.remove('token'); // to support logging out from all windows
  //window.localStorage.setItem('logout', Date.now())

  next_router__WEBPACK_IMPORTED_MODULE_2___default.a.push('/login');
}; // Gets the display name of a JSX component for dev tools

var getDisplayName = function getDisplayName(Component) {
  return Component.displayName || Component.name || 'Component';
};

var withAuthSync = function withAuthSync(WrappedComponent) {
  var _class, _temp;

  return _temp = _class =
  /*#__PURE__*/
  function (_Component) {
    _inherits(_class, _Component);

    _createClass(_class, null, [{
      key: "getInitialProps",
      value: function () {
        var _getInitialProps = _asyncToGenerator(
        /*#__PURE__*/
        _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee2(ctx) {
          var token, componentProps;
          return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee2$(_context2) {
            while (1) {
              switch (_context2.prev = _context2.next) {
                case 0:
                  token = auth(ctx);
                  _context2.t0 = WrappedComponent.getInitialProps;

                  if (!_context2.t0) {
                    _context2.next = 6;
                    break;
                  }

                  _context2.next = 5;
                  return WrappedComponent.getInitialProps(ctx);

                case 5:
                  _context2.t0 = _context2.sent;

                case 6:
                  componentProps = _context2.t0;
                  return _context2.abrupt("return", _objectSpread({}, componentProps, {
                    token: token
                  }));

                case 8:
                case "end":
                  return _context2.stop();
              }
            }
          }, _callee2);
        }));

        function getInitialProps(_x2) {
          return _getInitialProps.apply(this, arguments);
        }

        return getInitialProps;
      }()
    }]);

    function _class(props) {
      var _this;

      _classCallCheck(this, _class);

      _this = _possibleConstructorReturn(this, _getPrototypeOf(_class).call(this, props));
      _this.syncLogout = _this.syncLogout.bind(_assertThisInitialized(_this));
      return _this;
    }

    _createClass(_class, [{
      key: "componentDidMount",
      value: function componentDidMount() {
        window.addEventListener('storage', this.syncLogout);
      }
    }, {
      key: "componentWillUnmount",
      value: function componentWillUnmount() {
        window.removeEventListener('storage', this.syncLogout);
        window.localStorage.removeItem('logout');
      }
    }, {
      key: "syncLogout",
      value: function syncLogout(event) {
        if (event.key === 'logout') {
          console.log('logged out from storage!');
          next_router__WEBPACK_IMPORTED_MODULE_2___default.a.push('/login');
        }
      }
    }, {
      key: "render",
      value: function render() {
        return react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement(WrappedComponent, _extends({}, this.props, {
          __source: {
            fileName: _jsxFileName,
            lineNumber: 85
          },
          __self: this
        }));
      }
    }]);

    return _class;
  }(react__WEBPACK_IMPORTED_MODULE_1__["Component"]), _defineProperty(_class, "displayName", "withAuthSync(".concat(getDisplayName(WrappedComponent), ")")), _temp;
};
var auth = function auth(ctx) {
  var _nextCookie = next_cookies__WEBPACK_IMPORTED_MODULE_3___default()(ctx),
      token = _nextCookie.token;

  if (ctx.req && !token) {
    ctx.res.writeHead(302, {
      Location: '/login'
    });
    ctx.res.end();
    return;
  }

  if (!token) {
    next_router__WEBPACK_IMPORTED_MODULE_2___default.a.push('/login');
  }

  return token;
};

/***/ }),

/***/ "./utils/functions.js":
/*!****************************!*\
  !*** ./utils/functions.js ***!
  \****************************/
/*! exports provided: range */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "range", function() { return range; });
function range(start, stop, step) {
  var a = [start],
      b = start;

  while (b < stop) {
    a.push(b += step || 1);
  }

  return a;
}

/***/ }),

/***/ 5:
/*!******************************!*\
  !*** multi ./pages/main.jsx ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! ./pages/main.jsx */"./pages/main.jsx");


/***/ }),

/***/ "@babel/runtime/regenerator":
/*!*********************************************!*\
  !*** external "@babel/runtime/regenerator" ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@babel/runtime/regenerator");

/***/ }),

/***/ "isomorphic-unfetch":
/*!*************************************!*\
  !*** external "isomorphic-unfetch" ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("isomorphic-unfetch");

/***/ }),

/***/ "js-cookie":
/*!****************************!*\
  !*** external "js-cookie" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("js-cookie");

/***/ }),

/***/ "next-cookies":
/*!*******************************!*\
  !*** external "next-cookies" ***!
  \*******************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next-cookies");

/***/ }),

/***/ "next/head":
/*!****************************!*\
  !*** external "next/head" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/head");

/***/ }),

/***/ "next/link":
/*!****************************!*\
  !*** external "next/link" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/link");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "semantic-ui-react":
/*!************************************!*\
  !*** external "semantic-ui-react" ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("semantic-ui-react");

/***/ }),

/***/ "styled-jsx/style":
/*!***********************************!*\
  !*** external "styled-jsx/style" ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("styled-jsx/style");

/***/ })

/******/ });
//# sourceMappingURL=main.js.map