module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 15);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),
/* 1 */
/***/ (function(module, exports) {

module.exports = require("semantic-ui-react");

/***/ }),
/* 2 */
/***/ (function(module, exports) {

module.exports = require("@babel/runtime/regenerator");

/***/ }),
/* 3 */
/***/ (function(module, exports) {

module.exports = require("next/router");

/***/ }),
/* 4 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return DEFAULT_LOCATION; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return DEFAULT_TOOTH; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "l", function() { return REGISTER; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "e", function() { return GENDER; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "n", function() { return _TYPE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return FORM; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "i", function() { return OP3; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "f", function() { return LOCATION; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "k", function() { return POSITION; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "g", function() { return MANDIBULA_BRANCH; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "j", function() { return OP5_TYPE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "m", function() { return SINUS_MAXILAR_WALL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "h", function() { return MENUITEMS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return COLORS; });
var DEFAULT_LOCATION = {
  'location': '',
  'position': '',
  '_type': '',
  'branch_mandibula': null,
  'body_mandibula': false,
  'sinus_maxilar': false,
  'sinus_maxilar_wall': null
};
var DEFAULT_TOOTH = {
  'location': '',
  '_type': ''
};
var REGISTER = [{
  key: 'pi',
  text: 'PI',
  value: 'PI'
}, {
  key: 'pt',
  text: 'PT',
  value: 'PT'
}, {
  key: 'pce',
  text: 'PCE',
  value: 'PCE'
}];
var GENDER = [{
  key: 'm',
  text: 'Hombre',
  value: 'Hombre'
}, {
  key: 'f',
  text: 'Mujer',
  value: 'Mujer'
}];
var _TYPE = [{
  key: 'l',
  text: 'Lucente',
  value: 'Lucente'
}, {
  key: 'o',
  text: 'Opaca',
  value: 'Opaca'
}, {
  key: 'm',
  text: 'Mixta',
  value: 'Mixta'
}];
var FORM = [{
  key: 'c',
  text: 'Circular',
  value: 'Circular'
}, {
  key: 'o',
  text: 'Ovalada',
  value: 'Ovalada'
}, {
  key: 't',
  text: 'Triangular',
  value: 'Triangular'
}, {
  key: 'r',
  text: 'Rectangular',
  value: 'Rectangular'
}, {
  key: 'tr',
  text: 'Trapezoidal',
  value: 'Trapezoidal'
}, {
  key: 'cu',
  text: 'Cuadrada',
  value: 'Cuadrada'
}, {
  key: 'ir',
  text: 'Irregular',
  value: 'Irregular'
}, {
  key: 's',
  text: 'Semi Circular',
  value: 'Semi Circular'
}, {
  key: 'l',
  text: 'Lineal',
  value: 'Lineal'
}];
var OP3 = [{
  key: 'de',
  text: 'Definidos Esclerótico',
  value: 'Definidos Esclerótico'
}, {
  key: 'dn',
  text: 'Definidos No Esclerótico',
  value: 'Definidos No Esclerótico'
}, {
  key: 'di',
  text: 'Difusos',
  value: 'Difusos'
}];
var LOCATION = function LOCATION(index) {
  return [{
    key: 'bl-ligamento' + index,
    text: 'Ligamento Estilohioideo',
    value: {
      'name': 'Ligamento Estilohioideo',
      'type': 'Blando'
    }
  }, {
    key: 'bl-lengua' + index,
    text: 'Lengua',
    value: {
      'name': 'Lengua',
      'type': 'Blando'
    }
  }, {
    key: 'bl-glandula' + index,
    text: 'Glándula Tiroides',
    value: {
      'name': 'Glándula Tiroides',
      'type': 'Blando'
    }
  }, {
    key: 'bl-amigdala' + index,
    text: 'Amígdala',
    value: {
      'name': 'Amígdala',
      'type': 'Blando'
    }
  }, {
    key: 'bl-nariz' + index,
    text: 'Tejido Blando de Nariz',
    value: {
      'name': 'Tejido Blando de Nariz',
      'type': 'Blando'
    }
  }, {
    key: 'du-huesonasal' + index,
    text: 'Hueso Nasal',
    value: {
      'name': 'Hueso Nasal',
      'type': 'Duro'
    }
  }, {
    key: 'du-huesotemp' + index,
    text: 'Hueso Temporal',
    value: {
      'name': 'Hueso Temporal',
      'type': 'Duro'
    }
  }, {
    key: 'du-huesocigo' + index,
    text: 'Hueso Cigomático',
    value: {
      'name': 'Hueso Cigomático',
      'type': 'Duro'
    }
  }, {
    key: 'du-espacionasal' + index,
    text: 'Espacio de Fosas Nasales',
    value: {
      'name': 'Espacio de Fosas Nasales',
      'type': 'Duro'
    }
  }, {
    key: 'du-huesohio' + index,
    text: 'Hueso Hioides',
    value: {
      'name': 'Hueso Hioides',
      'type': 'Duro'
    }
  }, {
    key: 'du-vertebras' + index,
    text: 'Vertebras Cervicales',
    value: {
      'name': 'Vertebras Cervicales',
      'type': 'Duro'
    }
  }, {
    key: 'du-maxilar' + index,
    text: 'Maxilar',
    value: {
      'name': 'Maxilar',
      'type': 'Duro'
    }
  }, {
    key: 'du-mandibula' + index,
    text: 'Mandíbula',
    value: {
      'name': 'Mandíbula',
      'type': 'Duro'
    }
  }, {
    key: 'ae-oro' + index,
    text: 'Espacio de Orofaringe',
    value: {
      'name': 'Espacio de Orofaringe',
      'type': 'Aéreo'
    }
  }, {
    key: 'ae-naso' + index,
    text: 'Espacio de Nasofaringe',
    value: {
      'name': 'Espacio de Nasofaringe',
      'type': 'Aéreo'
    }
  }, {
    key: 'ae-hipo' + index,
    text: 'Espacio de Hipofaringe',
    value: {
      'name': 'Espacio de Hipofaringe',
      'type': 'Aéreo'
    }
  }];
};
var POSITION = function POSITION(index) {
  return [{
    key: 'de' + index,
    text: 'Derecho',
    value: 'Derecho'
  }, {
    key: 'di' + index,
    text: 'Izquierdo',
    value: 'Izquierdo'
  }, {
    key: 'bi' + index,
    text: 'Bilateral',
    value: 'Bilateral'
  }];
};
var MANDIBULA_BRANCH = function MANDIBULA_BRANCH(index) {
  return [{
    key: 'null' + index,
    text: 'No aplica',
    value: 'None'
  }, {
    key: 'rama' + index,
    text: 'Rama Mandibular',
    value: 'Rama Mandibular'
  }, {
    key: 'con' + index,
    text: 'Cóndilo Mandibular',
    value: 'Cóndilo Mandibular'
  }, {
    key: 'apo' + index,
    text: 'Apófisis Coronoides',
    value: 'Apófisis Coronoides'
  }];
};
var OP5_TYPE = [{
  key: 'r',
  text: 'Raices Dentarias',
  value: 'Raices Dentarias'
}, {
  key: 'c',
  text: 'Coronas Dentarias',
  value: 'Coronas Dentarias'
}, {
  key: 'o',
  text: 'Óseas',
  value: 'Óseas'
}];
var SINUS_MAXILAR_WALL = function SINUS_MAXILAR_WALL(index) {
  return [{
    key: 'null' + index,
    text: 'No aplica',
    value: 'None'
  }, {
    key: 'ant' + index,
    text: 'Pared Anterior',
    value: 'Pared Anterior'
  }, {
    key: 'post' + index,
    text: 'Pared Posterior',
    value: 'Pared Posterior'
  }, {
    key: 'techo' + index,
    text: 'Techo',
    value: 'Techo'
  }, {
    key: 'piso' + index,
    text: 'Piso',
    value: 'Piso'
  }];
};
var MENUITEMS = function MENUITEMS(currentType) {
  return [{
    title: 'Tipo de Lesión',
    filter: '_type',
    chartTitle: "Prevalencia de lesiones ".concat(currentType, " seg\xFAn tipo")
  }, {
    title: 'Edad',
    filter: 'age',
    chartTitle: "Prevalencia de lesiones ".concat(currentType, " seg\xFAn edad")
  }, {
    title: 'Género',
    filter: 'gender',
    chartTitle: "Prevalencia de lesiones ".concat(currentType, " seg\xFAn g\xE9nero")
  }, {
    title: 'Tipo de Registro',
    filter: 'register',
    chartTitle: "Prevalencia de lesiones ".concat(currentType, " seg\xFAn registro")
  }, {
    title: 'Única-Múltiple',
    filter: 'op1',
    chartTitle: "Prevalencia de lesiones ".concat(currentType, " seg\xFAn cantidad")
  }, {
    title: 'Unilocular-Multilocular',
    filter: 'op2',
    chartTitle: "Prevalencia de lesiones ".concat(currentType, " seg\xFAn compartimientos")
  }, {
    title: 'Formas',
    filter: 'form',
    chartTitle: "Prevalencia de lesiones ".concat(currentType, " seg\xFAn forma")
  }, {
    title: 'Bordes',
    filter: 'op3',
    chartTitle: "Prevalencia de lesiones ".concat(currentType, " seg\xFAn tipo de bordes")
  }, {
    title: 'Localización',
    filter: 'location_sub',
    chartTitle: "Prevalencia de lesiones ".concat(currentType, " seg\xFAn localizaci\xF3n"),
    sub: [{
      title: 'Localización',
      filter: 'location_sub',
      chartTitle: "Prevalencia de lesiones ".concat(currentType, " seg\xFAn localizaci\xF3n")
    }, {
      title: 'Tipo',
      filter: 'location_div',
      chartTitle: "Prevalenc\xEDa de lesiones ".concat(currentType, " seg\xFAn la estructura o espacio que ocupa")
    }, {
      title: 'Tejido Blando',
      filter: 'location_div_0',
      chartTitle: "Prevalencia de lesiones ".concat(currentType, " en tejidos blandos"),
      sub: [{
        title: 'Tejido Blando',
        filter: 'location_div_0',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en tejidos blandos")
      }, {
        title: 'Ligamento Estilohioideo',
        filter: 'location_estilohioideo_position',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en ligamento estilohioideo")
      }, {
        title: 'Lengua',
        filter: 'location_lengua_position',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en lengua")
      }, {
        title: 'Glándula Tiroides',
        filter: 'location_tiroides_position',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en gl\xE1ndula tiroides")
      }, {
        title: 'Amígdala',
        filter: 'location_amigdala_position',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en am\xEDgdala")
      }, {
        title: 'Tejido Blando de Nariz',
        filter: 'location_blnariz_position',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en tejido blando de nariz")
      }]
    }, {
      title: 'Tejido Duro',
      filter: 'location_div_1',
      chartTitle: "Prevalencia de lesiones ".concat(currentType, " en tejidos duros"),
      sub: [{
        title: 'Tejido Duro',
        filter: 'location_div_1',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en tejidos duros")
      }, {
        title: 'Mandíbula',
        filter: 'location_mandibula_position',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en mand\xEDbula"),
        sub: [{
          title: 'Mandíbula',
          filter: 'location_mandibula_position',
          chartTitle: "Prevalencia de lesiones ".concat(currentType, " en mand\xEDbula")
        }, {
          title: 'Cuerpo de la Mandíbula',
          filter: 'location_body_mandibula',
          chartTitle: "Prevalencia de lesiones ".concat(currentType, " en cuerpo de la mand\xEDbula")
        }, {
          title: 'Rama Mandibular',
          filter: 'location_branch_mandibula',
          chartTitle: "Prevalencia de lesiones ".concat(currentType, " en rama mandibular")
        }]
      }, {
        title: 'Maxilar',
        filter: 'location_maxilar_position',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en maxilar"),
        sub: [{
          title: 'Maxilar',
          filter: 'location_maxilar_position',
          chartTitle: "Prevalencia de lesiones ".concat(currentType, " en maxilar")
        }, {
          title: 'Seno Maxilar',
          filter: 'location_sinus_maxilar',
          chartTitle: "Prevalencia de lesiones ".concat(currentType, " en seno maxilar")
        }, {
          title: 'Peredes del Seno Maxilar',
          filter: 'location_sinus_maxilar_wall',
          chartTitle: "Prevalencia de lesiones ".concat(currentType, " en paredes del seno maxilar")
        }]
      }, {
        title: 'Hueso Nasal',
        filter: 'location_nasal_position',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en hueso nasal")
      }, {
        title: 'Espacio de Fosas Nasales',
        filter: 'location_fosa_position',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en espacio de fosas nasales")
      }, {
        title: 'Hueso Temporal',
        filter: 'location_temporal_position',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en hueso temporal")
      }, {
        title: 'Hueso Cigomático',
        filter: 'location_cigomatico_position',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en hueso cigom\xE1tico")
      }, {
        title: 'Hueso Hioides',
        filter: 'location_hioides_position',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en hueso hioides")
      }, {
        title: 'Vertebras Cervicales',
        filter: 'location_cervicales_position',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en vertebras cervicales")
      }]
    }, {
      title: 'Espacio Aéreo',
      filter: 'location_div_2',
      chartTitle: "Prevalencia de lesiones ".concat(currentType, " en espacios a\xE9reos"),
      sub: [{
        title: 'Espacio Aéreo',
        filter: 'location_div_2',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en espacios a\xE9reos")
      }, {
        title: 'Espacio de Orofaringe',
        filter: 'location_oro_position',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en espacio de orofaringe")
      }, {
        title: 'Espacio de Nasofaringe',
        filter: 'location_naso_position',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en espacio de nasofaringe")
      }, {
        title: 'Espacio de Hipofaringe',
        filter: 'location_hipo_position',
        chartTitle: "Prevalencia de lesiones ".concat(currentType, " en espacio de hipofaringe")
      }]
    }]
  }, {
    title: 'Asociada',
    filter: 'op4',
    chartTitle: "Prevalencia de lesiones ".concat(currentType, " asociadas a piezas dentales"),
    sub: [{
      title: 'Asociada',
      filter: 'op4',
      chartTitle: "Prevalencia de lesiones ".concat(currentType, " asociadas a piezas dentales")
    }, {
      title: 'Asociada Pieza Dental',
      filter: 'op4_super',
      chartTitle: "Frecuencia de piezas dentales asociadas por lesiones ".concat(currentType)
    }]
  }, {
    title: 'Reabsorción',
    filter: 'op5',
    chartTitle: "Prevalencia de lesiones ".concat(currentType, " provocando reabsorci\xF3n"),
    sub: [{
      title: 'Reabsorción',
      filter: 'op5',
      chartTitle: "Prevalencia de lesiones ".concat(currentType, " provocando reabsorci\xF3n")
    }, {
      title: 'Reabsorción Tipo',
      filter: 'op5_type',
      chartTitle: "Prevalencia de lesiones ".concat(currentType, " seg\xFAn tipo de reabsorci\xF3n")
    }]
  }, {
    title: 'Desplazamiento',
    filter: 'op6',
    chartTitle: "Prevalencia de lesiones ".concat(currentType, " con desplazamiento de piezas dentales"),
    sub: [{
      title: 'Desplazamiento',
      filter: 'op6',
      chartTitle: "Prevalencia de lesiones ".concat(currentType, " con desplazamiento de piezas dentales")
    }, {
      title: 'Desplazamiento Pieza Dental',
      filter: 'op6_super',
      chartTitle: "Frecuencia de piezas dentales desplazadas por lesiones ".concat(currentType)
    }]
  }, {
    title: 'Expansión de Corticales',
    filter: 'op7',
    chartTitle: "Prevalencia de lesiones ".concat(currentType, " con expansi\xF3n de corticales")
  }, {
    title: 'Pieza Incluida',
    filter: 'op8',
    chartTitle: "Prevalencia de lesiones ".concat(currentType, " con piezas dentales incluidas"),
    sub: [{
      title: 'Pieza Incluida',
      filter: 'op8',
      chartTitle: "Prevalencia de lesiones ".concat(currentType, " con piezas dentales incluidas")
    }, {
      title: 'Número de Pieza Incluida',
      filter: 'op8_super',
      chartTitle: "Frecuencia de piezas dentales incluidas por lesiones ".concat(currentType)
    }]
  }, {
    title: 'Diagnóstico Diferencial 1',
    filter: 'dif1',
    chartTitle: "Prevalencia de Diagn\xF3stico diferencial 1 de lesiones ".concat(currentType)
  }, {
    title: 'Diagnóstico Diferencial 2',
    filter: 'dif2',
    chartTitle: "Prevalencia de Diagn\xF3stico diferencial 2 de lesiones ".concat(currentType)
  }, {
    title: 'Diagnóstico Diferencial 3',
    filter: 'dif3',
    chartTitle: "Prevalencia de Diagn\xF3stico diferencial 3 de lesiones ".concat(currentType)
  }];
};
var COLORS = ["#0D855D", "#1B8F68", "#14CC8F", "#3DFFBD", "#1AFFBA"];

/***/ }),
/* 5 */
/***/ (function(module, exports) {

module.exports = require("js-cookie");

/***/ }),
/* 6 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: external "@babel/runtime/regenerator"
var regenerator_ = __webpack_require__(2);
var regenerator_default = /*#__PURE__*/__webpack_require__.n(regenerator_);

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(0);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);

// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(3);
var router_default = /*#__PURE__*/__webpack_require__.n(router_);

// EXTERNAL MODULE: external "next-cookies"
var external_next_cookies_ = __webpack_require__(9);
var external_next_cookies_default = /*#__PURE__*/__webpack_require__.n(external_next_cookies_);

// EXTERNAL MODULE: external "js-cookie"
var external_js_cookie_ = __webpack_require__(5);
var external_js_cookie_default = /*#__PURE__*/__webpack_require__.n(external_js_cookie_);

// EXTERNAL MODULE: external "isomorphic-unfetch"
var external_isomorphic_unfetch_ = __webpack_require__(10);

// CONCATENATED MODULE: ./utils/api.js


function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

var simulateApi =
/*#__PURE__*/
function () {
  var _ref = _asyncToGenerator(
  /*#__PURE__*/
  regenerator_default.a.mark(function _callee(payload) {
    var delay,
        _args = arguments;
    return regenerator_default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            delay = _args.length > 1 && _args[1] !== undefined ? _args[1] : 1000;
            _context.next = 3;
            return new Promise(function (resolve) {
              return setTimeout(resolve(payload), delay);
            });

          case 3:
            return _context.abrupt("return", _context.sent);

          case 4:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));

  return function simulateApi(_x) {
    return _ref.apply(this, arguments);
  };
}();
// CONCATENATED MODULE: ./utils/auth.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return login; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return auth_logout; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return auth_withAuthSync; });
/* unused harmony export auth */



function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function auth_asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function auth_asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { auth_asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { auth_asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }







var login =
/*#__PURE__*/
function () {
  var _ref2 = auth_asyncToGenerator(
  /*#__PURE__*/
  regenerator_default.a.mark(function _callee(_ref) {
    var username, password, url, response, error;
    return regenerator_default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            username = _ref.username, password = _ref.password, url = _ref.url;
            _context.prev = 1;
            _context.next = 4;
            return simulateApi({
              'ok': true,
              'status': 200
            }, 3000);

          case 4:
            response = _context.sent;
            console.log(response);

            if (!(response.status && response.status == 200)) {
              _context.next = 11;
              break;
            }

            /*const { token } = await response.json()*/
            external_js_cookie_default.a.set('token', 'token', {
              expires: 1
            });
            router_default.a.push('/main');
            _context.next = 15;
            break;

          case 11:
            console.log('Login failed.'); // https://github.com/developit/unfetch#caveats

            error = new Error(response.statusText);
            error.response = response;
            return _context.abrupt("return", Promise.reject(error));

          case 15:
            _context.next = 21;
            break;

          case 17:
            _context.prev = 17;
            _context.t0 = _context["catch"](1);
            console.error('You have an error in your code or there are Network issues.', _context.t0);
            throw new Error(_context.t0);

          case 21:
          case "end":
            return _context.stop();
        }
      }
    }, _callee, null, [[1, 17]]);
  }));

  return function login(_x) {
    return _ref2.apply(this, arguments);
  };
}();
var auth_logout = function logout() {
  external_js_cookie_default.a.remove('token'); // to support logging out from all windows
  //window.localStorage.setItem('logout', Date.now())

  router_default.a.push('/login');
}; // Gets the display name of a JSX component for dev tools

var getDisplayName = function getDisplayName(Component) {
  return Component.displayName || Component.name || 'Component';
};

var auth_withAuthSync = function withAuthSync(WrappedComponent) {
  var _class, _temp;

  return _temp = _class =
  /*#__PURE__*/
  function (_Component) {
    _inherits(_class, _Component);

    _createClass(_class, null, [{
      key: "getInitialProps",
      value: function () {
        var _getInitialProps = auth_asyncToGenerator(
        /*#__PURE__*/
        regenerator_default.a.mark(function _callee2(ctx) {
          var token, componentProps;
          return regenerator_default.a.wrap(function _callee2$(_context2) {
            while (1) {
              switch (_context2.prev = _context2.next) {
                case 0:
                  token = auth_auth(ctx);
                  _context2.t0 = WrappedComponent.getInitialProps;

                  if (!_context2.t0) {
                    _context2.next = 6;
                    break;
                  }

                  _context2.next = 5;
                  return WrappedComponent.getInitialProps(ctx);

                case 5:
                  _context2.t0 = _context2.sent;

                case 6:
                  componentProps = _context2.t0;
                  return _context2.abrupt("return", _objectSpread({}, componentProps, {
                    token: token
                  }));

                case 8:
                case "end":
                  return _context2.stop();
              }
            }
          }, _callee2);
        }));

        function getInitialProps(_x2) {
          return _getInitialProps.apply(this, arguments);
        }

        return getInitialProps;
      }()
    }]);

    function _class(props) {
      var _this;

      _classCallCheck(this, _class);

      _this = _possibleConstructorReturn(this, _getPrototypeOf(_class).call(this, props));
      _this.syncLogout = _this.syncLogout.bind(_assertThisInitialized(_this));
      return _this;
    }

    _createClass(_class, [{
      key: "componentDidMount",
      value: function componentDidMount() {
        window.addEventListener('storage', this.syncLogout);
      }
    }, {
      key: "componentWillUnmount",
      value: function componentWillUnmount() {
        window.removeEventListener('storage', this.syncLogout);
        window.localStorage.removeItem('logout');
      }
    }, {
      key: "syncLogout",
      value: function syncLogout(event) {
        if (event.key === 'logout') {
          console.log('logged out from storage!');
          router_default.a.push('/login');
        }
      }
    }, {
      key: "render",
      value: function render() {
        return external_react_default.a.createElement(WrappedComponent, this.props);
      }
    }]);

    return _class;
  }(external_react_["Component"]), _defineProperty(_class, "displayName", "withAuthSync(".concat(getDisplayName(WrappedComponent), ")")), _temp;
};
var auth_auth = function auth(ctx) {
  var _nextCookie = external_next_cookies_default()(ctx),
      token = _nextCookie.token;

  if (ctx.req && !token) {
    ctx.res.writeHead(302, {
      Location: '/login'
    });
    ctx.res.end();
    return;
  }

  if (!token) {
    router_default.a.push('/login');
  }

  return token;
};

/***/ }),
/* 7 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(0);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);


/* harmony default export */ __webpack_exports__["a"] = (function () {
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(next_head__WEBPACK_IMPORTED_MODULE_1___default.a, null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("link", {
    rel: "stylesheet",
    href: "//cdn.jsdelivr.net/npm/semantic-ui@2.4.2/dist/semantic.min.css"
  }), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("style", null, "\n\t\t\t    \tbody { background: #3f0644; color: rgba(255,255,255,.9); }\n\t\t\t    \tlabel { color: white !important; }\n        \t")));
});

/***/ }),
/* 8 */
/***/ (function(module, exports) {

module.exports = require("next/head");

/***/ }),
/* 9 */
/***/ (function(module, exports) {

module.exports = require("next-cookies");

/***/ }),
/* 10 */
/***/ (function(module, exports) {

module.exports = require("isomorphic-unfetch");

/***/ }),
/* 11 */
/***/ (function(module, exports) {

module.exports = require("recharts");

/***/ }),
/* 12 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(0);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1);
/* harmony import */ var semantic_ui_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__);


/* harmony default export */ __webpack_exports__["a"] = (function (_ref) {
  var _ref$headerTitle = _ref.headerTitle,
      headerTitle = _ref$headerTitle === void 0 ? 'LESIONES ROENTGENOLÓGICAS' : _ref$headerTitle;
  return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", {
    style: {
      marginBottom: 25,
      paddingTop: 10
    }
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
    style: {
      backgroundColor: 'white'
    }
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__["Grid"].Row, {
    columns: 3
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__["Grid"].Column, {
    width: 2
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__["Image"], {
    src: "static/usac-logo.png",
    style: {
      margin: 'auto'
    },
    width: 65,
    height: 65
  })), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__["Grid"].Column, {
    width: 12
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__["Header"], {
    as: "h2",
    color: "purple",
    textAlign: "center",
    style: {
      'height': '100%',
      'width': '100%',
      'position': 'absolute',
      'top': '30%'
    }
  }, headerTitle)), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__["Grid"].Column, {
    width: 2
  }, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__["Image"], {
    src: "static/fousac-logo.jpeg",
    style: {
      margin: 'auto'
    },
    width: 65,
    height: 65
  }))), react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement(semantic_ui_react__WEBPACK_IMPORTED_MODULE_1__["Grid"].Row, {
    style: {
      'color': 'black',
      'textAlign': 'right',
      'padding': '0 35px 0 0',
      'display': 'block'
    }
  }, "Adriana Olivar")));
});

/***/ }),
/* 13 */,
/* 14 */,
/* 15 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(31);


/***/ }),
/* 16 */,
/* 17 */,
/* 18 */,
/* 19 */,
/* 20 */,
/* 21 */,
/* 22 */,
/* 23 */,
/* 24 */,
/* 25 */,
/* 26 */,
/* 27 */,
/* 28 */,
/* 29 */,
/* 30 */,
/* 31 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);

// EXTERNAL MODULE: external "@babel/runtime/regenerator"
var regenerator_ = __webpack_require__(2);
var regenerator_default = /*#__PURE__*/__webpack_require__.n(regenerator_);

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(0);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);

// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(3);

// EXTERNAL MODULE: external "semantic-ui-react"
var external_semantic_ui_react_ = __webpack_require__(1);

// EXTERNAL MODULE: ./components/headerlayout.jsx
var headerlayout = __webpack_require__(12);

// EXTERNAL MODULE: external "recharts"
var external_recharts_ = __webpack_require__(11);

// EXTERNAL MODULE: ./configuration/options.js
var options = __webpack_require__(4);

// CONCATENATED MODULE: ./components/filterpie.jsx



/* harmony default export */ var filterpie = (function (props) {
  return external_react_default.a.createElement("div", {
    style: {
      width: '100%',
      height: 500,
      padding: "0 0 0 15%"
    }
  }, external_react_default.a.createElement(external_recharts_["ResponsiveContainer"], null, external_react_default.a.createElement(external_recharts_["PieChart"], null, external_react_default.a.createElement(external_recharts_["Pie"], {
    dataKey: "value",
    isAnimationActive: true,
    data: props.data,
    label: true
  }, props.data.map(function (entry, index) {
    return external_react_default.a.createElement(external_recharts_["Cell"], {
      key: index,
      fill: options["a" /* COLORS */][index % options["a" /* COLORS */].length]
    });
  })), external_react_default.a.createElement(external_recharts_["Legend"], {
    verticalAlign: "bottom",
    layout: "vertical",
    align: "right",
    wrapperStyle: {
      paddingLeft: "15px"
    }
  }), external_react_default.a.createElement(external_recharts_["Tooltip"], null))));
});
// EXTERNAL MODULE: ./components/css.jsx
var css = __webpack_require__(7);

// EXTERNAL MODULE: ./utils/auth.js + 1 modules
var auth = __webpack_require__(6);

// CONCATENATED MODULE: ./pages/chart.jsx


function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance"); }

function _iterableToArrayLimit(arr, i) { if (!(Symbol.iterator in Object(arr) || Object.prototype.toString.call(arr) === "[object Arguments]")) { return; } var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }









/* harmony default export */ var chart = __webpack_exports__["default"] = (Object(auth["c" /* withAuthSync */])(Object(router_["withRouter"])(function (props) {
  var translateMenu = function translateMenu(m) {
    return {
      key: m.filter,
      text: m.title,
      value: m
    };
  };

  var title = props.router.query.title;
  var headerTitle = title.charAt(0).toUpperCase() + title.slice(1);
  var headerTitleChart = '';

  if (headerTitle !== 'Todas') {
    headerTitleChart = headerTitle.toLowerCase();
  } else {
    headerTitleChart = 'Roentgenológicas'.toLowerCase();
  }

  var menu = Object(options["h" /* MENUITEMS */])(headerTitleChart).map(translateMenu);

  var _useState = Object(external_react_["useState"])(menu[0].value.filter),
      _useState2 = _slicedToArray(_useState, 2),
      filter = _useState2[0],
      setFilter = _useState2[1];

  var _useState3 = Object(external_react_["useState"])(menu[0].value.title),
      _useState4 = _slicedToArray(_useState3, 2),
      filterTitle = _useState4[0],
      setFilterTitle = _useState4[1];

  var _useState5 = Object(external_react_["useState"])(menu[0].value.chartTitle),
      _useState6 = _slicedToArray(_useState5, 2),
      chartTitle = _useState6[0],
      setChartTitle = _useState6[1];

  var _useState7 = Object(external_react_["useState"])([]),
      _useState8 = _slicedToArray(_useState7, 2),
      data = _useState8[0],
      setData = _useState8[1];

  var _useState9 = Object(external_react_["useState"])([]),
      _useState10 = _slicedToArray(_useState9, 2),
      subMenuItems = _useState10[0],
      setSubMenuItems = _useState10[1];

  var getData = function getData() {
    return fetch("http://127.0.0.1:5000/injury/".concat(title, "/").concat(filter)).then(function (response) {
      return response.json();
    }).then(function (data) {
      setData(data);
    });
  };

  Object(external_react_["useEffect"])(function () {
    getData();
  }, [filter]);

  var handleItemClick =
  /*#__PURE__*/
  function () {
    var _ref = _asyncToGenerator(
    /*#__PURE__*/
    regenerator_default.a.mark(function _callee(filter, sub, chartTitle, filterTitle) {
      return regenerator_default.a.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              setFilter(filter);
              setChartTitle(chartTitle);
              setFilterTitle(filterTitle);

              if (sub) {
                setSubMenuItems(sub.map(translateMenu));
              } else {
                setSubMenuItems([]);
              }

            case 4:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }));

    return function handleItemClick(_x, _x2, _x3, _x4) {
      return _ref.apply(this, arguments);
    };
  }();

  return external_react_default.a.createElement("div", null, external_react_default.a.createElement(css["a" /* default */], null), external_react_default.a.createElement(headerlayout["a" /* default */], {
    headerTitle: headerTitle
  }), external_react_default.a.createElement(external_semantic_ui_react_["Grid"], null, external_react_default.a.createElement(external_semantic_ui_react_["Grid"].Column, {
    width: 2
  }), external_react_default.a.createElement(external_semantic_ui_react_["Grid"].Column, {
    width: 12
  }, external_react_default.a.createElement(external_semantic_ui_react_["Segment"], {
    inverted: true,
    color: "purple",
    inline: true
  }, external_react_default.a.createElement(external_semantic_ui_react_["Grid"], null, external_react_default.a.createElement(external_semantic_ui_react_["Grid"].Column, {
    streched: true,
    width: 16
  }, external_react_default.a.createElement(external_semantic_ui_react_["Grid"].Row, null, external_react_default.a.createElement(external_semantic_ui_react_["Dropdown"], {
    text: filterTitle,
    icon: "filter",
    floating: true,
    labeled: true,
    button: true,
    options: menu,
    className: "icon",
    onChange: function onChange(e, _ref2) {
      var value = _ref2.value;
      return handleItemClick(value.filter, value.sub, value.chartTitle, value.title);
    }
  }), subMenuItems && subMenuItems.length > 0 ? external_react_default.a.createElement(external_semantic_ui_react_["Dropdown"], {
    icon: "filter",
    floating: true,
    labeled: true,
    button: true,
    options: subMenuItems,
    className: "icon",
    onChange: function onChange(e, _ref3) {
      var value = _ref3.value;
      return handleItemClick(value.filter, value.sub, value.chartTitle, value.title);
    }
  }) : null, external_react_default.a.createElement(external_semantic_ui_react_["Segment"], {
    inverted: true,
    style: {
      'textAlign': 'center'
    }
  }, external_react_default.a.createElement("p", null, chartTitle))), external_react_default.a.createElement(external_semantic_ui_react_["Grid"].Row, null, external_react_default.a.createElement(filterpie, {
    data: data
  })), external_react_default.a.createElement(external_semantic_ui_react_["Grid"].Row, null, external_react_default.a.createElement(external_semantic_ui_react_["Segment"], {
    inverted: true
  }, external_react_default.a.createElement("p", null, "Fuente: examen radiol\xF3gico, fase III Dx, FOUSAC"))))))), external_react_default.a.createElement(external_semantic_ui_react_["Grid"].Column, {
    width: 2
  })));
})));

/***/ })
/******/ ]);